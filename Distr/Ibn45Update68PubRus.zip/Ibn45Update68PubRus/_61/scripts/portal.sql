SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetAssignedByUser]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ToDoAndTasksGetAssignedByUser]
	@UserId as int,
	@ShowActive as bit,
	@FromDate datetime,
	@ToDate datetime
as
SET @ToDate = DATEADD(d, 1, @ToDate)
DECLARE @ActiveState int, @OverdueState int
SET @ActiveState = 2
SET @OverdueState  = 3
DECLARE @Now datetime, @MaxValue datetime, @MinValue datetime
SET @Now = getutcdate()
SET @MaxValue = DATEADD(yy, 100, @Now)
SET @MinValue = DATEADD(yy, -100, @Now)
DECLARE @IsPpmExec bit
SET @IsPpmExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND (GroupId = 4 OR GroupId = 7))
	SET @IsPpmExec = 1
SELECT ToDoId AS ItemId, Title, IsCompleted, CompletionTypeId, ReasonId, 1 AS IsToDo, StateId,
	CreationDate, StartDate, FinishDate, ActualStartDate, ActualFinishDate, ISNULL(FinishDate, DATEADD(yy, 100, CreationDate)) AS SortFinishDate
  FROM TODO
  WHERE (ManagerId = @UserId OR CreatorId = @UserId)
	AND
	(@ShowActive = 0 OR StateId = @ActiveState OR StateId = @OverdueState)
	AND
		CASE
			WHEN StartDate IS NOT NULL AND StartDate < ISNULL(ActualStartDate, @MaxValue) THEN StartDate
			WHEN ActualStartDate IS NOT NULL AND ActualStartDate < ISNULL(StartDate, @MaxValue) THEN ActualStartDate
			ELSE CreationDate
		END < @ToDate
	AND
		CASE
			WHEN FinishDate IS NOT NULL AND FinishDate > ISNULL(ActualFinishDate, @Now) THEN FinishDate
			WHEN ActualFinishDate IS NOT NULL AND ActualFinishDate > ISNULL(FinishDate, @MinValue) THEN ActualFinishDate
			WHEN ActualFinishDate IS NULL THEN @Now
			ELSE CreationDate
		END > @FromDate
	AND
    (
        @IsPpmExec = 1
        OR ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
        OR ToDoId IN
	        (SELECT ToDoId FROM TODO_SECURITY_ALL S
        	  WHERE PrincipalId = @UserId AND (IsResource = 1 OR IsManager = 1))
    )
UNION ALL
SELECT T.TaskId  AS ItemId, T.Title, T.IsCompleted, T.CompletionTypeId, T.ReasonId, 0 AS IsToDo, T.StateId,
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate, T.FinishDate AS SortFinishDate
  FROM TASKS T
	JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
  WHERE (P.ManagerId = @UserId OR T.CreatorId = @UserId)
	AND
	(@ShowActive = 0 OR T.StateId = @ActiveState OR T.StateId = @OverdueState)
	AND
		CASE
			WHEN T.StartDate < ISNULL(T.ActualStartDate, @MaxValue) THEN T.StartDate
			WHEN T.ActualStartDate IS NOT NULL AND T.ActualStartDate < T.StartDate THEN T.ActualStartDate
			ELSE T.CreationDate
		END < @ToDate
	AND
		CASE
			WHEN T.FinishDate > ISNULL(T.ActualFinishDate, @Now) THEN T.FinishDate
			WHEN T.ActualFinishDate IS NOT NULL AND T.ActualFinishDate > T.FinishDate THEN T.ActualFinishDate
			WHEN T.ActualFinishDate IS NULL THEN @Now
			ELSE T.CreationDate
		END > @FromDate
	AND T.IsSummary = 0 AND T.IsMilestone = 0
	AND
    (
        @IsPpmExec = 1
        OR T.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
        OR TaskId IN
    	    (SELECT TaskId FROM TASK_SECURITY S
        	  WHERE PrincipalId = @UserId AND (IsResource = 1 OR IsManager = 1))
    )
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
