SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[fsc_FileGetCountByProjectAll]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].fsc_FileGetCountByProjectAll
	@ProjectId as int,
	@retval int output
AS
DECLARE @SelectedContainerKeys TABLE(ContainerKey nvarchar(50) COLLATE database_default)
INSERT INTO @SelectedContainerKeys
	SELECT DISTINCT N'ProjectId_' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	UNION
	SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	UNION
	SELECT DISTINCT N'TaskId_' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	UNION
	SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	UNION
	SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	UNION
	SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
SELECT @retval = COUNT(*)
  FROM fsc_Files F WITH (NOLOCK)
	INNER JOIN fsc_Directories D WITH (NOLOCK) ON F.DirectoryId = D.DirectoryId
WHERE
	D.ContainerKey IN (SELECT ContainerKey FROM @SelectedContainerKeys)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[UsersGetBy2GroupAll]'
GO
CREATE PROCEDURE [dbo].UsersGetBy2GroupAll
	@Group1Id as int,
	@Group2Id as int
as
DECLARE @Active tinyint
SET @Active = 3
DECLARE @Pending tinyint
SET @Pending = 2
SELECT PrincipalId AS UserId, Login, FirstName, LastName, Email, IMGroupId, OriginalId, CreatedBy, Activity, IsExternal
  FROM USERS
  WHERE PrincipalId IN (SELECT UserId FROM USER_GROUP WHERE GroupId = @Group1Id OR GroupId = @Group2Id)
	AND (Activity = @Active OR Activity = @Pending)
ORDER BY LastName, FirstName
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
