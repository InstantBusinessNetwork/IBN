SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Creating [dbo].[EmailMessageSmtpQueue]'
GO
CREATE TABLE [dbo].[EmailMessageSmtpQueue]
(
[Id] [int] NOT NULL IDENTITY(1, 1),
[Created] [datetime] NOT NULL CONSTRAINT [DF_EmailMessageSmtpQueue_Created] DEFAULT (getutcdate()),
[MailFrom] [nvarchar] (255) NOT NULL,
[RcptTo] [nvarchar] (255) NOT NULL,
[Subject] [ntext] NOT NULL,
[EmlData] [image] NULL,
[Generation] [int] NOT NULL CONSTRAINT [DF_EmailMessageSmtpQueue_Generation] DEFAULT ((0)),
[ErrorMsg] [ntext] NOT NULL CONSTRAINT [DF_EmailMessageSmtpQueue_ErrorMsg] DEFAULT ('')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
PRINT N'Creating primary key [PK_EmailMessageSmtpQueue] on [dbo].[EmailMessageSmtpQueue]'
GO
ALTER TABLE [dbo].[EmailMessageSmtpQueue] ADD CONSTRAINT [PK_EmailMessageSmtpQueue] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
PRINT N'Creating [dbo].[mc_EmailMessageSmtpQueueDelete]'
GO
CREATE PROCEDURE [dbo].[mc_EmailMessageSmtpQueueDelete]
(
@Id int
)
AS
    SET NOCOUNT ON
DELETE FROM [EmailMessageSmtpQueue]
WHERE
[Id] = @Id
RETURN @@Error
GO
PRINT N'Creating [dbo].[mc_EmailMessageSmtpQueueInsert]'
GO
CREATE PROCEDURE [dbo].[mc_EmailMessageSmtpQueueInsert]
(
@Id int = NULL OUTPUT
,
@Created datetime,
@MailFrom nvarchar(255),
@RcptTo nvarchar(255),
@Subject ntext,
@EmlData image = NULL
,
@Generation int,
@ErrorMsg ntext)
AS
    SET NOCOUNT ON
INSERT INTO [EmailMessageSmtpQueue]
(
[Created],
[MailFrom],
[RcptTo],
[Subject],
[EmlData],
[Generation],
[ErrorMsg])
VALUES(
@Created,
@MailFrom,
@RcptTo,
@Subject,
@EmlData,
@Generation,
@ErrorMsg)
SELECT @Id = SCOPE_IDENTITY();
RETURN @@Error
GO
PRINT N'Creating [dbo].[mc_EmailMessageSmtpQueueList]'
GO
CREATE PROCEDURE [dbo].[mc_EmailMessageSmtpQueueList]
AS
    SET NOCOUNT ON
SELECT [Id],
[Created],
[MailFrom],
[RcptTo],
[Subject],
NULL,
[Generation],
[ErrorMsg] FROM EmailMessageSmtpQueue
ORDER BY [Created]
GO
PRINT N'Creating [dbo].[mc_EmailMessageSmtpQueueSelect]'
GO
CREATE PROCEDURE [dbo].[mc_EmailMessageSmtpQueueSelect]
(
@Id int
)
AS
    SET NOCOUNT ON
SELECT [Id],
[Created],
[MailFrom],
[RcptTo],
[Subject],
NULL,
[Generation],
[ErrorMsg] FROM EmailMessageSmtpQueue
WHERE
[Id] = @Id
GO
PRINT N'Creating [dbo].[mc_EmailMessageSmtpQueueUpdate]'
GO
CREATE PROCEDURE [dbo].[mc_EmailMessageSmtpQueueUpdate]
(
@Id int,
@Created datetime,
@MailFrom nvarchar(255),
@RcptTo nvarchar(255),
@Subject ntext,
@Generation int,
@ErrorMsg ntext)
AS
    SET NOCOUNT ON
UPDATE [EmailMessageSmtpQueue]
SET
[Created] = @Created,
[MailFrom] = @MailFrom,
[RcptTo] = @RcptTo,
[Subject] = @Subject,
[Generation] = @Generation,
[ErrorMsg] = @ErrorMsg
WHERE
[Id] = @Id
RETURN @@Error
GO
