SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Dropping constraints from [dbo].[mf_InnerAttachment]'
GO
ALTER TABLE [dbo].[mf_InnerAttachment] DROP CONSTRAINT [PK_mf_InnerAttachment]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping constraints from [dbo].[mf_InnerAttachment]'
GO
ALTER TABLE [dbo].[mf_InnerAttachment] DROP CONSTRAINT [DF_mf_InnerAttachment_Uid]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping constraints from [dbo].[mf_InnerAttachment]'
GO
ALTER TABLE [dbo].[mf_InnerAttachment] DROP CONSTRAINT [DF_mf_InnerAttachment_Created]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping constraints from [dbo].[mf_InnerAttachment]'
GO
ALTER TABLE [dbo].[mf_InnerAttachment] DROP CONSTRAINT [DF_mf_InnerAttachment_Attributes]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[mf_InnerAttachmentCleanUp]'
GO
DROP PROCEDURE [dbo].[mf_InnerAttachmentCleanUp]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[mc_mf_InnerAttachmentInsert]'
GO
DROP PROCEDURE [dbo].[mc_mf_InnerAttachmentInsert]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[mc_mf_InnerAttachmentDelete]'
GO
DROP PROCEDURE [dbo].[mc_mf_InnerAttachmentDelete]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[mc_mf_InnerAttachmentUpdate]'
GO
DROP PROCEDURE [dbo].[mc_mf_InnerAttachmentUpdate]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[mc_mf_InnerAttachmentSelect]'
GO
DROP PROCEDURE [dbo].[mc_mf_InnerAttachmentSelect]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[mf_InnerAttachment]'
GO
DROP TABLE [dbo].[mf_InnerAttachment]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ContentTypeGetByString]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].ContentTypeGetByString
	@ContentTypeString as nvarchar(250)
as
SELECT ContentTypeId, Extension, ContentTypeString, FriendlyName,
	CASE WHEN IconFileId IS NULL THEN -1 ELSE IconFileId END AS IconFileId,
	CASE WHEN BigIconFileId IS NULL THEN -1 ELSE BigIconFileId END AS BigIconFileId,
	AllowWebDav
  FROM CONTENT_TYPES
  WHERE ContentTypeString = @ContentTypeString
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[SqlFileStorage]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TABLE [dbo].[SqlFileStorage]
(
[AttachmentId] [int] NOT NULL IDENTITY(1, 1),
[Uid] [uniqueidentifier] NOT NULL CONSTRAINT [DF_mf_InnerAttachment_Uid] DEFAULT (newid()),
[SessionUid] [uniqueidentifier] NOT NULL CONSTRAINT [DF_mf_InnerAttachment_SessionUid] DEFAULT (newid()),
[Created] [datetime] NOT NULL CONSTRAINT [DF_mf_InnerAttachment_Created] DEFAULT (getutcdate()),
[FileName] [nvarchar] (255) NOT NULL,
[FileStream] [image] NULL,
[Size] AS (datalength([FileStream])),
[Type] [int] NOT NULL,
[ReferenceUrl] [ntext] NOT NULL CONSTRAINT [DF_SqlFileStorage_ReferenceUrl] DEFAULT (N''),
[Attributes] [ntext] NOT NULL CONSTRAINT [DF_mf_InnerAttachment_Attributes] DEFAULT (N'')
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_mf_InnerAttachment] on [dbo].[SqlFileStorage]'
GO
ALTER TABLE [dbo].[SqlFileStorage] ADD CONSTRAINT [PK_mf_InnerAttachment] PRIMARY KEY CLUSTERED  ([AttachmentId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SqlFileStorageUpdate]'
GO
CREATE PROCEDURE [dbo].[mc_SqlFileStorageUpdate]
(
@AttachmentId int,
@Uid uniqueidentifier,
@Created datetime,
@FileName nvarchar(255),
@Type int,
@ReferenceUrl ntext,
@FileStream image = NULL
,
@Attributes ntext,
@SessionUid uniqueidentifier)
AS
    SET NOCOUNT ON
UPDATE [SqlFileStorage]
SET
[Uid] = @Uid,
[Created] = @Created,
[FileName] = @FileName,
[Type] = @Type,
[ReferenceUrl] = @ReferenceUrl,
[FileStream] = @FileStream,
[Attributes] = @Attributes,
[SessionUid] = @SessionUid
WHERE
[AttachmentId] = @AttachmentId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SqlFileStorageInsert]'
GO
CREATE PROCEDURE [dbo].[mc_SqlFileStorageInsert]
(
@AttachmentId int = NULL OUTPUT
,
@Uid uniqueidentifier,
@Created datetime,
@FileName nvarchar(255),
@Type int,
@ReferenceUrl ntext,
@FileStream image = NULL,
@Attributes ntext,
@SessionUid uniqueidentifier)
AS
    SET NOCOUNT ON
INSERT INTO [SqlFileStorage]
(
[Uid],
[Created],
[FileName],
[Type],
[ReferenceUrl],
[FileStream],
[Attributes],
[SessionUid])
VALUES(
@Uid,
@Created,
@FileName,
@Type,
@ReferenceUrl,
@FileStream,
@Attributes,
@SessionUid)
SELECT @AttachmentId = SCOPE_IDENTITY();
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SqlFileStorageSelect]'
GO
CREATE PROCEDURE [dbo].[mc_SqlFileStorageSelect]
(
@AttachmentUId uniqueidentifier
)
AS
    SET NOCOUNT ON
SELECT [AttachmentId],
[Uid],
[Created],
[FileName],
[Type],
[ReferenceUrl],
[FileStream],
[Attributes],
SessionUid,
[Size] FROM SqlFileStorage
WHERE
[Uid] = @AttachmentUId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SqlFileStorageSelectBySessionUid]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[mc_SqlFileStorageSelectBySessionUid]
(
@SessionUid uniqueidentifier
)
AS
    SET NOCOUNT ON
SELECT [AttachmentId],
[Uid],
[Created],
[FileName],
[Type],
[ReferenceUrl],
[FileStream],
[Attributes],
SessionUid,
[Size] FROM SqlFileStorage
WHERE
[SessionUid] = @SessionUid
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SqlFileStorageDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[mc_SqlFileStorageDelete]
(
@AttachmentId int
)
AS
    SET NOCOUNT ON
DELETE FROM [mf_InnerAttachment]
WHERE
[AttachmentId] = @AttachmentId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SqlFileStorageDeleteBySessionUid]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[mc_SqlFileStorageDeleteBySessionUid]
(
@SessionUid int
)
AS
    SET NOCOUNT ON
DELETE FROM [mf_InnerAttachment]
WHERE
[SessionUid] = @SessionUid
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
