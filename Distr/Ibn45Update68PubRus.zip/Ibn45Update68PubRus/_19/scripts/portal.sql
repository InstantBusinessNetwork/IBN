SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Dropping [dbo].[ArticlesGetByTag]'
GO
DROP PROCEDURE [dbo].[ArticlesGetByTag]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[Articles]'
GO
sp_rename N'[dbo].[Articles].[Delimeter]', N'Delimiter', 'COLUMN'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_DirectoryDelete]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].fsc_DirectoryDelete
	@DirectoryId INT
AS
SET NOCOUNT ON
BEGIN TRAN
	IF NOT EXISTS(SELECT * FROM fsc_Directories WHERE DirectoryId = @DirectoryId)
	BEGIN
		RAISERROR('Invalid DirectoryId.',16,1)
		GOTO ERR
	END
	DECLARE @SearchPath VARCHAR(512)
	SELECT @SearchPath = (Path + CAST(@DirectoryId AS VARCHAR(10)) + '.%') FROM fsc_Directories WHERE DirectoryId = @DirectoryId
	DECLARE @DeletedDirectories TABLE (DirectoryId INT)
	INSERT INTO @DeletedDirectories (DirectoryId)
	SELECT DirectoryId FROM fsc_Directories WHERE Path LIKE @SearchPath OR DirectoryId = @DirectoryId ORDER BY Path
	DECLARE CurFile CURSOR LOCAL FOR
		SELECT FileId FROM fsc_Files WHERE DirectoryId IN (SELECT DirectoryId FROM @DeletedDirectories)
	OPEN CurFile
	DECLARE @CurFileId int
	FETCH NEXT FROM CurFile INTO @CurFileId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC fsc_FileDelete @CurFileId
		IF @@ERROR <> 0 GOTO ERR
	FETCH NEXT FROM CurFile INTO @CurFileId
	END
	CLOSE CurFile
	DEALLOCATE CurFile
	DELETE FROM fsc_Directories WHERE DirectoryId IN (SELECT DirectoryId FROM @DeletedDirectories)
	IF @@ERROR <> 0 GOTO ERR
COMMIT TRAN
RETURN
ERR:
	ROLLBACK TRAN
RETURN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ArticlesAdd]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE ArticlesAdd
	@Question as nvarchar(1000) ,
	@Answer as ntext,
	@AnswerHTML as ntext,
	@Tags as nvarchar(1000) ,
	@Delimiter nchar(1),
	@retval int output
as
INSERT INTO Articles (Question, Answer, AnswerHTML, Tags, Created, Counter, Delimiter)
  VALUES(@Question, @Answer, @AnswerHTML, @Tags, GETUTCDATE(), 0, @Delimiter)
SELECT @retval = @@identity
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[EMailTempFileCleanUp]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].[EMailTempFileCleanUp]
AS
	BEGIN TRANSACTION
	DECLARE CurDir CURSOR LOCAL FOR
		SELECT DirectoryId FROM fsc_Directories WHERE
			ContainerKey = N'EMailAttach'
			AND
			ParentDirectoryId IS NOT NULL
			AND
			DATEADD(Day, 7, Created) < GetDate()
	OPEN CurDir
	DECLARE @CurDirId int
	FETCH NEXT FROM CurDir INTO @CurDirId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC fsc_DirectoryDelete @CurDirId
		IF @@ERROR <> 0 GOTO ERR
	FETCH NEXT FROM CurDir INTO @CurDirId
	END
	CLOSE CurDir
	DEALLOCATE CurDir
	COMMIT TRAN
	RETURN
ERR:
	ROLLBACK TRAN
	RETURN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ArticlesUpdate]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE ArticlesUpdate
	@ArticleId int,
	@Question as nvarchar(1000) ,
	@Answer as ntext,
	@AnswerHTML as ntext,
	@Tags as nvarchar(1000),
	@Delimiter nchar(1)
as
UPDATE Articles
  SET Question=@Question, Answer=@Answer, AnswerHTML=@AnswerHTML, Tags=@Tags, Delimiter=@Delimiter
  WHERE ArticleId = @ArticleId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ArticlesGet]'
GO
ALTER PROCEDURE [dbo].ArticlesGet
       @ArticleId as int
as
SELECT ArticleId, Question, Answer, AnswerHTML, Tags, Created, Counter, Delimiter
  FROM Articles
  WHERE @ArticleId=0 OR ArticleId = @ArticleId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO

IF NOT EXISTS (SELECT * FROM [dbo].PortalConfig WHERE [Key] = N'email.routing.antispamfilter')
 INSERT INTO [dbo].PortalConfig ([Key],[Value]) VALUES (N'email.routing.antispamfilter', N'True')
GO