SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[SmtpOutputMessage]'
GO
CREATE TABLE [dbo].[SmtpOutputMessage]
(
[SmtpOutputMessageId] [int] NOT NULL IDENTITY(1, 1),
[Created] [datetime] NOT NULL CONSTRAINT [DF_SmtpOutputMessage_Created] DEFAULT (getutcdate()),
[MailFrom] [nvarchar] (255) NOT NULL,
[RcptTo] [nvarchar] (255) NOT NULL,
[Subject] [ntext] NOT NULL,
[EmlData] [image] NULL,
[Sent] [datetime] NULL,
[Attempts] [int] NOT NULL CONSTRAINT [DF_SmtpOutputMessage_Attempts] DEFAULT (0),
[ErrorText] [ntext] NOT NULL CONSTRAINT [DF_SmtpOutputMessage_ErrorText] DEFAULT (N'')
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_SmtpOutputMessage] on [dbo].[SmtpOutputMessage]'
GO
ALTER TABLE [dbo].[SmtpOutputMessage] ADD CONSTRAINT [PK_SmtpOutputMessage] PRIMARY KEY CLUSTERED  ([SmtpOutputMessageId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SmtpOutputMessageUpdate]'
GO
CREATE PROCEDURE [dbo].[mc_SmtpOutputMessageUpdate]
(
@SmtpOutputMessageId int,
@Created datetime,
@MailFrom nvarchar(255),
@RcptTo nvarchar(255),
@Subject ntext,
@EmlData image = NULL
,
@Sent datetime = NULL
,
@Attempts int,
@ErrorText ntext)
AS
    SET NOCOUNT ON
UPDATE [SmtpOutputMessage]
SET
[Created] = @Created,
[MailFrom] = @MailFrom,
[RcptTo] = @RcptTo,
[Subject] = @Subject,
[EmlData] = @EmlData,
[Sent] = @Sent,
[Attempts] = @Attempts,
[ErrorText] = @ErrorText
WHERE
[SmtpOutputMessageId] = @SmtpOutputMessageId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SmtpOutputMessageDelete]'
GO
CREATE PROCEDURE [dbo].[mc_SmtpOutputMessageDelete]
(
@SmtpOutputMessageId int
)
AS
    SET NOCOUNT ON
DELETE FROM [SmtpOutputMessage]
WHERE
[SmtpOutputMessageId] = @SmtpOutputMessageId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SmtpOutputMessageInsert]'
GO
CREATE PROCEDURE [dbo].[mc_SmtpOutputMessageInsert]
(
@SmtpOutputMessageId int = NULL OUTPUT
,
@Created datetime,
@MailFrom nvarchar(255),
@RcptTo nvarchar(255),
@Subject ntext,
@EmlData image = NULL
,
@Sent datetime = NULL
,
@Attempts int,
@ErrorText ntext)
AS
    SET NOCOUNT ON
INSERT INTO [SmtpOutputMessage]
(
[Created],
[MailFrom],
[RcptTo],
[Subject],
[EmlData],
[Sent],
[Attempts],
[ErrorText])
VALUES(
@Created,
@MailFrom,
@RcptTo,
@Subject,
@EmlData,
@Sent,
@Attempts,
@ErrorText)
SELECT @SmtpOutputMessageId = SCOPE_IDENTITY();
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_SmtpOutputMessageSelect]'
GO
CREATE PROCEDURE [dbo].[mc_SmtpOutputMessageSelect]
(
@SmtpOutputMessageId int
)
AS
    SET NOCOUNT ON
SELECT [SmtpOutputMessageId],
[Created],
[MailFrom],
[RcptTo],
[Subject],
[EmlData],
[Sent],
[Attempts],
[ErrorText] FROM SmtpOutputMessage
WHERE
[SmtpOutputMessageId] = @SmtpOutputMessageId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
