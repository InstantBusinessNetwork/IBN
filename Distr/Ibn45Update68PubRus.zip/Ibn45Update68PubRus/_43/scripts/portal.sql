SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Dropping [dbo].[IncidentGetMetrics]'
GO
DROP PROCEDURE [dbo].[IncidentGetMetrics]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentGet]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].IncidentGet
	@IncidentId as int,
	@LanguageId as int
as
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle, I.CreatorId, I.Title, I.[Description], I.Resolution, I.Workaround,
	I.CreationDate, I.TypeId, IT.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId, SV.SeverityName,
	I.IsEmail, I.MailSenderEmail, I.TaskTime, I.IncidentBoxId, I.OrgId, I.VCardId, ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.ExpectedDuration, I.ExpectedResponseTime, I.ActualFinishDate, I.ResponsibleId, I.IsResponsibleGroup, I.Identifier,
	I.ModifiedDate, I.ExpectedResponseDate, I.ExpectedResolveDate, I.ActualOpenDate,
	CASE WHEN B.ControllerId > 0
	THEN
		B.ControllerId
	ELSE
		I.CreatorId
	END as ControllerId,
	(SELECT
	CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
	END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN INCIDENT_TYPES IT ON (I.TypeId = IT.TypeId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN INCIDENT_SEVERITY SV ON (I.SeverityId = SV.SeverityId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
  WHERE I.IncidentId = @IncidentId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_ForumThreadNodeCreate]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].fsc_ForumThreadNodeCreate
@ThreadId int,
@Text ntext,
@Created datetime,
@CreatorId int,
@CreatorName nvarchar(255),
@CreatorEmail nvarchar(50),
@EMailMessageId int,
@NodeType int,
@Retval int out
AS
INSERT INTO [fsc_ForumThreadNodes]([ThreadId], [Text], [Created], [CreatorId], [CreatorName], [CreatorEmail], EMailMessageId, NodeType)
VALUES(@ThreadId, @Text, @Created, @CreatorId, @CreatorName, @CreatorEmail, @EMailMessageId, @NodeType)
SET @Retval = @@IDENTITY
DECLARE @ForumId int, @ContainerKey nvarchar(50), @IncidentId int
SELECT @ForumId = ForumId FROM fsc_ForumThreads WHERE ThreadId = @ThreadId
SELECT @ContainerKey = ContainerKey FROM fsc_Forums WHERE ForumId = @ForumId
IF LEFT(@ContainerKey, 11) = 'IncidentId_'
BEGIN
	SET @IncidentId = CAST(REPLACE(@ContainerKey, 'IncidentId_', '') as int)
	UPDATE INCIDENTS SET ModifiedDate = getutcdate() WHERE IncidentId = @IncidentId
	IF @NodeType = 1
	BEGIN
		DECLARE @CalendarId int, @ExpectedResponseDate datetime, @ExpectedResponseTime int
		SELECT @CalendarId = B.CalendarId, @ExpectedResponseTime = I.ExpectedResponseTime
			FROM Incidents I
				JOIN IncidentBox B ON (I.IncidentBoxId = B.IncidentBoxId)
			WHERE I.IncidentId = @IncidentId
		IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
			SET @CalendarId = (SELECT MIN(CalendarId) FROM Calendars)
		SET @ExpectedResponseDate = [dbo].GetFinishDateByDuration(@CalendarId, getutcdate(), @ExpectedResponseTime)
		UPDATE INCIDENTS SET ExpectedResponseDate = @ExpectedResponseDate WHERE IncidentId = @IncidentId
	END
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetByFilter]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[IncidentsGetByFilter]
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle, I.IncidentBoxId,B.[Name] as IncidentBoxName,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId
	,U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	INM.NewMessage,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate, I.ModifiedDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,  I.Identifier,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId  OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT  JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
	LEFT JOIN INCIDENT_NEWMESSAGE INM ON I.IncidentId = INM.IncidentId
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND (IsResource = 1 OR IsIncidentResponsible =1)))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND (I.Title LIKE @Keyword OR I.[Description] LIKE @Keyword OR I.Resolution LIKE @Keyword OR I.Workaround LIKE @Keyword OR CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
  ORDER BY ProjectTitle
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
