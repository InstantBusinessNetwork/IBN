SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[OrganizationDelete]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].OrganizationDelete
	@OrgId as int
as
DECLARE @ObjectType int
SET @ObjectType = 21
DELETE FROM TAGS WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM COLLAPSED_PROJECTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_TODO_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM ORGANIZATIONS WHERE OrgId = @OrgId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[Cal_GetDurationByFinishDate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].Cal_GetDurationByFinishDate
	@CalendarId int,
	@StartDate datetime,
	@EndDate datetime,
	@retval int output
AS
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
SET @StartDate = [dbo].GetLocalDate(@TimeZoneId, @StartDate)
SET @EndDate = [dbo].GetLocalDate(@TimeZoneId, @EndDate)
DECLARE @DayOfWeek tinyint
DECLARE @Duration int, @DayDuration int
SET @Duration = 0
SET @DayDuration = 0
DECLARE @StartTime smallint
SET @StartTime = DATEPART(hh, @StartDate) * 60 + DATEPART(mi, @StartDate)
DECLARE @EndTime smallint
SET @EndTime = 24*60
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@StartTime, @StartDate)
WHILE @ProcessDate <= @EndDate BEGIN
	IF DATEDIFF(dd, @ProcessDate, @EndDate) = 0
			SET @EndTime = DATEPART(hh, @EndDate) * 60 + DATEPART(mi, @EndDate)
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(CASE WHEN ToTime < @EndTime THEN ToTime ELSE @EndTime END  - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		  FROM CAL_EXCEPTION_HOURS
		  WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
			AND ToTime > @StartTime AND FromTime < @EndTime
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(CASE WHEN ToTime < @EndTime THEN ToTime ELSE @EndTime END - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		  FROM CAL_WEEKDAYS
		  WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime AND FromTime < @EndTime
	END
	IF @DayDuration IS NOT NULL
		SET @Duration = @Duration + @DayDuration
	SET @ProcessDate = DATEADD(dd, 1, @ProcessDate)
	SET @StartTime = 0
END
SET @retval = @Duration
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_VCardDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[mc_VCardDelete]
(
@VCardId int
)
AS
    SET NOCOUNT ON
DECLARE @ObjectType int
SET @ObjectType = 22
DELETE FROM TAGS WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM COLLAPSED_PROJECTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_TODO_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM [VCard] WHERE [VCardId] = @VCardId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[Cal_GetFinishDateByDuration]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].Cal_GetFinishDateByDuration
	@CalendarId int,
	@StartDate datetime,
	@Duration int,
	@retval datetime output
AS
DECLARE @EndDate datetime
DECLARE @FromTime smallint, @ToTime smallint
DECLARE @IntervalDuration smallint
DECLARE @DayDuration smallint
DECLARE @DayOfWeek tinyint
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
SET @StartDate = [dbo].GetLocalDate(@TimeZoneId, @StartDate)
DECLARE @StartTime smallint
SET @StartTime = DATEPART(hh, @StartDate) * 60 + DATEPART(mi, @StartDate)
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@StartTime, @StartDate)
WHILE @Duration >= 0 BEGIN
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(ToTime - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		 FROM CAL_EXCEPTION_HOURS
		 WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
			AND ToTime > @StartTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration <= @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END AS FromTime, ToTime
					 FROM CAL_EXCEPTION_HOURS
					 WHERE ExceptionId IN
						(SELECT ExceptionId
						  FROM CAL_EXCEPTIONS
						  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
						AND ToTime > @StartTime
					 ORDER BY FromTime
				BREAK
			END
		END
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(ToTime - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		 FROM CAL_WEEKDAYS
		 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration <= @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END AS FromTime, ToTime
					 FROM CAL_WEEKDAYS
					 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime
					 ORDER BY FromTime
				BREAK
			END
		END
	END
	SET @ProcessDate = DATEADD(dd, 1, @ProcessDate)
	SET @StartTime = 0
END
OPEN HoursCursor
FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @IntervalDuration = @ToTime - @FromTime
	IF @IntervalDuration <= @Duration
		SET @Duration = @Duration - @IntervalDuration
	ELSE BEGIN
		SET @EndDate = DATEADD(mi, @FromTime + @Duration,@ProcessDate)
		BREAK
	END
	FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
END
CLOSE HoursCursor
DEALLOCATE HoursCursor
SET @retval = [dbo].GetUTCDateFromLocal(@TimeZoneId, @EndDate)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[Cal_GetStartDateByDuration]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].Cal_GetStartDateByDuration
	@CalendarId int,
	@FinishDate datetime,
	@Duration int,
	@retval datetime output
AS
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
SET @FinishDate = [dbo].GetLocalDate(@TimeZoneId, @FinishDate)
DECLARE @StartdDate datetime
DECLARE @FromTime smallint, @ToTime smallint
DECLARE @IntervalDuration smallint
DECLARE @DayDuration smallint
DECLARE @DayOfWeek tinyint
DECLARE @FinishTime smallint
SET @FinishTime = DATEPART(hh, @FinishDate) * 60 + DATEPART(mi, @FinishDate)
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@FinishTime, @FinishDate)
WHILE @Duration >= 0 BEGIN
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END - FromTime)
		 FROM CAL_EXCEPTION_HOURS
		 WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
			AND FromTime <= @FinishTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration < @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT FromTime, CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END AS ToTime
					 FROM CAL_EXCEPTION_HOURS
					 WHERE ExceptionId IN
						(SELECT ExceptionId
						  FROM CAL_EXCEPTIONS
						  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
						AND FromTime <= @FinishTime
					 ORDER BY ToTime DESC
				BREAK
			END
		END
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END - FromTime)
		 FROM CAL_WEEKDAYS
		 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND FromTime <= @FinishTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration < @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT FromTime, CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END AS ToTime
					 FROM CAL_WEEKDAYS
					 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND FromTime <= @FinishTime
					 ORDER BY ToTime DESC
				BREAK
			END
		END
	END
	SET @ProcessDate = DATEADD(dd, -1, @ProcessDate)
	SET @FinishTime = 24*60
END
OPEN HoursCursor
FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @IntervalDuration = @ToTime - @FromTime
	IF @IntervalDuration < @Duration
		SET @Duration = @Duration - @IntervalDuration
	ELSE BEGIN
		SET @StartdDate = DATEADD(mi, @ToTime - @Duration, @ProcessDate)
		BREAK
	END
	FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
END
CLOSE HoursCursor
DEALLOCATE HoursCursor
SET @StartdDate = [dbo].GetUTCDateFromLocal(@TimeZoneId, @StartdDate)
SET @retval = @StartdDate
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
