SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[mdpsp_sys_FullTextQueriesFieldUpdate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].mdpsp_sys_FullTextQueriesFieldUpdate
	@MetaClassId 	INT,
	@MetaFieldId	INT,
	@Add		BIT
AS
	DECLARE 	@IsFulltextEnabled INT
	SET @IsFulltextEnabled = 0
	IF @IsFulltextEnabled = 0
		RETURN
	DECLARE @TableName		NVARCHAR(256)
	SELECT @TableName	= TableName FROM MetaClass WHERE MetaClassId = @MetaClassId
	DECLARE @FieldName		NVARCHAR(256)
	SELECT @FieldName	= MF.Name FROM MetaField MF
		INNER JOIN MetaDataType MDT ON MDT.DataTypeId = MF.DataTypeId
	WHERE MF.MetaFieldId = @MetaFieldId AND MDT.SqlName IN (N'char', N'nchar', N'varchar', N'nvarchar', N'text', N'ntext', N'image')
	IF (@TableName IS NULL) OR (@FieldName IS NULL)
		RETURN
	DECLARE @TableFulltextCatalogId	INT
	SELECT @TableFulltextCatalogId = OBJECTPROPERTY (OBJECT_ID(TableName), 'TableFulltextCatalogId') FROM MetaClass WHERE MetaClassId = @MetaClassId
	IF @TableFulltextCatalogId = 0
	BEGIN
		DECLARE	@PK_Table NVARCHAR(256)
		SELECT 	@PK_Table = PrimaryKeyName FROM MetaClass WHERE MetaClassId = @MetaClassId
		EXEC sp_fulltext_table  @TableName, 'create', 'MetaDataFullTextQueriesCatalog', @PK_Table
		IF @Add = 1
			EXEC sp_fulltext_column @TableName,  @FieldName,  'add'
	END
	ELSE
	BEGIN
		EXEC sp_fulltext_table  @TableName,  'deactivate'
		IF @Add = 1
			EXEC sp_fulltext_column @TableName,  @FieldName,  'add'
		ELSE
			EXEC sp_fulltext_column @TableName,  @FieldName,  'drop'
	END
	DECLARE @SFCount	INT
	SELECT @SFCount = SUM(COLUMNPROPERTY ( OBJECT_ID(@TableName), [name],  'IsFullTextIndexed' )) FROM MetaField
	IF @SFCount = 0
	BEGIN
		EXEC sp_fulltext_table  @TableName,  'drop'
	END
	ELSE
	BEGIN
		EXEC sp_fulltext_table @TableName,  'activate'
	END
	EXEC sp_fulltext_catalog  'MetaDataFullTextQueriesCatalog',  'start_full'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
