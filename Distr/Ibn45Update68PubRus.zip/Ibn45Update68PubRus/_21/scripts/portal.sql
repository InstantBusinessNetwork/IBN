SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[CONTENT_TYPES]'
GO
ALTER TABLE [dbo].[CONTENT_TYPES] ADD
[AllowWebDav] [bit] NOT NULL CONSTRAINT [DF_CONTENT_TYPES_AllowWebDav] DEFAULT (0)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypesGet]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].ContentTypesGet
as
SELECT ContentTypeId, Extension, ContentTypeString, FriendlyName,
	CASE WHEN IconFileId IS NULL THEN -1 ELSE IconFileId END AS IconFileId,
	CASE WHEN BigIconFileId IS NULL THEN -1 ELSE BigIconFileId END AS BigIconFileId,
	AllowWebDav
  FROM CONTENT_TYPES
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeGetByExtension]'
GO
ALTER PROCEDURE [dbo].ContentTypeGetByExtension
       @Extension as nvarchar(10)
as
SELECT ContentTypeId, Extension, ContentTypeString, FriendlyName, AllowWebDav
  FROM CONTENT_TYPES
  WHERE Extension = @Extension
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeCreate]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].ContentTypeCreate
	@Extension as nvarchar(10),
	@ContentTypeString as nvarchar(250),
	@FriendlyName as nvarchar(50),
	@IconFileId as int,
	@BigIconFileId as int,
	@AllowWebDav as bit,
	@retval int output
as
INSERT INTO CONTENT_TYPES (Extension, ContentTypeString, IconFileId, BigIconFileId, FriendlyName, AllowWebDav)
  VALUES (@Extension, @ContentTypeString, @IconFileId, @BigIconFileId, @FriendlyName, @AllowWebDav)
select @retval = @@identity
UPDATE fsc_FileBinaries SET ContentTypeId = @retval
WHERE FileBinaryId IN
	(Select FileBinaryId from fsc_Files
		WHERE
		CHARINDEX('.',REVERSE([Name])) >  0
		AND
		RIGHT([Name], CHARINDEX('.',REVERSE([Name]))-1) = @Extension
	)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeGet]'
GO
ALTER PROCEDURE [dbo].ContentTypeGet
	@ContentTypeId as int
as
SELECT ContentTypeId, Extension, ContentTypeString, FriendlyName,
	CASE WHEN IconFileId IS NULL THEN -1 ELSE IconFileId END AS IconFileId,
	CASE WHEN BigIconFileId IS NULL THEN -1 ELSE BigIconFileId END AS BigIconFileId,
	AllowWebDav
  FROM CONTENT_TYPES
  WHERE ContentTypeId = @ContentTypeId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeUpdate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].ContentTypeUpdate
	@ContentTypeId as int,
	@FriendlyName as nvarchar(50),
	@AllowWebDav as bit
as
UPDATE CONTENT_TYPES
  SET FriendlyName = @FriendlyName, AllowWebDav = @AllowWebDav
  WHERE ContentTypeId = @ContentTypeId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_FullTextSearchGetInfo]'
GO
ALTER PROCEDURE [dbo].[fsc_FullTextSearchGetInfo]
AS
SELECT FULLTEXTCATALOGPROPERTY('ibnfts', 'PopulateStatus') as PopulateStatus, FULLTEXTCATALOGPROPERTY('ibnfts', 'IndexSize') as IndexSize
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO

UPDATE CONTENT_TYPES SET allowwebdav=1 WHERE Extension='doc' or Extension='ppt' or Extension='xls' or Extension='vsd' or Extension='mpp' or Extension='docx' or Extension='xlsx'
GO

DECLARE @val BIT

IF NOT EXISTS (SELECT * FROM [dbo].PortalConfig WHERE [Key] = N'filelibrary.webdav')
BEGIN
	SELECT @val = UseWebDav FROM {MainDB}.[dbo].COMPANIES WHERE db_name = '{PortalDB}'
	INSERT INTO [dbo].PortalConfig ([Key], [Value]) VALUES (N'filelibrary.webdav', CASE WHEN @val=1 THEN N'True' ELSE N'False' END)
END

IF NOT EXISTS (SELECT * FROM [dbo].PortalConfig WHERE [Key] = N'portal.usewinlogin')
BEGIN
	SELECT @val = LoginAD FROM {MainDB}.[dbo].COMPANIES WHERE db_name = '{PortalDB}'
	INSERT INTO [dbo].PortalConfig ([Key], [Value]) VALUES (N'portal.usewinlogin', CASE WHEN @val=1 THEN N'True' ELSE N'False' END)
END
GO
