SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[TRIAL_PROFILES]'
GO
ALTER TABLE [dbo].[TRIAL_PROFILES] DROP
COLUMN [UseAlertService],
COLUMN [AlertServiceUrl],
COLUMN [SmtpServer]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_TRIAL_SETTINGS_UPDATE]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].ASP_TRIAL_SETTINGS_UPDATE
	@ProfileId as int,
	@ProfileName as nvarchar(50),
	@ManualActivation as bit,
	@MaxHdd as int,
	@MaxUsers as int,
	@MaxExternalUsers as int,
	@TrialPeriod as int,
	@UseIm as bit,
	@AdminEmail as nvarchar(100),
	@ServerLink as nvarchar(100),
	@EmailFrom as nvarchar(100),
	@EmailTrial as nvarchar(100),
	@ResellerTemplate as ntext,
	@ResellerBanner as image,
	@TrialTopLogo as image,
	@DnsRecordType NVARCHAR(50),
	@DnsParentDomain NVARCHAR(100),
	@DnsRecordData NVARCHAR(100),
	@IisIpAddress NVARCHAR(15),
	@IisPort INT
AS
IF @ProfileId = -1
	INSERT INTO TRIAL_PROFILES (ProfileName, ManualActivation, MaxHDD, MaxUsers, MaxExternalUsers, TrialPeriod, UseIM, AdminEmail,
	  ServerLink, EmailFrom, EmailTrial,
	  ResellerTemplate, ResellerBanner, TrialTopLogo, DnsRecordType, DnsParentDomain, DnsRecordData, IisIpAddress, IisPort)
	  VALUES (@ProfileName, @ManualActivation, @MaxHDD, @MaxUsers, @MaxExternalUsers, @TrialPeriod, @UseIM, @AdminEmail,
	  @ServerLink, @EmailFrom, @EmailTrial,
	  @ResellerTemplate, @ResellerBanner, @TrialTopLogo, @DnsRecordType, @DnsParentDomain, @DnsRecordData, @IisIpAddress, @IisPort)
ELSE
	UPDATE TRIAL_PROFILES SET ProfileName = @ProfileName, ManualActivation = @ManualActivation, MaxHDD = @MaxHDD,
	 MaxUsers = @MaxUsers, MaxExternalUsers = @MaxExternalUsers, TrialPeriod = @TrialPeriod, UseIM = @UseIM, AdminEmail = @AdminEmail,
	 ServerLink = @ServerLink, EmailFrom = @EmailFrom, EmailTrial = @EmailTrial,
	 ResellerTemplate = @ResellerTemplate, ResellerBanner = @ResellerBanner, TrialTopLogo = @TrialTopLogo,
	 DnsRecordType = @DnsRecordType, DnsParentDomain = @DnsParentDomain, DnsRecordData = @DnsRecordData, IisIpAddress = @IisIpAddress, IisPort = @IisPort
	  WHERE ProfileId = @ProfileId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_TRIAL_SETTINGS_GET]'
GO
ALTER PROCEDURE [dbo].ASP_TRIAL_SETTINGS_GET
	@ProfileId INT
AS
SELECT TOP 1 ProfileID, ProfileName, ManualActivation, MaxHDD, MaxUsers, MaxExternalUsers, TrialPeriod, UseIM, AdminEmail, ServerLink,
	EmailFrom, EmailTrial, ResellerTemplate, ResellerBanner, TrialTopLogo,
	DnsRecordType, DnsParentDomain, DnsRecordData, IisIpAddress, IisPort
  FROM TRIAL_PROFILES
  WHERE ProfileID = @ProfileId OR @ProfileId = 0 OR @ProfileId = -1 AND IsActive = 1
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
