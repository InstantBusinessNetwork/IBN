SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[COMPANIES]'
GO
ALTER TABLE [dbo].[COMPANIES] ADD
[UseWebDav] [bit] NOT NULL CONSTRAINT [DF_COMPANIES_UseWebDav] DEFAULT (0)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Company_UseWebDavGet]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].Company_UseWebDavGet
	@CompanyId INT
AS
SELECT UseWebDav FROM COMPANIES
 WHERE company_id = @CompanyId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_GET_COMPANY]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].ASP_GET_COMPANY
	@company_type INT,
	@company_id INT
AS
SELECT company_id, company_name, domain, [db_name], app_id, C.description, contact_name, contact_phone, contact_email, support_name, support_email, product_name,
	theme, use_im, title1, title2, text1, text2, max_users, max_external_users, is_global, creation_date, company_type, start_date, end_date, rate_per_user, is_active, max_disk_space,
	enable_alerts, show_admin_wizard, use_ssl, firstdayofweek, Port,
	CC.StatusId, S.Name AS StatusName, CC.Description AS StatusDescription, DATALENGTH(S.Icon) AS StatusIconLength
 FROM Companies C
LEFT JOIN CompanyComment CC ON CC.CompanyId = company_id
LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE (company_id = @company_id OR @company_id = 0) AND (company_type=@company_type OR @company_type=0)
 ORDER BY company_name
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_TRIAL_REQUEST_GET]'
GO
ALTER PROCEDURE [dbo].ASP_TRIAL_REQUEST_GET
	@RequestID as int,
	@IncludeInactive as bit
AS
SELECT R.RequestID, CompanyName, R.CompanyID, SizeOfGroup, R.Description, Domain, FirstName, LastName, Email, Phone, Country, TimeZone, Login, Password, R.ResellerId, RS.Title AS ResellerTitle, XML, R.GUID, UseIM, IsActive, IsDeleted, CreationDate, Locale, TimeZoneId,
	CC.StatusId, S.Name AS StatusName, CC.Description AS StatusDescription, DATALENGTH(S.Icon) AS StatusIconLength
 FROM TRIAL_REQUESTS R
 JOIN TRIAL_RESELLERS RS ON (R.ResellerId = RS.ResellerId)
 LEFT JOIN CompanyComment CC ON CC.RequestId = R.RequestId
 LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE (@IncludeInactive = 1 OR IsActive = 1)  AND (R.RequestID = @RequestID OR @RequestID = 0) AND IsDeleted = 0
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Company_UseWebDavSet]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].Company_UseWebDavSet
	@CompanyId INT,
	@Enable BIT
AS
UPDATE COMPANIES
 SET UseWebDav = @Enable
 WHERE company_id = @CompanyId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
