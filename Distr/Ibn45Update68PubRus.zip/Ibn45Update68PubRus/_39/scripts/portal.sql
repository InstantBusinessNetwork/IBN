DELETE FROM MetaClassMetaFieldRelation
 WHERE MetaClassId IN (SELECT MetaClassId FROM MetaClass WHERE [Name] = 'Assets' OR [Name] = 'AssetsEx')
DELETE FROM MetaField 
 WHERE SystemMetaClassId IN (SELECT MetaClassId FROM MetaClass WHERE [Name] = 'Assets' OR [Name] = 'AssetsEx')
DELETE FROM MetaClass
 WHERE [Name] = 'Assets' OR [Name] = 'AssetsEx'
GO
