SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[EventsGetByFilter]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].EventsGetByFilter
	@ProjectId as int,
	@UserId as int,
	@ResourceId as int,
	@StartDate as datetime,
	@FinishDate as datetime,
	@GetAssigned as bit,
	@GetManaged as bit,
	@GetCreated as bit,
	@VCardId as int = NULL,
	@OrgId as int = NULL,
	@Keyword as nvarchar(100)
as
SET @Keyword = '%' + @Keyword + '%'
DECLARE @EventType int
SET @EventType = 4
SET @FinishDate = DATEADD(d, 1, @FinishDate)
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
IF @VCardId <=0
	SET @VCardId = NULL
IF @OrgId <=0
	SET @OrgId = NULL
SELECT EventId, Title, [Description], TypeId, Location, StartDate, FinishDate,
	CASE WHEN R.RecurrenceId IS NULL THEN 0 ELSE 1 END AS HasRecurrence,
	CASE WHEN @IsPPM = 1 OR E.ManagerId = @UserId THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR E.ManagerId = @UserId THEN 1 ELSE 0 END AS CanDelete,
	ManagerId, PriorityId, Interval, E.StateId
  FROM EVENTS E
	LEFT JOIN RECURRENCE R ON (E.EventId = R.ObjectId AND R.ObjectTypeId = @EventType)
  WHERE (@ProjectId = 0 OR ProjectId = @ProjectId OR (@ProjectId = -1 AND ProjectId IS NULL))
	AND StartDate < @FinishDate AND FinishDate > @StartDate
	AND (@Keyword = '%%' OR E.Title LIKE @Keyword OR E.[Description] LIKE @Keyword OR E.Location LIKE @Keyword)
	AND (@VCardId = NULL OR E.VCardId = @VCardId)
	AND (@OrgId = NULL OR  E.OrgId = @OrgId OR E.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND
	(
		(@GetAssigned = 1 AND (@ResourceId = 0 OR EventId IN
			(SELECT EventId FROM EVENT_SECURITY_ALL S
			  WHERE PrincipalId = @ResourceId AND (IsResource = 1 OR IsManager = 1))))
		OR
		(@GetManaged =1 AND (@ResourceId = 0 OR E.ManagerId = @ResourceId))
		OR
		(@GetCreated =1 AND (@ResourceId = 0 OR E.CreatorId = @ResourceId))
	)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
