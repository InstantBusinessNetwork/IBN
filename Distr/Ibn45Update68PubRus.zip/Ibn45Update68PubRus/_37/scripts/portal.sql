SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[TaskRecalculateSummaryPercent]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].TaskRecalculateSummaryPercent
			@TaskId INT
AS
DECLARE @Dt datetime
SET @Dt = getutcdate()
DECLARE @OutlineNumber VarChar(255)
DECLARE @ProjectId INT
SELECT @OutlineNumber = OutlineNumber, @ProjectId = ProjectId FROM TASKS WHERE TaskId = @TaskId
DECLARE SummaryCursor CURSOR FOR SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId AND IsSummary = 1 AND (@OutlineNumber LIKE OutlineNumber + '.%' OR @TaskId = TaskId) ORDER BY TaskNum DESC
DECLARE @reOutlineNumber VarChar(255)
DECLARE @reTaskId INT, @reOutlineLevel INT
OPEN SummaryCursor
FETCH NEXT FROM SummaryCursor INTO @reTaskId
WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT @reOutlineNumber = OutlineNumber, @reOutlineLevel = OutlineLevel FROM TASKS WHERE TaskId = @reTaskId
	UPDATE TASKS SET PercentCompleted =
		(SELECT AVG(PercentCompleted) FROM TASKS WHERE OutlineNumber LIKE @reOutlineNumber + '.%'  AND OutlineLevel = @reOutlineLevel +1 AND ProjectId = @ProjectId)
	  WHERE TaskId = @reTaskId
 	IF NOT EXISTS(SELECT * FROM TASKS WHERE IsCompleted = 0 AND OutlineNumber LIKE @reOutlineNumber + '.%'  AND OutlineLevel = @reOutlineLevel +1 AND ProjectId = @ProjectId)
		UPDATE TASKS SET IsCompleted = 1, ReasonId = 2, ActualFinishDate = @Dt
		  WHERE TaskId = @reTaskId
	ELSE
		UPDATE TASKS SET IsCompleted = 0, ReasonId = -1, ActualFinishDate = null
		  WHERE TaskId = @reTaskId
   FETCH NEXT FROM SummaryCursor INTO @reTaskId
END
CLOSE SummaryCursor
DEALLOCATE SummaryCursor
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TaskUpdateTaskTime]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].TaskUpdateTaskTime
	@TaskId as int ,
	@TaskTime as int
as
UPDATE TASKS SET TaskTime = @TaskTime
  WHERE TaskId = @TaskId AND TaskTime = 0
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
