SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[FieldSets]'
GO
CREATE TABLE [dbo].[FieldSets]
(
[FieldSetId] [int] NOT NULL IDENTITY(1, 1),
[Title] [nvarchar] (250) NOT NULL,
[ListUid] [uniqueidentifier] NOT NULL,
[XmlSet] [ntext] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_FieldSets] on [dbo].[FieldSets]'
GO
ALTER TABLE [dbo].[FieldSets] ADD CONSTRAINT [PK_FieldSets] PRIMARY KEY CLUSTERED  ([FieldSetId]) ON [PRIMARY]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[FieldSetAdd]'
GO
CREATE PROCEDURE [dbo].[FieldSetAdd]
	@ListUid as uniqueidentifier ,
	@Title as nvarchar(250),
	@XmlSet as ntext,
	@retval as int out
as
	INSERT INTO FieldSets (Title, ListUid, XmlSet) VALUES(@Title, @ListUid, @XmlSet)
select @retval = @@identity
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[FieldSetsGetByListUid]'
GO
CREATE PROCEDURE [dbo].[FieldSetsGetByListUid]
	@ListUid uniqueidentifier
as
SELECT FieldSetId, Title, ListUid, XmlSet
  FROM FieldSets
  WHERE ListUid = @ListUid
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[FieldSetGet]'
GO
CREATE PROCEDURE [dbo].[FieldSetGet]
	@FieldSetId int
as
SELECT FieldSetId, Title, ListUid, XmlSet
  FROM FieldSets
  WHERE @FieldSetId=0 OR FieldSetId = @FieldSetId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[FieldSetDelete]'
GO
CREATE PROCEDURE FieldSetDelete
	@FieldSetId as int
as
	DELETE FROM FieldSets WHERE FieldSetId=@FieldSetId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[FieldSetUpdate]'
GO
CREATE PROCEDURE [dbo].[FieldSetUpdate]
	@FieldSetId as int,
	@Title as nvarchar(250),
	@ListUid as uniqueidentifier,
	@XmlSet as ntext
as
	UPDATE FieldSets
		SET Title = @Title, ListUid = @ListUid, XmlSet=@XmlSet
	WHERE FieldSetId=@FieldSetId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[INCIDENTS]'
GO
ALTER TABLE [dbo].[INCIDENTS] ADD
[ModifiedDate] [datetime] NULL,
[ExpectedResponseDate] [datetime] NULL,
[ExpectedResolveDate] [datetime] NULL,
[ActualOpenDate] [datetime] NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[CONTENT_TYPES]'
GO
ALTER TABLE [dbo].[CONTENT_TYPES] ADD
[AllowNewWindow] [bit] NOT NULL CONSTRAINT [DF_CONTENT_TYPES_AllowNewWindow] DEFAULT (0)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[TasksGetByProjectCollapsed]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].TasksGetByProjectCollapsed
	@ProjectId as int,
	@UserId as int
as
SELECT T.TaskId, T.TaskNum, T.OutlineNumber, T.OutlineLevel, T.IsSummary, T.IsMilestone, T.Title, T.PercentCompleted, T.CompletionTypeId, T.IsCompleted,
	CASE WHEN CT.CollapsedId IS NOT NULL AND T.IsSummary = 1 THEN 1 ELSE 0 END AS IsCollapsed,
	T.StartDate, T.FinishDate, T.Duration, T.StateId, T.ActualStartDate, T.ActualFinishDate
  FROM TASKS T
	LEFT JOIN COLLAPSED_TASKS CT ON (T.TaskId = CT.TaskId AND CT.UserId = @UserId)
  WHERE T.ProjectId = @ProjectId
  ORDER BY T.TaskNum
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeGetByExtension]'
GO
ALTER PROCEDURE [dbo].[ContentTypeGetByExtension]
       @Extension as nvarchar(10)
as
SELECT ContentTypeId, Extension, ContentTypeString, FriendlyName, AllowWebDav, AllowNewWindow
  FROM CONTENT_TYPES
  WHERE Extension = @Extension
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypesGet]'
GO
ALTER PROCEDURE [dbo].[ContentTypesGet]
as
SELECT ContentTypeId, Extension, ContentTypeString, FriendlyName,
	CASE WHEN IconFileId IS NULL THEN -1 ELSE IconFileId END AS IconFileId,
	CASE WHEN BigIconFileId IS NULL THEN -1 ELSE BigIconFileId END AS BigIconFileId,
	AllowWebDav, AllowNewWindow
  FROM CONTENT_TYPES
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TaskUpdateActualStart]'
GO
CREATE PROCEDURE [dbo].TaskUpdateActualStart
	@TaskId as int
as
UPDATE TASKS
  SET ActualStartDate = getutcdate()
  WHERE TaskId = @TaskId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeUpdate]'
GO
ALTER PROCEDURE [dbo].[ContentTypeUpdate]
	@ContentTypeId as int,
	@FriendlyName as nvarchar(50),
	@AllowWebDav as bit,
	@AllowNewWindow as bit
as
UPDATE CONTENT_TYPES
  SET FriendlyName = @FriendlyName, AllowWebDav = @AllowWebDav, AllowNewWindow = @AllowNewWindow
  WHERE ContentTypeId = @ContentTypeId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeCreate]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[ContentTypeCreate]
	@Extension as nvarchar(10),
	@ContentTypeString as nvarchar(250),
	@FriendlyName as nvarchar(50),
	@IconFileId as int,
	@BigIconFileId as int,
	@AllowWebDav as bit,
	@AllowNewWindow as bit,
	@retval int output
as
INSERT INTO CONTENT_TYPES (Extension, ContentTypeString, IconFileId, BigIconFileId, FriendlyName, AllowWebDav, AllowNewWindow)
  VALUES (@Extension, @ContentTypeString, @IconFileId, @BigIconFileId, @FriendlyName, @AllowWebDav, @AllowNewWindow)
select @retval = @@identity
UPDATE fsc_FileBinaries SET ContentTypeId = @retval
WHERE FileBinaryId IN
	(Select FileBinaryId from fsc_Files
		WHERE
		CHARINDEX('.',REVERSE([Name])) >  0
		AND
		RIGHT([Name], CHARINDEX('.',REVERSE([Name]))-1) = @Extension
	)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[Act_TodoUpdateConfigurationInfo]'
GO
ALTER PROCEDURE [dbo].Act_TodoUpdateConfigurationInfo
	@TodoId int,
	@ActivationTypeId int,
	@CompletionTypeId int,
	@MustBeConfirmed bit,
	@retval int output
AS
UPDATE TODO
 SET ActivationTypeId = @ActivationTypeId, CompletionTypeId = @CompletionTypeId, MustBeConfirmed = @MustBeConfirmed
 WHERE TodoId = @TodoId AND (ActivationTypeId != @ActivationTypeId OR CompletionTypeId != @CompletionTypeId OR MustBeConfirmed != @MustBeConfirmed)
SET @retval = @@ROWCOUNT
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeGet]'
GO
ALTER PROCEDURE [dbo].[ContentTypeGet]
	@ContentTypeId as int
as
SELECT ContentTypeId, Extension, ContentTypeString, FriendlyName,
	CASE WHEN IconFileId IS NULL THEN -1 ELSE IconFileId END AS IconFileId,
	CASE WHEN BigIconFileId IS NULL THEN -1 ELSE BigIconFileId END AS BigIconFileId,
	AllowWebDav, AllowNewWindow
  FROM CONTENT_TYPES
  WHERE ContentTypeId = @ContentTypeId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ToDoUpdateActualStart]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].ToDoUpdateActualStart
	@ToDoId as int
as
UPDATE TODO
  SET ActualStartDate = getutcdate()
  WHERE ToDoId = @ToDoId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ContentTypeGetByString]'
GO
ALTER PROCEDURE [dbo].[ContentTypeGetByString]
	@ContentTypeString as nvarchar(250)
as
SELECT ContentTypeId, Extension, ContentTypeString, FriendlyName,
	CASE WHEN IconFileId IS NULL THEN -1 ELSE IconFileId END AS IconFileId,
	CASE WHEN BigIconFileId IS NULL THEN -1 ELSE BigIconFileId END AS BigIconFileId,
	AllowWebDav, AllowNewWindow
  FROM CONTENT_TYPES
  WHERE ContentTypeString = @ContentTypeString
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_ForumThreadNodeCreate]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].fsc_ForumThreadNodeCreate
@ThreadId int,
@Text ntext,
@Created datetime,
@CreatorId int,
@CreatorName nvarchar(255),
@CreatorEmail nvarchar(50),
@EMailMessageId int,
@NodeType int,
@Retval int out
AS
INSERT INTO [fsc_ForumThreadNodes]([ThreadId], [Text], [Created], [CreatorId], [CreatorName], [CreatorEmail], EMailMessageId, NodeType)
VALUES(@ThreadId, @Text, @Created, @CreatorId, @CreatorName, @CreatorEmail, @EMailMessageId, @NodeType)
SET @Retval = @@IDENTITY
DECLARE @ForumId int, @ContainerKey nvarchar(50), @IncidentId int
SELECT @ForumId = ForumId FROM fsc_ForumThreads WHERE ThreadId = @ThreadId
SELECT @ContainerKey = ContainerKey FROM fsc_Forums WHERE ForumId = @ForumId
IF LEFT(@ContainerKey, 11) = 'IncidentId_'
BEGIN
	SET @IncidentId = CAST(REPLACE(@ContainerKey, 'IncidentId_', '') as int)
	UPDATE INCIDENTS SET ModifiedDate = getutcdate() WHERE IncidentId = @IncidentId
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_ForumThreadNodeSimpleCreate]'
GO
ALTER PROCEDURE [dbo].fsc_ForumThreadNodeSimpleCreate
@ContainerKey nvarchar(50),
@Text ntext,
@Created datetime,
@CreatorId int,
@CreatorName nvarchar(255),
@CreatorEmail nvarchar(50),
@EMailMessageId int,
@NodeType int,
@Retval int out
AS
DECLARE @ForumId INT
DECLARE @ThreadId INT
BEGIN TRAN
SET @ForumId = (SELECT TOP 1 ForumId FROM fsc_Forums WHERE ContainerKey = @ContainerKey)
IF @ForumId IS NULL
BEGIN
	EXEC fsc_ForumCreate @ContainerKey, 'Default', 'Auto-generated forum', @Created, @ForumId OUTPUT
	IF @@ERROR<>0 GOTO ERR
END
SET @ThreadId = (SELECT TOP 1 ThreadId FROM fsc_ForumThreads WHERE ForumId = @ForumId)
IF @ThreadId IS NULL
BEGIN
	EXEC fsc_ForumThreadCreate @ForumId, 'Default', @Created, @ThreadId OUTPUT
	IF @@ERROR<>0 GOTO ERR
END
INSERT INTO [fsc_ForumThreadNodes]([ThreadId], [Text], [Created], [CreatorId], [CreatorName], [CreatorEmail], EMailMessageId, NodeType)
VALUES(@ThreadId, @Text, @Created, @CreatorId, @CreatorName, @CreatorEmail, @EMailMessageId, @NodeType)
IF @@ERROR<>0 GOTO ERR
SET @Retval = @@IDENTITY
IF LEFT(@ContainerKey, 11) = 'IncidentId_'
BEGIN
	DECLARE @IncidentId int
	SET @IncidentId = CAST(REPLACE(@ContainerKey, 'IncidentId_', '') as int)
	UPDATE INCIDENTS SET ModifiedDate = getutcdate() WHERE IncidentId = @IncidentId
	IF @@ERROR<>0 GOTO ERR
END
COMMIT TRAN
RETURN
ERR:
ROLLBACK TRAN
RETURN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentCreate]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].IncidentCreate
	@ProjectId as int=null ,
	@CreatorId as int ,
	@Title as nvarchar(255) ,
	@Description as ntext,
	@CreationDate as datetime ,
	@TypeId as int ,
	@PriorityId as int ,
	@StateId as int ,
	@SeverityId as int ,
	@IsEmail as bit,
	@TaskTime int,
	@IncidentBoxId int,
	@ResponsibleId int,
	@IsResponsibleGroup int,
	@VCardId int,
	@OrgId int,
	@ExpectedDuration int,
	@ExpectedResponseTime int,
	@Identifier nvarchar(255) = NULL,
	@retval int output
as
IF @IncidentBoxId < 0
	SET @IncidentBoxId = null
IF @VCardId < 0
	SET @VCardId = null
IF @OrgId < 0
	SET @OrgId = null
DECLARE @CalendarId int, @ExpectedResponseDate datetime, @ExpectedResolveDate datetime
SELECT @CalendarId = CalendarId FROM IncidentBox WHERE IncidentBoxId = @IncidentBoxId
IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
        SET @CalendarId = (SELECT MIN(CalendarId) FROM Calendars)
SET @ExpectedResponseDate = [dbo].GetFinishDateByDuration(@CalendarId, @CreationDate, @ExpectedResponseTime)
SET @ExpectedResolveDate = [dbo].GetFinishDateByDuration(@CalendarId, @CreationDate, @ExpectedDuration)
INSERT INTO INCIDENTS (ProjectId, CreatorId, Title, [Description], CreationDate, TypeId, PriorityId, SeverityId, IsEmail, StateId, TaskTime,
	IncidentBoxId, ResponsibleId, IsResponsibleGroup,  VCardId, OrgId, ExpectedDuration, ExpectedResponseTime, Identifier,
	ModifiedDate, ActualOpenDate, ExpectedResponseDate, ExpectedResolveDate)
  VALUES(@ProjectId, @CreatorId, @Title, @Description, @CreationDate, @TypeId, @PriorityId, @SeverityId, @IsEmail, @StateId, @TaskTime,
	@IncidentBoxId,@ResponsibleId, @IsResponsibleGroup, @VCardId, @OrgId, @ExpectedDuration, @ExpectedResponseTime, @Identifier,
	@CreationDate, @CreationDate, @ExpectedResponseDate, @ExpectedResolveDate)
select @retval = @@identity
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Act_IssueUpdateExpectedValues]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].Act_IssueUpdateExpectedValues
	@IssueId int,
	@ExpectedResponseTime int,
	@ExpectedDuration int,
	@retval int output
AS
UPDATE INCIDENTS
 SET ExpectedResponseTime = @ExpectedResponseTime, ExpectedDuration = @ExpectedDuration
 WHERE IncidentId = @IssueId AND
	(ExpectedResponseTime != @ExpectedResponseTime OR ExpectedDuration != @ExpectedDuration)
SET @retval = @@ROWCOUNT
IF @retval > 0
BEGIN
	DECLARE @CalendarId int, @ExpectedResponseDate datetime, @ExpectedResolveDate datetime, @CreationDate datetime, @ActualOpenDate datetime
	SELECT @CalendarId = B.CalendarId, @CreationDate  = I.CreationDate, @ActualOpenDate = I.ActualOpenDate
	  FROM Incidents I
		JOIN IncidentBox B ON (I.IncidentBoxId = B.IncidentBoxId)
	  WHERE I.IncidentId = @IssueId
	IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
	        SET @CalendarId = (SELECT MIN(CalendarId) FROM Calendars)
	DECLARE @ContainerKey nvarchar(50), @ForumId int, @ThreadId int, @LastInDt datetime
	SET @ContainerKey = 'IncidentId_' + CAST(@IssueId AS varchar(10))
	SELECT @ForumId = ForumId FROM fsc_Forums WHERE ContainerKey = @ContainerKey
	IF @ForumId IS NOT NULL
	BEGIN
		SELECT @ThreadId = ThreadId FROM fsc_ForumThreads WHERE ForumId = @ForumId
		IF @ThreadId IS NOT NULL
		BEGIN
			SELECT @LastInDt = MAX(Created) FROM fsc_ForumThreadNodes WHERE ThreadId = @ThreadId AND NodeType = 1
		END
	END
	IF @LastInDt IS NULL
		SET @LastInDt = @CreationDate
	SET @ExpectedResponseDate = [dbo].GetFinishDateByDuration(@CalendarId, @LastInDt, @ExpectedResponseTime)
	SET @ExpectedResolveDate = [dbo].GetFinishDateByDuration(@CalendarId, @ActualOpenDate, @ExpectedDuration)
	UPDATE INCIDENTS
	 SET ExpectedResponseDate = @ExpectedResponseDate, ExpectedResolveDate = @ExpectedResolveDate
	 WHERE IncidentId = @IssueId
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
UPDATE TODO SET ActualStartDate = CreationDate WHERE StartDate IS NULL AND StateId > 1
UPDATE TODO SET ActualStartDate = StartDate WHERE StartDate IS NOT NULL AND StateId > 1
UPDATE TASKS SET ActualStartDate = StartDate WHERE StateId > 1
GO
SET NOCOUNT ON
DECLARE @IncidentId int, @ContainerKey nvarchar(50), @ForumId int, @ThreadId int, @Dt datetime,
    @CreationDate datetime, @LastInDt datetime, @CalendarId int, @ExpectedResponseTime int, @ExpectedDuration int, @MinCalendarId int
SET @MinCalendarId = (SELECT MIN(CalendarId) FROM Calendars)
DECLARE incident_cursor CURSOR FOR
  SELECT I.IncidentId, I.CreationDate, B.CalendarId, I.ExpectedResponseTime, I.ExpectedDuration
  FROM Incidents I
    JOIN IncidentBox B ON (I.IncidentBoxId = B.IncidentBoxId)
OPEN incident_cursor
FETCH NEXT FROM incident_cursor INTO @IncidentId, @CreationDate, @CalendarId, @ExpectedResponseTime, @ExpectedDuration
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @Dt = NULL
    SET @LastInDt = NULL
    SET @ForumId = NULL
    SET @ThreadId = NULL
    SET @ContainerKey = 'IncidentId_' + CAST(@IncidentId AS varchar(10))
    SELECT @ForumId = ForumId FROM fsc_Forums WHERE ContainerKey = @ContainerKey
    IF @ForumId IS NOT NULL
    BEGIN
        SELECT @ThreadId = ThreadId FROM fsc_ForumThreads WHERE ForumId = @ForumId
        IF @ThreadId IS NOT NULL
        BEGIN
            SELECT @Dt = MAX(Created) FROM fsc_ForumThreadNodes WHERE ThreadId = @ThreadId
            SELECT @LastInDt = MAX(Created) FROM fsc_ForumThreadNodes WHERE ThreadId = @ThreadId AND NodeType = 1
        END
    END
    IF @Dt IS NULL
        SET @Dt = @CreationDate
    IF @LastInDt IS NULL
        SET @LastInDt = @CreationDate
    IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
        SET @CalendarId = @MinCalendarId
    UPDATE Incidents
        SET ModifiedDate = @Dt, ActualOpenDate = @LastInDt,
            ExpectedResponseDate = [dbo].GetFinishDateByDuration(@CalendarId, @LastInDt, @ExpectedResponseTime),
            ExpectedResolveDate = [dbo].GetFinishDateByDuration(@CalendarId, @LastInDt, @ExpectedDuration)
        WHERE IncidentId = @IncidentId
    FETCH NEXT FROM incident_cursor INTO @IncidentId, @CreationDate, @CalendarId, @ExpectedResponseTime, @ExpectedDuration
END
CLOSE incident_cursor
DEALLOCATE incident_cursor
SET NOCOUNT OFF
GO

UPDATE CONTENT_TYPES SET AllowNewWindow = 1 WHERE ContentTypeString LIKE 'image/%' OR ContentTypeString LIKE 'message/%' OR ContentTypeString LIKE 'text/%'
GO
