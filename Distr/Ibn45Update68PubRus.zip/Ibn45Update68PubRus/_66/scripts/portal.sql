SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[ScheduleProcessHandlerTempItemsFill]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ScheduleProcessHandlerTempItemsFill]
AS
	SET NOCOUNT ON
	DECLARE @To DATETIME
	SET @To = getutcdate()
	SELECT V.ValueId, D.DateTypeName, D.ObjectTypeId, V.ObjectId, DATEADD(mi, -H.Lag, V.DateValue) AS Dt, H.HookId, H.HandlerId, H.Params, V.DateValue, H.Lag
	FROM DATE_TYPE_VALUES V WITH (NOLOCK)
		JOIN DATE_TYPE_HOOKS H ON (V.DateTypeId = H.DateTypeId)
		JOIN DATE_TYPES D ON (V.DateTypeId = D.DateTypeId)
	WHERE
		(V.ObjectId = H.ObjectId OR H.ObjectId IS NULL)
		AND
		(DATEADD(mi, -H.Lag, V.DateValue) <= @To )
		AND NOT EXISTS (SELECT * FROM DATE_TYPE_PROCESSED P WHERE V.ValueId = P.ValueId AND H.HookId = P.HookId AND V.DateValue = P.DateValue AND H.Lag = P.Lag)
	ORDER BY Dt
GO
PRINT N'Altering [dbo].[IncidentsGetByFilter]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[IncidentsGetByFilter]
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle, I.IncidentBoxId,B.[Name] as IncidentBoxName,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId
	,U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	INM.NewMessage,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate, I.ModifiedDate, I.ActualOpenDate, I.ActualFinishDate, I.ExpectedResponseDate, I.ExpectedResolveDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,  I.Identifier,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId  OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT  JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
	LEFT JOIN INCIDENT_NEWMESSAGE INM ON I.IncidentId = INM.IncidentId
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND (IsResource = 1 OR IsIncidentResponsible =1)))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND
	(	@Keyword = '%%' OR
		I.Title LIKE @Keyword OR
		I.[Description] LIKE @Keyword OR
		I.Resolution LIKE @Keyword OR
		I.Workaround LIKE @Keyword OR
		CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword OR
		I.IncidentId IN (SELECT IssueID FROM EmailIssueExternalRecipient WHERE Email LIKE @Keyword)
	)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
  ORDER BY ProjectTitle
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[IncidentsGetByFilterGroupedByClient]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[IncidentsGetByFilterGroupedByClient]
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId  as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
DECLARE @Incidents
	TABLE (IncidentId int, ProjectId int, ProjectTitle nvarchar(255), ClientName nvarchar(255), CreatorId int, CreatorName nvarchar(102), ControllerId int, ControllerName nvarchar(102), ManagerId int, ManagerName nvarchar(102),
		ResponsibleId int, ResponsibleName nvarchar(102),IsResponsibleGroup bit, ResponsibleGroupState int, VCardId int, OrgId int,
		Title nvarchar(255), CreationDate DateTime, TypeId int, TypeName nvarchar(50), PriorityId int, PriorityName nvarchar(50),
		StateId int, StateName nvarchar(50), SeverityId int, CanEdit int, CanDelete int, IncidentBoxId int, IncidentBoxName nvarchar(255))
INSERT INTO @Incidents
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId,
	U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId  OR(I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete,
	I.IncidentBoxId, B.[Name] as IncidentBoxName
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND IsResource = 1))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND (	@Keyword = '%%' OR
			I.Title LIKE @Keyword OR
			I.[Description] LIKE @Keyword OR
			I.Resolution LIKE @Keyword OR
			I.Workaround LIKE @Keyword OR
			CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword OR
			I.IncidentId IN (SELECT IssueID FROM EmailIssueExternalRecipient WHERE Email LIKE @Keyword)
		)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
DECLARE @CollapseNonClientIncident bit
SET @CollapseNonClientIncident = 0
IF EXISTS (SELECT * FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE UserId = @UserId AND vCardId = -1 AND OrgId = -1)
	SET @CollapseNonClientIncident = 1
SELECT DISTINCT
	CASE WHEN I.VCardId IS NULL THEN -1 ELSE I.VCardId END AS VCardId,
	CASE WHEN I.OrgId IS NULL THEN -1 ELSE I.OrgId END AS OrgId,
	CAST (1 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	0 AS ProjectId, '' AS ProjectTitle,
	0 as IncidentId, '' as Title, 0 as CreatorId, '' as CreatorName, 0 as ControllerId, '' as ControllerName, 0 as ManagerId, '' as ManagerName,
	0 as ResponsibleId , '' as ResponsibleName ,CAST(0 as bit) as IsResponsibleGroup , 0 as ResponsibleGroupState ,
	NULL as CreationDate, 0 as TypeId, '' as TypeName, -1 as PriorityId, '' as PriorityName, 0 as IncidentBoxId, '' as IncidentBoxName,
	0 as StateId, '' as StateName, 0 as SeverityId, 0 as CanEdit, 0 as CanDelete,
	CASE WHEN
		(CI.OrgId IS NULL AND CI.vCardId IS NULL  AND  (I.OrgId IS NOT NULL OR I.vCardId IS NOT NULL))
		OR
		(I.OrgId IS NULL AND I.vCardId IS NULL AND @CollapseNonClientIncident = 0)
	THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS IsCollapsed
  FROM @Incidents I
		LEFT JOIN COLLAPSED_INCIDENTS_BYCLIENT CI ON ((I.vCardId = CI.vCardId OR I.OrgId = CI.OrgId) AND CI.UserId = @UserId)
UNION ALL
SELECT
	CASE WHEN I.VCardId IS NULL THEN -1 ELSE I.VCardId END AS VCardId,
	CASE WHEN I.OrgId IS NULL THEN -1 ELSE I.OrgId END AS OrgId,
	CAST (0 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	CASE WHEN I.ProjectId IS NULL THEN 0 ELSE I.ProjectId END AS ProjectId,
	CASE WHEN I.ProjectTitle IS NULL THEN '' ELSE I.ProjectTitle END AS ProjectTitle,
	IncidentId, Title, CreatorId, CreatorName, ControllerId, ControllerName,  ManagerId, ManagerName,
	ResponsibleId , ResponsibleName ,IsResponsibleGroup , ResponsibleGroupState ,
	CreationDate, TypeId, TypeName, PriorityId, PriorityName, IncidentBoxId, IncidentBoxName,
	StateId, StateName, SeverityId, CanEdit, CanDelete, CAST(0 as bit) as IsCollapsed
  FROM @Incidents I
		LEFT JOIN COLLAPSED_INCIDENTS_BYCLIENT CI ON ((I.vCardId = CI.vCardId OR I.OrgId = CI.OrgId) AND CI.UserId = @UserId)
  WHERE
	(CI.OrgId IS NULL AND CI.vCardId IS NULL  AND  (I.OrgId IS NOT NULL OR I.vCardId IS NOT NULL))
		OR
		(I.OrgId IS NULL AND I.vCardId IS NULL AND @CollapseNonClientIncident = 0)
ORDER BY ClientName, Title
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[IncidentsGetByFilterGroupedByProject]'
GO
ALTER PROCEDURE [dbo].[IncidentsGetByFilterGroupedByProject]
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId  as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
DECLARE @Incidents
	TABLE (IncidentId int, ProjectId int, ProjectTitle nvarchar(255), ClientName nvarchar(255), CreatorId int, CreatorName nvarchar(102), ControllerId int, ControllerName nvarchar(102), ManagerId int, ManagerName nvarchar(102),
		ResponsibleId int, ResponsibleName nvarchar(102),IsResponsibleGroup bit, ResponsibleGroupState int, VCardId int, OrgId int,
		Title nvarchar(255), CreationDate DateTime, TypeId int, TypeName nvarchar(50), PriorityId int, PriorityName nvarchar(50),
		StateId int, StateName nvarchar(50), SeverityId int, CanEdit int, CanDelete int, IncidentBoxId int, IncidentBoxName nvarchar(255))
INSERT INTO @Incidents
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId
	,U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete,
	I.IncidentBoxId, B.[Name] as IncidentBoxName
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND IsResource = 1))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND (	@Keyword = '%%' OR
			I.Title LIKE @Keyword OR
			I.[Description] LIKE @Keyword OR
			I.Resolution LIKE @Keyword OR
			I.Workaround LIKE @Keyword OR
			CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword OR
			I.IncidentId IN (SELECT IssueID FROM EmailIssueExternalRecipient WHERE Email LIKE @Keyword)
		)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
DECLARE @CollapseNonProjectIncident bit
SET @CollapseNonProjectIncident = 0
IF EXISTS (SELECT * FROM COLLAPSED_INCIDENTS WHERE UserId = @UserId AND ProjectId = -1)
	SET @CollapseNonProjectIncident = 1
SELECT DISTINCT CASE WHEN I.ProjectId IS NULL THEN -1 ELSE I.ProjectId END AS ProjectId,
	CASE WHEN ProjectTitle IS NULL THEN '' ELSE ProjectTitle END AS ProjectTitle,
	0 as IncidentId, '' as Title, 0 as CreatorId, '' as CreatorName, 0 as ControllerId, '' as ControllerName, 0 as ManagerId, '' as ManagerName,
	0 as ResponsibleId , '' as ResponsibleName ,CAST(0 as bit) as IsResponsibleGroup , 0 as ResponsibleGroupState ,0 as VCardId ,0 as OrgId , '' as ClientName,
	NULL as CreationDate, 0 as TypeId, '' as TypeName, -1 as PriorityId, '' as PriorityName, 0 as IncidentBoxId, '' as IncidentBoxName,
	0 as StateId, '' as StateName, 0 as SeverityId, 0 as CanEdit, 0 as CanDelete, CAST (1 as bit) AS IsProject,
	CASE WHEN
		(CI.ProjectId IS NULL  AND I.ProjectId IS NOT NULL)
		OR
		(I.ProjectId IS NULL AND @CollapseNonProjectIncident = 0)
	THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS IsCollapsed
  FROM @Incidents I
		LEFT JOIN COLLAPSED_INCIDENTS CI ON (I.ProjectId = CI.ProjectId AND CI.UserId = @UserId)
UNION ALL
SELECT CASE WHEN I.ProjectId IS NULL THEN -1 ELSE I.ProjectId END AS ProjectId,
	CASE WHEN ProjectTitle IS NULL THEN '' ELSE ProjectTitle END AS ProjectTitle,
	IncidentId, Title, CreatorId, CreatorName, ControllerId, ControllerName,  ManagerId, ManagerName,
	ResponsibleId , ResponsibleName ,IsResponsibleGroup , ResponsibleGroupState , VCardId , OrgId , ClientName,
	CreationDate, TypeId, TypeName, PriorityId, PriorityName, IncidentBoxId, IncidentBoxName,
	StateId, StateName, SeverityId, CanEdit, CanDelete, CAST (0 as bit) AS IsProject, CAST(0 as bit) as IsCollapsed
  FROM @Incidents I
	LEFT JOIN COLLAPSED_INCIDENTS CI ON (I.ProjectId = CI.ProjectId AND CI.UserId = @UserId)
  WHERE
	(CI.ProjectId IS NULL  AND I.ProjectId IS NOT NULL)
	OR
	(I.ProjectId IS NULL AND @CollapseNonProjectIncident = 0)
ORDER BY ProjectTitle, Title
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[IncidentsGetForResourceView]'
GO
ALTER PROCEDURE [dbo].[IncidentsGetForResourceView]
	@UserId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
 SELECT DISTINCT I.IncidentId AS ItemId, I.Title, B.ManagerId, I.PriorityId, P.PriorityName, 7 AS ItemType, I.CreationDate, I.CreationDate as StartDate,
	I.ActualFinishdate as ActualFinishDate, I.ActualOpenDate as ActualStartDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	0 as ReasonId, I.ProjectId, PR.Title as ProjectTitle, I.StateId, 0 as CompletionTypeId,  I.Identifier
  FROM INCIDENTS I
	 LEFT JOIN PROJECTS PR ON I.ProjectId=PR.ProjectId
	JOIN INCIDENT_SECURITY_ALL ISS ON (I.IncidentId = ISS.IncidentId  AND ISS.PrincipalId = @UserId)
	 JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
  WHERE
	(@ManagerId=0 OR B.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND (@OrgId=0 OR I.OrgId=@OrgId)
	AND (@VCardId=0 OR I.VCardId=@VCardId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
	AND
	(I.ResponsibleId = @UserId OR ISS.IsRealIncidentResource=1)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
PRINT N'Creating index [IX_DATE_TYPE_PROCESSED_2] on [dbo].[DATE_TYPE_PROCESSED]'
GO
CREATE NONCLUSTERED INDEX [IX_DATE_TYPE_PROCESSED_2] ON [dbo].[DATE_TYPE_PROCESSED] ([ValueId], [HookId], [DateValue], [Lag]) ON [PRIMARY]
GO
