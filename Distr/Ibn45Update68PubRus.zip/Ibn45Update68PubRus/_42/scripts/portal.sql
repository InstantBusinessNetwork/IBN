SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[Act_IssueUpdateState]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].Act_IssueUpdateState
	@IssueId int,
	@ValueId int,
	@retval int output
AS
IF @ValueId = 4 OR @ValueId = 5
	UPDATE INCIDENTS
	 SET StateId = @ValueId, ActualFinishDate = getutcdate()
	 WHERE IncidentId = @IssueId AND StateId != @ValueId
else
	UPDATE INCIDENTS
	 SET StateId = @ValueId, ActualFinishDate = null
	 WHERE IncidentId = @IssueId AND StateId != @ValueId
SET @retval = @@ROWCOUNT
IF @retval > 0 AND (@ValueId = 2 OR @ValueId = 6)
BEGIN
	DECLARE @CalendarId int, @ExpectedResolveDate datetime, @ExpectedDuration int
	SELECT @CalendarId = B.CalendarId, @ExpectedDuration = I.ExpectedDuration
	  FROM Incidents I
		JOIN IncidentBox B ON (I.IncidentBoxId = B.IncidentBoxId)
	  WHERE I.IncidentId = @IssueId
	IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
	        SET @CalendarId = (SELECT MIN(CalendarId) FROM Calendars)
	SET @ExpectedResolveDate = [dbo].GetFinishDateByDuration(@CalendarId, getutcdate(), @ExpectedDuration)
	UPDATE INCIDENTS
		SET ActualOpenDate = getutcdate(), ExpectedResolveDate = @ExpectedResolveDate
		WHERE IncidentId = @IssueId
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
