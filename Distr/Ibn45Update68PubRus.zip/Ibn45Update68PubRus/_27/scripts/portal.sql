SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[IncidentResourcesGetWithResponsible]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].IncidentResourcesGetWithResponsible
	@IncidentId as int
as
SELECT IR.IncidentId, IR.PrincipalId, P.IsGroup, CAST (0 AS bit) AS IsResponsible, U.FirstName, U.LastName
  FROM INCIDENT_RESOURCES IR
	JOIN PRINCIPALS P ON (IR.PrincipalId = P.PrincipalId)
	LEFT JOIN USERS U ON (IR.PrincipalId = U.PrincipalId)
  WHERE IR.IncidentId = @IncidentId AND IR.IsResponsible = 0
	AND (NOT (MustBeConfirmed = 1 AND ResponsePending = 0 AND IsConfirmed = 0 ))
UNION ALL
SELECT I.IncidentId, I.ResponsibleId AS PrincipalId, P.IsGroup, CAST (1 AS bit)  AS IsResponsible, U.FirstName, U.LastName
  FROM INCIDENTS I
	JOIN PRINCIPALS P ON (I.ResponsibleId = P.PrincipalId)
	LEFT JOIN USERS U ON (I.ResponsibleId = U.PrincipalId)
  WHERE I.IncidentId = @IncidentId AND I.ResponsibleId IS NOT NULL
ORDER BY U.FirstName, U.LastName
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[GroupDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].GroupDelete
	@GroupId as int
as
DECLARE @GroupType int
SET @GroupType = 2
BEGIN TRAN
	DELETE FROM BroadCastRecipients WHERE GroupId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM EVENT_RESOURCES WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM INCIDENT_RESOURCES WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM PARTNER_GROUP WHERE GroupId = @GroupId OR PartnerId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM HISTORY WHERE ObjectId = @GroupId AND ObjectTypeId = @GroupType
	IF @@ERROR != 0
		GOTO err
	DELETE LIST_ACCESS WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM GROUPS WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM PRINCIPALS WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[OrganizationDelete]'
GO
ALTER PROCEDURE [dbo].OrganizationDelete
	@OrgId as int
as
DECLARE @ObjectType int
SET @ObjectType = 21
DELETE FROM TAGS WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM COLLAPSED_PROJECTS WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_TODO_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM ORGANIZATIONS WHERE OrgId = @OrgId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_VCardDelete]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[mc_VCardDelete]
(
@VCardId int
)
AS
    SET NOCOUNT ON
DECLARE @ObjectType int
SET @ObjectType = 22
DELETE FROM TAGS WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM COLLAPSED_PROJECTS WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_TODO_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM [VCard] WHERE [VCardId] = @VCardId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[UserDelete]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].UserDelete
	@UserId as int
as
DECLARE @BatchAlertType int
SET @BatchAlertType = 9
DECLARE @UserType int
SET @UserType = 1
BEGIN TRAN
	DELETE COLLAPSED_TASKS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_ACCOUNTS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_INCIDENTS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_DOCUMENTS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_USERTIMESHEETS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_MANAGERTIMESHEETS WHERE UserId = @UserId OR ManagerId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_PROJECT_TEAM WHERE MemberId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_PROJECT_TEAM WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE CONTAINERSHIP WHERE PrincipalId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE SCHEDULE WHERE UserId = @UserId OR ContUserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE SHARING WHERE UserId = @UserId OR ProUserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE DateTypeId = @BatchAlertType AND ObjectId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE TIMESHEET_TODO WHERE TimesheetToDoId IN
		(SELECT ObjectId FROM TIMESHEETS T WHERE T.ObjectTypeId = 11 AND WeekTimeSheetId IN
			(SELECT WeekTimeSheetId FROM WeekTimeSheet WHERE UserId = @UserId))
	IF @@ERROR != 0
		GOTO err
	DELETE TIMESHEETS WHERE WeekTimeSheetId IN (SELECT WeekTimeSheetId FROM WeekTimeSheet WHERE UserId = @UserId)
	IF @@ERROR != 0
		GOTO err
	DELETE WeekTimeSheet WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE STUBS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE BroadCastMessages WHERE CreatorId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE PORTAL_LOGINS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	UPDATE SYSTEM_EVENTS SET UserId = NULL WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE LIST_ACCESS WHERE PrincipalId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @UserType AND ObjectId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @UserType AND ObjectId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_GROUP WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_SETTINGS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_PREFERENCES WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_DETAILS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USERS WHERE PrincipalId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE PRINCIPALS WHERE PrincipalId = @UserId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ProjectDelete]'
GO
ALTER PROCEDURE [dbo].ProjectDelete
	@ProjectId as int
as
DECLARE @ProjectObjectType int
SET @ProjectObjectType = 3
BEGIN TRAN
	DELETE DISCUSSIONS WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE PROJECT_MEMBERS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_INCIDENTS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_DOCUMENTS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_USERTIMESHEETS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE PROJECT_SNAPSHOTS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE ACTUAL_FINANCES WHERE AccountId IN (SELECT AccountId FROM ACCOUNTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE ACCOUNTS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId = @ProjectId AND EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @ProjectObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE REMINDER_SUBSCRIPTIONS WHERE ObjectId = @ProjectId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @ProjectObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE ObjectId = @ProjectId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @ProjectObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_HOOKS WHERE ObjectId = @ProjectId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @ProjectObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE PROJECT_RELATIONS WHERE ProjectId = @ProjectId OR RelProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM PROJECTS  WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetForManagerView]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].IncidentsGetForManagerView
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
SELECT I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, 7 AS ItemType, I.CreationDate,
	I.CreationDate as StartDate, I.ActualFinishdate as FinishDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, B.ManagerId,  I.Identifier
  FROM INCIDENTS I, PRIORITY_LANGUAGE P, INCIDENTBOX B
  WHERE I.IncidentBoxId = B.IncidentBoxId AND
	I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId AND
	(@ManagerId=0 OR B.ManagerId=@ManagerId) AND
	(@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
	AND
	(
		@PrincipalId = 1
	OR
		IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE IsRealIncidentResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
		OR (ResponsibleId = @PrincipalId OR ResponsibleId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
	)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fsc_DirectoryPurge]'
GO
CREATE PROCEDURE [dbo].fsc_DirectoryPurge
AS
DECLARE @ContainerKey nvarchar(50), @Prefix nvarchar(50)
DECLARE @ObjectId int, @PrefixLen int, @DirectoryId int
DECLARE dir_cursor CURSOR FOR
	SELECT ContainerKey, DirectoryId
	  FROM fsc_Directories
	  WHERE ParentDirectoryId IS NULL
	  ORDER BY ContainerKey
OPEN dir_cursor
FETCH NEXT FROM dir_cursor INTO @ContainerKey, @DirectoryId
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @Prefix = 'ProjectId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM PROJECTS WHERE ProjectId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'EventId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM EVENTS WHERE EventId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'TaskId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM TASKS WHERE TaskId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'ToDoId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM TODO WHERE ToDoId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'IncidentId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM INCIDENTS WHERE IncidentId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'DocumentId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM DOCUMENTS WHERE DocumentId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'DocumentVers_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM DOCUMENTS WHERE DocumentId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'Pop3MailRequestId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM Pop3MailRequests WHERE Pop3MailRequestId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'ForumNodeId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM fsc_ForumThreadNodes WHERE NodeId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	SET @Prefix = 'ArticleId_'
	SET @PrefixLen = LEN(@Prefix)
	IF LEFT(@ContainerKey, @PrefixLen) = @Prefix
	BEGIN
		SET @ObjectId = CAST(SUBSTRING(@ContainerKey, @PrefixLen + 1, 10) as int)
		IF NOT EXISTS(SELECT * FROM Articles WHERE ArticleId = @ObjectId)
			EXEC fsc_DirectoryDelete @DirectoryId
	END
	FETCH NEXT FROM dir_cursor INTO @ContainerKey, @DirectoryId
END
CLOSE dir_cursor
DEALLOCATE dir_cursor
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetByFilter]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].IncidentsGetByFilter
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle, I.IncidentBoxId,B.[Name] as IncidentBoxName,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId
	,U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	INM.NewMessage,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,  I.Identifier,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId  OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT  JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
	LEFT JOIN INCIDENT_NEWMESSAGE INM ON I.IncidentId = INM.IncidentId
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND (IsResource = 1 OR IsIncidentResponsible =1)))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND (I.Title LIKE @Keyword OR I.[Description] LIKE @Keyword OR I.Resolution LIKE @Keyword OR I.Workaround LIKE @Keyword OR CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
  ORDER BY ProjectTitle
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ObjectsGetForManagerViewGroupedByUser]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].ObjectsGetForManagerViewGroupedByUser
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
DECLARE @EventType int
SET @EventType = 4
SELECT U.PrincipalId, U.FirstName, U.LastName, 5 AS ItemType, T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate, T.PercentCompleted, T.IsCompleted,
	PR.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN TASK_SECURITY TS ON (U.PrincipalId = TS.PrincipalId)
	JOIN TASKS T ON (TS.TaskId = T.TaskId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN PROJECTS PR ON (T.ProjectId=PR.ProjectId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND(TS.IsRealTaskResource=1)
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 6 AS ItemType, T.TodoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate, T.PercentCompleted, T.IsCompleted,
	T.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN TODO_SECURITY_ALL TS ON (U.PrincipalId = TS.PrincipalId)
	JOIN TODO T ON (TS.TodoId = T.TodoId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (TS.IsResource=1)
	AND (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 7 AS ItemType, I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, I.CreationDate, I.CreationDate as StartDate,
	I.ActualFinishdate as FinishDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	B.ManagerId, 0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN INCIDENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN INCIDENTS I ON (S.IncidentId = I.IncidentId)
	JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealIncidentResource=1 OR S.IsIncidentResponsible = 1)
	AND (@ManagerId=0 OR B.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 4 AS ItemType, E.EventId AS ItemId, E.Title, E.PriorityId, P.PriorityName, E.CreationDate, E.StartDate, E.FinishDate, 0 as PercentCompleted, CAST(0 as bit) as IsCompleted,
	E.ManagerId, 0 as ReasonId, E.ProjectId, E.StateId, 0 as CompletionTypeId,
	CASE WHEN R.RecurrenceId IS NULL THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS HasRecurrence
  FROM Users U
	JOIN EVENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN EVENTS E ON (S.EventId = E.EventId)
	JOIN PRIORITY_LANGUAGE P ON (E.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	LEFT JOIN RECURRENCE R ON (E.EventId = R.ObjectId AND R.ObjectTypeId = @EventType)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsResource=1)
	AND (@ManagerId=0 OR E.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR E.ProjectId=@ProjectId)
	AND
	(
		(
			R.RecurrenceId IS NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.StateId=@UpcomingState)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StateId=@CompletedState)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
		OR
		(
			R.RecurrenceId IS NOT NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.FinishDate>=@dt)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StartDate<=@dt)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 16 AS ItemType, D.DocumentId AS ItemId, D.Title, D.PriorityId, P.PriorityName, D.CreationDate, D.CreationDate as StartDate, D.ClosedDate as FinishDate, 0 as PercentCompleted, D.IsCompleted,
	D.ManagerId, D.ReasonId, D.ProjectId, D.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN DOCUMENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN DOCUMENTS D ON (S.DocumentId = D.DocumentId)
	JOIN PRIORITY_LANGUAGE P ON (D.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealDocumentResource=1)
	AND (@ManagerId=0 OR D.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR D.ProjectId=@ProjectId)
	AND
	(
	((@StartDate is not null)AND(D.CreationDate<=@StartDate)AND(D.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(D.ClosedDate>=@CompletedDate)AND(D.IsCompleted=1))
	OR((@ShowActive=1 AND (D.StateId=@ActiveState OR D.StateId=@OverdueState)))
	)
ORDER BY U.PrincipalId, ItemType, ItemId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
PRINT N'Adding foreign keys to [dbo].[INCIDENT_STATE_LANGUAGE]'
GO
ALTER TABLE [dbo].[INCIDENT_STATE_LANGUAGE] ADD
CONSTRAINT [FK_INCIDENT_STATE_LANGUAGE_LANGUAGES] FOREIGN KEY ([LanguageId]) REFERENCES [dbo].[LANGUAGES] ([LanguageId]) ON DELETE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[Tags]'
GO
ALTER TABLE [dbo].[Tags] ADD
CONSTRAINT [FK_Tags_OBJECT_TYPES] FOREIGN KEY ([ObjectTypeId]) REFERENCES [dbo].[OBJECT_TYPES] ([ObjectTypeId]) ON DELETE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
exec HistoryPurge
GO
exec fsc_DirectoryPurge
GO
