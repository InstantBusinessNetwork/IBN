SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetForManagerView]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ToDoAndTasksGetForManagerView]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @OverdueState as int
set @OverdueState=3
SELECT T.ToDoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 6 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	T.PercentCompleted, T.IsCompleted,
	T.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, T.TaskTime
  FROM TODO T, PRIORITY_LANGUAGE P
  WHERE (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND (@OrgId=0 OR @OrgId = T.OrgId)
	AND (@VCardId=0 OR @VCardId = T.VCardId)
	AND T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
	AND
	(
		@PrincipalId = 1
	OR
		ToDoId IN (SELECT ToDoId FROM TODO_SECURITY_ALL
				WHERE IsResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
 UNION ALL
 SELECT T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 5 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	T.PercentCompleted, T.IsCompleted,
	PR.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, T.TaskTime
  FROM TASKS T,  PRIORITY_LANGUAGE P, PROJECTS PR
  WHERE T.ProjectId=PR.ProjectId
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId OR T.TaskId IN (SELECT TaskId FROM TASK_RESOURCES WHERE PrincipalId = @ManagerId AND CanManage = 1))
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId
	AND @OrgId=0 AND @VCardId=0 AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
	AND
	(
		@PrincipalId = 1
	OR
		TaskId IN (SELECT TaskId FROM TASK_SECURITY
				WHERE IsRealTaskResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
ORDER By ItemType, FinishDate DESC
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
