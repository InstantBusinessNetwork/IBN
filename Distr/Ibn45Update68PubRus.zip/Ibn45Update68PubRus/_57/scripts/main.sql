SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[ASP_SEARCH_HISTORY]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ASP_SEARCH_HISTORY]
	@CompanyId int,
	@User_id int,
	@Cont_user_id int,
	@DT_Begin datetime,
	@DT_End datetime,
	@Mess_Type int,
	@Keyword nvarchar(50),
	@Order int,
	@TimeOffset int
AS
DECLARE @DT_BeginInt int, @DT_EndInt int
SET @DT_BeginInt = DATEDIFF(s, '1970-01-01 00:00', @DT_Begin) + @TimeOffset
SET @DT_EndInt = DATEDIFF(s, '1970-01-01 00:00', @DT_End) + @TimeOffset
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET @Keyword = '%' + RTRIM(LTRIM(@Keyword)) + '%'
IF @Mess_Type = 1 BEGIN
	SELECT TOP 1000 U1.first_name AS FromFirst, U1.last_name AS FromLast, U1.[User_ID] AS FromID, U2.first_name AS ToFirst,  U2.last_name AS ToLast, U2.[User_ID] AS ToID, mess_text, DATEADD(s, Send_Time - @TimeOffset, '1970-01-01 00:00') AS send_time
	 FROM User_Mess M, [User] U1, [User] U2
	 WHERE Send_Time >= @DT_BeginInt AND Send_Time <= @DT_EndInt AND
		M.From_User_id = U1.[user_id] AND M.To_User_id = U2.[user_id] AND
		(
			 (@User_id = 0 OR M.To_User_Id = @User_id)
			AND
			 (@Cont_user_id = 0 OR M.From_User_id = @Cont_user_id)
		OR
			 (@User_id = 0 OR M.From_User_id = @User_id)
			AND
			 (@Cont_user_id = 0 OR M.To_User_Id = @Cont_user_id)
		) AND
		(@Keyword = '%%' OR mess_text LIKE @Keyword) AND (U1.[login] != 'alert') AND (U2.[login] != 'alert')
		AND (U1.[imgroup_id] IN (SELECT imgroup_id FROM IMGroups WHERE Company_id = @CompanyId))
		AND (U2.[imgroup_id] IN (SELECT imgroup_id FROM IMGroups WHERE Company_id = @CompanyId))
	 ORDER BY CASE WHEN @Order = 1 THEN -send_time ELSE send_time END
END
ELSE IF @Mess_Type = 2 BEGIN
	SELECT TOP 1000 U1.first_name AS FromFirst, U1.last_name AS FromLast, U1.[User_ID] AS FromID, U2.first_name AS ToFirst,  U2.last_name AS ToLast, U2.[User_ID] AS ToID, mess_text, DATEADD(s, Send_Time - @TimeOffset, '1970-01-01 00:00') AS send_time
	 FROM User_Mess M, [User] U1, [User] U2
	 WHERE Send_Time >= @DT_BeginInt AND Send_Time <= @DT_EndInt AND
		M.From_User_id = U1.[user_id] AND M.To_User_id = U2.[user_id] AND
		(@User_id = 0 OR M.To_User_Id = @User_id) AND
		(@Cont_user_id = 0 OR M.From_User_id = @Cont_user_id) AND
		(@Keyword = '%%' OR mess_text LIKE @Keyword) AND (U1.[login] != 'alert') AND (U2.[login] != 'alert')
		AND (U1.[imgroup_id] IN (SELECT imgroup_id FROM IMGroups WHERE Company_id = @CompanyId))
		AND (U2.[imgroup_id] IN (SELECT imgroup_id FROM IMGroups WHERE Company_id = @CompanyId))
	 ORDER BY CASE WHEN @Order = 1 THEN -send_time ELSE send_time END
END
ELSE IF @Mess_Type = 3 BEGIN
	SELECT TOP 1000 U1.first_name AS FromFirst, U1.last_name AS FromLast, U1.[User_ID] AS FromID, U2.first_name AS ToFirst,  U2.last_name AS ToLast,  U2.[User_ID] AS ToID, mess_text, DATEADD(s, Send_Time - @TimeOffset, '1970-01-01 00:00') AS send_time
	 FROM User_Mess M, [User] U1, [User] U2
	 WHERE Send_Time >= @DT_BeginInt AND Send_Time <= @DT_EndInt AND
		M.From_User_id = U1.[user_id] AND M.To_User_id = U2.[user_id] AND
		(@User_id = 0 OR M.From_User_id = @User_id) AND
		(@Cont_user_id = 0 OR M.To_User_Id = @Cont_user_id) AND
		(@Keyword = '%%' OR mess_text LIKE @Keyword) AND (U1.[login] != 'alert') AND (U2.[login] != 'alert')
		AND (U1.[imgroup_id] IN (SELECT imgroup_id FROM IMGroups WHERE Company_id = @CompanyId))
		AND (U2.[imgroup_id] IN (SELECT imgroup_id FROM IMGroups WHERE Company_id = @CompanyId))
	 ORDER BY CASE WHEN @Order = 1 THEN -send_time ELSE send_time END
END
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
