SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Dropping foreign keys from [dbo].[fsc_FileBinaries]'
GO
ALTER TABLE [dbo].[fsc_FileBinaries] DROP
CONSTRAINT [FK_fsc_FileBinaries_CONTENT_TYPES]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[WorkSpaceFilesSearchFts]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].WorkSpaceFilesSearchFts
	@UserId INT,
	@ProjectId INT = NULL,
	@ObjectTypeId INT = NULL,
	@ObjectId INT = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
DECLARE @FtsString NVARCHAR(300)
SET @FtsString = N'"*'+@Keyword+N'*"'
EXEC sp_executesql  N'DECLARE @SelectedContainerKeys TABLE(ContainerKey nvarchar(50) COLLATE database_default)
IF @ProjectId IS NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys SELECT DISTINCT ContainerKey FROM fsc_Directories WITH (NOLOCK)
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 3
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ProjectId_'' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)
		UNION
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO  WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ProjectId_'' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents  WITH (NOLOCK) WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 5
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentVers_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentVers_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId IS NULL
END
SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory
FROM fsc_Files F WITH (NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH (NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N''Read'' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	D.ContainerKey IN (SELECT ContainerKey FROM @SelectedContainerKeys)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE ''%''+@Keyword+''%''
		OR
		CONTAINS(Data, @FtsString)
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)',
N'@UserId INT, @ProjectId INT,	@ObjectTypeId INT,@ObjectId INT,@Keyword nvarchar(255),@ContentType int,@ModifiedFrom DateTime,@ModifiedTo DateTime,@LengthFrom int,	@LengthTo int, 	@FtsString NVARCHAR(300)',
@UserId, @ProjectId,	@ObjectTypeId,	@ObjectId,	@Keyword,	@ContentType,	@ModifiedFrom,	@ModifiedTo,	@LengthFrom,	@LengthTo, 	@FtsString
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[GetFullTextSearchEnabled]'
GO
SET ANSI_NULLS OFF
GO
CREATE FUNCTION [dbo].[GetFullTextSearchEnabled] ()
RETURNS INT AS
BEGIN
	DECLARE @RetVal INT
	SET  @RetVal = (SELECT CASE FULLTEXTSERVICEPROPERTY( 'IsFullTextInstalled' )
	WHEN 1 THEN
		CASE DatabaseProperty (DB_NAME(DB_ID()),  'IsFulltextEnabled')
		WHEN 1 THEN 1
		ELSE 0
		END
	ELSE 0
	END)
	RETURN @RetVal
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[INCIDENT_NEWMESSAGE]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TABLE [dbo].[INCIDENT_NEWMESSAGE]
(
[IncidentNewMessageId] [int] NOT NULL IDENTITY(1, 1),
[IncidentId] [int] NOT NULL,
[NewMessage] [bit] NOT NULL CONSTRAINT [DF_IncidentNewMessage_NewMessage] DEFAULT (1)
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_IncidentNewMessage] on [dbo].[INCIDENT_NEWMESSAGE]'
GO
ALTER TABLE [dbo].[INCIDENT_NEWMESSAGE] ADD CONSTRAINT [PK_IncidentNewMessage] PRIMARY KEY CLUSTERED  ([IncidentNewMessageId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_INCIDENT_NEWMESSAGE] on [dbo].[INCIDENT_NEWMESSAGE]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_INCIDENT_NEWMESSAGE] ON [dbo].[INCIDENT_NEWMESSAGE] ([IncidentId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[GroupsGetForMove]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].GroupsGetForMove
	@GroupId as int
as
DECLARE @PartnerGroupId int
SET @PartnerGroupId = 6
Declare @cur_group_id as int
Declare @child_group_id as int
Declare @parent_group_id as int
Declare @cur_group_name as nvarchar(100)
BEGIN TRAN
	Declare Cur_Group Cursor For
	Select [PrincipalID], [GroupName] From Groups Where ([PrincipalId] >= 9) AND [PrincipalId] <>@GroupId
		AND PrincipalID NOT IN (SELECT PrincipalId FROM CONTAINERSHIP WHERE ParentPrincipalId = @PartnerGroupId)
	Open Cur_Group
	Create Table #Temp
	(
		[GroupID] int,
		[GroupName] nvarchar(100)
	)
	Fetch Next From Cur_Group Into @cur_group_id, @cur_group_name
		While @@Fetch_Status = 0
		Begin
			set @child_group_id = @cur_group_id
			Select @parent_group_id=[ParentPrincipalId] From Containership
				Where [PrincipalId]=@child_group_id
			While(@@rowcount>0)AND(@parent_group_id<>1)AND(@parent_group_id<>@GroupId)
			Begin
				set @child_group_id=@parent_group_id
				Select @parent_group_id=[ParentPrincipalId] From Containership
						Where [PrincipalId]=@child_group_id
			End
			If @parent_group_id<>@GroupId
			Begin
				Insert Into #Temp
					([GroupID], [GroupName])
					Values (@cur_group_id, @cur_group_name)
				If @@error <> 0
					Goto ErrorLabel
			End
			Fetch Next From Cur_Group Into @cur_group_id, @cur_group_name
		End
		Close Cur_Group
		Deallocate Cur_Group
	SELECT GroupId, GroupName  FROM #Temp
	Drop Table #Temp
COMMIT TRAN
RETURN
ErrorLabel:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[IncidentNewMessageSet]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].[IncidentNewMessageSet]
	@IncidentId int,
	@NewMessage bit
AS
	BEGIN TRAN
	IF EXISTS(SELECT * FROM INCIDENT_NEWMESSAGE WHERE IncidentId = @IncidentId)
		UPDATE INCIDENT_NEWMESSAGE SET NewMessage = @NewMessage WHERE IncidentId = @IncidentId
	ELSE
		INSERT INTO INCIDENT_NEWMESSAGE (IncidentId, NewMessage) VALUES (@IncidentId, @NewMessage)
	COMMIT TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fsc_FilesSearchFts]'
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].fsc_FilesSearchFts
	@UserId INT,
	@ContainerKey nvarchar(50) = NULL,
	@DirectoryId int = NULL,
	@Deep bit = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
DECLARE @FtsString NVARCHAR(300)
SET @FtsString = N'"*'+@Keyword+N'*"'
EXEC sp_executesql  N'SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory
FROM fsc_Files F WITH(NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH(NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N''Read'' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	(
		@ContainerKey IS NULL
		OR
		D.ContainerKey = @ContainerKey
	)
	AND
	(
		@DirectoryId IS NULL
		OR
		@Deep = 1
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Deep IS NULL
		OR
		@DirectoryId IS NULL
		OR
		@Deep = 0
		OR
		F.DirectoryId IN (SELECT DD.DirectoryId From fsc_Directories DD WHERE DD.Path LIKE (''%.'' + CAST(@DirectoryId AS VARCHAR(10)) + ''.%''))
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE ''%''+@Keyword+''%''
		OR
		CONTAINS(Data, @FtsString)
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)',
N'@UserId INT, 	@ContainerKey nvarchar(50), @DirectoryId int, @Deep bit,
	@Keyword nvarchar(255) ,
	@ContentType int = NULL,
	@ModifiedFrom DateTime,
	@ModifiedTo DateTime,
	@LengthFrom int,
	@LengthTo int, @FtsString NVARCHAR(300)',
@UserId , 	@ContainerKey , @DirectoryId, @Deep,
	@Keyword,
	@ContentType,
	@ModifiedFrom,
	@ModifiedTo,
	@LengthFrom,
	@LengthTo, @FtsString
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[INCIDENTS]'
GO
ALTER TABLE [dbo].[INCIDENTS] ADD
[Identifier] [nvarchar] (300) NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_FileBinaries]'
GO
ALTER TABLE [dbo].[fsc_FileBinaries] ADD
[ContentType] [varchar] (10) NOT NULL CONSTRAINT [DF_fsc_FileBinaries_ContentType] DEFAULT ('')
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[EventGetState]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].EventGetState
	@ObjectId INT
AS
SELECT StateId FROM EVENTS WHERE EventId = @ObjectId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetByType]'
GO
ALTER PROCEDURE [dbo].IncidentsGetByType
	@TypeId as int,
	@LanguageId as int
as
DECLARE @ClosedState int
SET @ClosedState = 5
SELECT I.IncidentId, I.Title, I.ProjectId, P.Title AS ProjectName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName,  I.Identifier
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
  WHERE I.StateId != @ClosedState AND TypeId = @TypeId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetHighPriority]'
GO
ALTER PROCEDURE [dbo].IncidentsGetHighPriority
	@LanguageId as int
as
DECLARE @ClosedState int
SET @ClosedState = 5
DECLARE @NormalPriority int
SET @NormalPriority = 500
SELECT I.IncidentId, I.Title, I.ProjectId, P.Title AS ProjectTitle, I.StateId, S.StateName, I.PriorityId, PL.PriorityName, I.CreationDate,  I.Identifier
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN PRIORITY_LANGUAGE PL ON (I.PriorityId = PL.PriorityId AND PL.LanguageId = @LanguageId)
  WHERE I.PriorityId > @NormalPriority AND I.StateId != @ClosedState
  ORDER BY I.PriorityId DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ProjectGetStatus]'
GO
CREATE PROCEDURE [dbo].ProjectGetStatus
	@ObjectId INT
AS
SELECT StatusId FROM PROJECTS WHERE ProjectId = @ObjectId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_FileBinaryCreate]'
GO
ALTER PROCEDURE [dbo].[fsc_FileBinaryCreate]
	@FileId int,
	@ContentTypeId int,
	@retVal int output
AS
	DECLARE @ContentType varchar(10)
	SET @ContentType = (SELECT Extension FROM CONTENT_TYPES WHERE ContentTypeId = @ContentTypeId)
	IF @ContentType IS NULL
		SET @ContentType = ''
	INSERT INTO fsc_FileBinaries(ContentTypeId, ContentType)
	VALUES (@ContentTypeId, @ContentType)
	SELECT @retVal=@@identity
	UPDATE fsc_Files SET FileBinaryId=@retVal WHERE FileId=@FileId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetOpenByProject]'
GO
ALTER PROCEDURE [dbo].IncidentsGetOpenByProject
	@ProjectId as int
as
DECLARE @CompletedState int, @SuspendedSate  int
SET @SuspendedSate = 4
SET @CompletedState = 5
SELECT I.IncidentId, I.Title, I.TypeId, IT.TypeName, I.StateId, B.ManagerId,  I.Identifier
  FROM INCIDENTS I
	JOIN INCIDENT_TYPES IT ON (I.TypeId = IT.TypeId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
  WHERE I.ProjectId = @ProjectId AND I.StateId != @CompletedState AND I.StateId != @SuspendedSate
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentCreate]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].IncidentCreate
	@ProjectId as int=null ,
	@CreatorId as int ,
	@Title as nvarchar(255) ,
	@Description as ntext,
	@CreationDate as datetime ,
	@TypeId as int ,
	@PriorityId as int ,
	@StateId as int ,
	@SeverityId as int ,
	@IsEmail as bit,
	@TaskTime int,
	@IncidentBoxId int,
	@ResponsibleId int,
	@IsResponsibleGroup int,
	@VCardId int,
	@OrgId int,
	@ExpectedDuration int,
	@ExpectedResponseTime int,
	@Identifier nvarchar(255) = NULL,
	@retval int output
as
IF @IncidentBoxId < 0
	SET @IncidentBoxId = null
IF @VCardId < 0
	SET @VCardId = null
IF @OrgId < 0
	SET @OrgId = null
INSERT INTO INCIDENTS (ProjectId, CreatorId, Title, [Description], CreationDate, TypeId, PriorityId, SeverityId, IsEmail, StateId, TaskTime,
	IncidentBoxId, ResponsibleId, IsResponsibleGroup,  VCardId, OrgId, ExpectedDuration, ExpectedResponseTime, Identifier)
  VALUES(@ProjectId, @CreatorId, @Title, @Description, @CreationDate, @TypeId, @PriorityId, @SeverityId, @IsEmail, @StateId, @TaskTime,
	@IncidentBoxId,@ResponsibleId, @IsResponsibleGroup, @VCardId, @OrgId, @ExpectedDuration, @ExpectedResponseTime, @Identifier)
select @retval = @@identity
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DiscussionDelete]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].DiscussionDelete
	@DiscussionId as int
AS
DELETE DISCUSSIONS
  WHERE DiscussionId = @DiscussionId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_IncidentUserTicketListByUID]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[mc_IncidentUserTicketListByUID]
(
@UID uniqueidentifier
)
AS
    SET NOCOUNT ON
UPDATE IncidentUserTicket SET Created = getutcdate() WHERE [UID] = @UID
SELECT [IncidentUserTicketId],
[UID],
[UserId],
[IncidentId],
[Created] FROM IncidentUserTicket
WHERE
[UID] = @UID
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TaskGetState]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].TaskGetState
	@ObjectId INT
AS
SELECT StateId FROM TASKS WHERE TaskId = @ObjectId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[IncidentUpdateIdentifier]'
GO
CREATE PROCEDURE [dbo].[IncidentUpdateIdentifier]
	@IncidentId int,
	@Identifier varchar(300)
AS
	UPDATE INCIDENTS SET Identifier = @Identifier WHERE IncidentId = @IncidentId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ToDoGetState]'
GO
CREATE PROCEDURE [dbo].ToDoGetState
	@ObjectId INT
AS
SELECT StateId FROM TODO WHERE TodoId = @ObjectId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetByState]'
GO
ALTER PROCEDURE [dbo].IncidentsGetByState
	@ProjectId as int,
	@StateId as int,
	@LanguageId as int
as
SELECT I.IncidentId, I.Title, I.ProjectId, P.Title AS ProjectName, I.PriorityId, PR.PriorityName, I.TypeId, T.TypeName, I.CreationDate, I.Identifier
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
  WHERE I.StateId = @StateId
	AND (@ProjectId = 0 OR I.ProjectId = @ProjectId)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetByCategory]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].IncidentsGetByCategory
	@CategoryId as int,
	@LanguageId as int
as
DECLARE @ClosedState int
SET @ClosedState = 5
DECLARE @IncidentType int
SET @IncidentType = 7
SELECT I.IncidentId, I.Title, I.ProjectId, P.Title AS ProjectName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.StateId, I.Identifier
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
  WHERE I.StateId != @ClosedState AND IncidentId IN
	(SELECT ObjectId FROM OBJECT_CATEGORY WHERE ObjectTypeId = @IncidentType AND CategoryId = @CategoryId)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetNotAssigned]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE dbo.IncidentsGetNotAssigned
	@ProjectId as int,
	@UserId as int,
	@LanguageId as int
as
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
SELECT I.IncidentId, I.Title, I.PriorityId, PR.PriorityName, I.StateId, SL.StateName, I.CreationDate, I.CreatorId,  I.Identifier
  FROM INCIDENTS I
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_STATE_LANGUAGE SL ON (I.StateId = SL.StateId AND SL.LanguageId = @LanguageId)
	JOIN IncidentBox B ON I.IncidentBoxId = B.IncidentBoxId
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId)
	AND (I.StateId = @NewState OR I.StateId = @ActiveState OR  I.StateId = @ReOpenState)
	AND  (I.ResponsibleId <= 0
			AND NOT EXISTS(SELECT * FROM INCIDENT_RESOURCES IR WHERE IR.IsResponsible = 1 AND IR.ResponsePending = 1 AND IR.IncidentId = I.IncidentId)
			AND NOT EXISTS(SELECT * FROM INCIDENT_TODO ITD , TODO T WHERE ITD.IncidentId = I.IncidentId AND ITD.ToDoId = T.ToDoId AND T.IsCompleted = 0)
			AND NOT EXISTS(SELECT * FROM INCIDENT_RESOURCES IR1 WHERE ((IR1.MustBeConfirmed = 0 OR IR1.ResponsePending = 1 OR (IR1.MustBeConfirmed = 1 AND IR1.ResponsePending = 0 AND IR1.IsConfirmed = 1)) AND IR1.IsResponsible =0 AND IR1.IncidentId = I.IncidentId))
		)
	AND (@UserId = B.ManagerId OR  @IsHDM = 1)
  ORDER BY CreationDate DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentGet]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].IncidentGet
	@IncidentId as int,
	@LanguageId as int
as
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle, I.CreatorId, I.Title, I.[Description], I.Resolution, I.Workaround,
	I.CreationDate, I.TypeId, IT.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId, SV.SeverityName,
	I.IsEmail, I.MailSenderEmail, I.TaskTime, I.IncidentBoxId, I.OrgId, I.VCardId, ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.ExpectedDuration, I.ExpectedResponseTime, I.ActualFinishDate, I.ResponsibleId, I.IsResponsibleGroup, I.Identifier,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId,
	(SELECT
	CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
	END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN INCIDENT_TYPES IT ON (I.TypeId = IT.TypeId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN INCIDENT_SEVERITY SV ON (I.SeverityId = SV.SeverityId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
  WHERE I.IncidentId = @IncidentId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_FilesSearch]'
GO
ALTER PROCEDURE [dbo].fsc_FilesSearch
	@UserId INT,
	@ContainerKey nvarchar(50) = NULL,
	@DirectoryId int = NULL,
	@Deep bit = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
IF  [dbo].[GetFullTextSearchEnabled] () = 1
BEGIN
	EXEC [dbo].fsc_FilesSearchFts @UserId, @ContainerKey, @DirectoryId, @DirectoryId, @Keyword, @ContentType, @ModifiedFrom, @ModifiedTo, @LengthFrom, @LengthTo
	RETURN
END
SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory
FROM fsc_Files F WITH(NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH(NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N'Read' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	(
		@ContainerKey IS NULL
		OR
		D.ContainerKey = @ContainerKey
	)
	AND
	(
		@DirectoryId IS NULL
		OR
		@Deep = 1
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Deep IS NULL
		OR
		@DirectoryId IS NULL
		OR
		@Deep = 0
		OR
		F.DirectoryId IN (SELECT DD.DirectoryId From fsc_Directories DD WHERE DD.Path LIKE ('%.' + CAST(@DirectoryId AS VARCHAR(10)) + '.%'))
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE '%'+@Keyword+'%'
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetForResourceView]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].IncidentsGetForResourceView
	@UserId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
 SELECT DISTINCT I.IncidentId AS ItemId, I.Title, B.ManagerId, I.PriorityId, P.PriorityName, 7 AS ItemType, I.CreationDate, I.CreationDate as StartDate,
	I.ActualFinishdate as FinishDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	0 as ReasonId, I.ProjectId, PR.Title as ProjectTitle, I.StateId, 0 as CompletionTypeId,  I.Identifier
  FROM INCIDENTS I
	 LEFT JOIN PROJECTS PR ON I.ProjectId=PR.ProjectId
	JOIN INCIDENT_SECURITY_ALL ISS ON (I.IncidentId = ISS.IncidentId  AND ISS.PrincipalId = @UserId)
	 JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	JOIN INCIDENT_RESOURCES IR ON (I.IncidentId = IR.IncidentId AND IR.PrincipalId = @UserId)
  WHERE
	(@ManagerId=0 OR B.ManagerId=@ManagerId)
	AND
	(@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
	AND
	(I.ResponsibleId = @UserId OR ISS.IsRealIncidentResource=1)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetForManagerView]'
GO
ALTER PROCEDURE [dbo].IncidentsGetForManagerView
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
SELECT I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, 7 AS ItemType, I.CreationDate,
	I.CreationDate as StartDate, I.ActualFinishdate as FinishDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, B.ManagerId,  I.Identifier
  FROM INCIDENTS I, PRIORITY_LANGUAGE P, INCIDENTBOX B
  WHERE I.IncidentBoxId = B.IncidentBoxId AND
	I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId AND
	(@ManagerId=0 OR B.ManagerId=@ManagerId) AND
	(@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
	AND
	(
		@PrincipalId = 1
	OR
		IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE IsRealIncidentResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetSimple]'
GO
ALTER PROCEDURE [dbo].IncidentsGetSimple
	@ProjectId as int,
	@UserId as int
as
SELECT I.IncidentId, I.Title,  I.Identifier
  FROM INCIDENTS I
	JOIN INCIDENT_SECURITY_ALL  IA ON (IA.IncidentId = I.IncidentId AND IA.PrincipalId = @UserId)
  WHERE (@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND ProjectId IS NULL))
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetOpenByUserOnly]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].IncidentsGetOpenByUserOnly
	@UserId as int,
	@LanguageId as int
AS
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
SELECT I.IncidentId, I.Title, I.CreationDate, I.PriorityId, P.PriorityName, I.CreatorId, A.IsRealIncidentManager AS IsManager,
	A.IsCreator, A.IsRealIncidentResource AS IsResource, I.StateId, S.StateName,  I.Identifier
  FROM INCIDENTS I
	JOIN INCIDENT_STATE_LANGUAGE S ON( I.StateId =  S.StateId AND S.LanguageId = @LanguageId)
	JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENT_SECURITY_ALL A ON(I.IncidentId = A.IncidentId AND A.PrincipalId = @UserId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
  WHERE
	(I.StateId = @NewState AND B.ManagerId = @UserId)
	OR
	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @UserId)
	OR
	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = -1 AND (B.ManagerId = @UserId OR EXISTS(SELECT * FROM INCIDENT_RESOURCES IR WHERE I.IncidentId=IR.IncidentId AND IR.PrincipalId = @UserId AND IsResponsible =1 AND ResponsePending = 1) ))
	OR
	(I.StateId = @OnCheckState  AND @UserId  = (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END))
	OR
	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND IsRealIncidentResource = 1)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[WorkSpaceFilesSearch]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].WorkSpaceFilesSearch
	@UserId INT,
	@ProjectId INT = NULL,
	@ObjectTypeId INT = NULL,
	@ObjectId INT = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
IF  [dbo].[GetFullTextSearchEnabled] () = 1
BEGIN
	EXEC [dbo].WorkSpaceFilesSearchFts @UserId, @ProjectId, @ObjectTypeId, @ObjectId, @Keyword, @ContentType, @ModifiedFrom, @LengthFrom, @LengthTo
	RETURN
END
DECLARE @SelectedContainerKeys TABLE(ContainerKey nvarchar(50) COLLATE database_default)
IF @ProjectId IS NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys SELECT DISTINCT ContainerKey FROM fsc_Directories WITH (NOLOCK)
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 3
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'ProjectId_' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)
		UNION
		SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N'TaskId_' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO  WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'ProjectId_' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'TaskId_' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents  WITH (NOLOCK) WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 5
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'TaskId_' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'DocumentVers_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'DocumentVers_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId IS NULL
END
SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory
FROM fsc_Files F WITH (NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH (NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N'Read' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	D.ContainerKey IN (SELECT ContainerKey FROM @SelectedContainerKeys)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE '%'+@Keyword+'%'
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetByFilter]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].IncidentsGetByFilter
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle, I.IncidentBoxId,B.[Name] as IncidentBoxName,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId
	,U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	INM.NewMessage,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,  I.Identifier,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId  OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT  JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
	LEFT JOIN INCIDENT_NEWMESSAGE INM ON I.IncidentId = INM.IncidentId
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND IsResource = 1))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND (I.Title LIKE @Keyword OR I.[Description] LIKE @Keyword OR I.Resolution LIKE @Keyword OR I.Workaround LIKE @Keyword OR CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
  ORDER BY ProjectTitle
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentsGetByProject]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].IncidentsGetByProject
	@ProjectId as int,
	@UserId as int,
	@LanguageId as int
as
DECLARE @NewState int
DECLARE @ActiveState  int
SET @NewState = 1
SET @ActiveState = 2
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	I.Title, I.CreationDate,
	I.TypeId, IT.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId, SV.SeverityName, I.Identifier,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN IncidentBox B ON I.IncidentBoxId = B.IncidentBoxId
	JOIN INCIDENT_TYPES IT ON (I.TypeId = IT.TypeId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN INCIDENT_SEVERITY SV ON (I.SeverityId = SV.SeverityId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND
	(@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fsc_Locks]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TABLE [dbo].[fsc_Locks]
(
[ItemID] [int] NOT NULL,
[Token] [char] (36) NOT NULL,
[Expires] [datetime] NULL,
[Owner] [nvarchar] (255) NOT NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_fsc_Locks] on [dbo].[fsc_Locks]'
GO
ALTER TABLE [dbo].[fsc_Locks] ADD CONSTRAINT [PK_fsc_Locks] PRIMARY KEY CLUSTERED  ([Token])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fsc_FullTextSearchActivate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].fsc_FullTextSearchActivate
	@Language int = 1049
AS
	exec sp_fulltext_database 'enable'
	exec sp_fulltext_catalog 'ibnfts', 'Create'
	exec sp_fulltext_table 'fsc_FileBinaries', 'Create', 'ibnfts', 'PK_fsc_FileBinaries'
	exec sp_fulltext_column 'fsc_FileBinaries', 'Data', 'add', @Language, 'ContentType'
	exec sp_fulltext_table 'fsc_FileBinaries', 'activate'
	exec sp_fulltext_table 'fsc_FileBinaries', 'start_change_tracking'
	exec sp_fulltext_table 'fsc_FileBinaries', 'start_background_updateindex'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fsc_FullTextSearchDeactivate]'
GO
CREATE PROCEDURE [dbo].fsc_FullTextSearchDeactivate
AS
	exec sp_fulltext_table 'fsc_FileBinaries', 'Drop'
	exec sp_fulltext_catalog 'ibnfts', 'Drop'
	exec sp_fulltext_database  'disable'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fsc_FullTextSearchEnabled]'
GO
CREATE PROCEDURE [dbo].fsc_FullTextSearchEnabled
AS
	SELECT CASE FULLTEXTSERVICEPROPERTY( 'IsFullTextInstalled' )
	WHEN 1 THEN
		CASE DatabaseProperty (DB_NAME(DB_ID()),  'IsFulltextEnabled')
		WHEN 1 THEN 1
		ELSE 0
		END
	ELSE 0
	END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fsc_FullTextSearchIsInstalled]'
GO
CREATE PROCEDURE [dbo].fsc_FullTextSearchIsInstalled
AS
	SELECT CASE FULLTEXTSERVICEPROPERTY( 'IsFullTextInstalled' )
	WHEN 1 THEN
		CASE FULLTEXTSERVICEPROPERTY( 'ResourceUsage' )
		WHEN NULL THEN 0
		ELSE 1
		END
	ELSE 0
	END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
PRINT N'Adding foreign keys to [dbo].[INCIDENT_NEWMESSAGE]'
GO
ALTER TABLE [dbo].[INCIDENT_NEWMESSAGE] ADD
CONSTRAINT [FK_IncidentNewMessage_INCIDENTS] FOREIGN KEY ([IncidentId]) REFERENCES [dbo].[INCIDENTS] ([IncidentId]) ON DELETE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
UPDATE fsc_FileBinaries
SET ContentType = CT.Extension
FROM fsc_FileBinaries FB, CONTENT_TYPES CT
WHERE FB.ContentTypeId = CT.ContentTypeId
GO
