SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[Tags]'
GO
CREATE TABLE [dbo].[Tags]
(
[TagId] [int] NOT NULL IDENTITY(1, 1),
[ObjectTypeId] [int] NOT NULL,
[ObjectId] [int] NOT NULL,
[Tag] [nvarchar] (50) NOT NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_Tags] on [dbo].[Tags]'
GO
ALTER TABLE [dbo].[Tags] ADD CONSTRAINT [PK_Tags] PRIMARY KEY CLUSTERED  ([TagId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_Tags] on [dbo].[Tags]'
GO
CREATE NONCLUSTERED INDEX [IX_Tags] ON [dbo].[Tags] ([ObjectTypeId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_Tags_1] on [dbo].[Tags]'
GO
CREATE NONCLUSTERED INDEX [IX_Tags_1] ON [dbo].[Tags] ([ObjectId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_Tags_2] on [dbo].[Tags]'
GO
CREATE NONCLUSTERED INDEX [IX_Tags_2] ON [dbo].[Tags] ([Tag])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TagsDeleteByObject]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].TagsDeleteByObject
	@ObjectTypeId as int,
	@ObjectId as int
AS
DELETE FROM Tags
  WHERE ObjectId = @ObjectId AND ObjectTypeId = @ObjectTypeId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TagsGetForCloudByTag]'
GO
CREATE PROCEDURE [dbo].TagsGetForCloudByTag
	@ObjectTypeId as int,
	@TagSizeCount as int,
	@TagCount as int,
	@Tag nvarchar(50)
as
SET @TagSizeCount = @TagSizeCount - 1
DECLARE @Dummy TABLE ([id] int IDENTITY(1, 1), Tag nvarchar(50), Counter int)
INSERT INTO @Dummy (Tag, Counter)
SELECT Tag, COUNT(Tag) AS Counter
  FROM Tags
  WHERE ObjectTypeId = @ObjectTypeId
	AND ObjectId IN (SELECT ObjectId FROM Tags WHERE ObjectTypeId = @ObjectTypeId AND Tag = @Tag)
  GROUP BY Tag
  ORDER BY Counter DESC
DELETE FROM @Dummy WHERE [id] > @TagCount
DECLARE @MinValue int, @MaxValue int, @Diff decimal
SELECT @MinValue = MIN(Counter), @MaxValue = MAX(Counter)
  FROM @Dummy
SET @Diff = @MaxValue - @MinValue
IF @Diff = 0
	SELECT Tag, 1 AS TagSize
	  FROM @Dummy
	  ORDER BY Tag
ELSE
	SELECT Tag, CAST(ROUND((Counter - @MinValue)/@Diff * @TagSizeCount + 1, 0) AS int) AS TagSize
	  FROM @Dummy
	  ORDER BY Tag
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TagsGetForCloud]'
GO
CREATE PROCEDURE [dbo].TagsGetForCloud
	@ObjectTypeId as int,
	@TagSizeCount as int,
	@TagCount as int
as
SET @TagSizeCount = @TagSizeCount - 1
DECLARE @Dummy TABLE ([id] int IDENTITY(1, 1), Tag nvarchar(50), Counter int)
INSERT INTO @Dummy (Tag, Counter)
SELECT Tag, COUNT(Tag) AS Counter
  FROM Tags
  WHERE ObjectTypeId = @ObjectTypeId
  GROUP BY Tag
  ORDER BY Counter DESC
DELETE FROM @Dummy WHERE [id] > @TagCount
DECLARE @MinValue int, @MaxValue int, @Diff decimal
SELECT @MinValue = MIN(Counter), @MaxValue = MAX(Counter)
  FROM @Dummy
SET @Diff = @MaxValue - @MinValue
IF @Diff = 0
	SELECT Tag, 1 AS TagSize
	  FROM @Dummy
	  ORDER BY Tag
ELSE
	SELECT Tag, CAST(ROUND((Counter - @MinValue)/@Diff * @TagSizeCount + 1, 0) AS int) AS TagSize
	  FROM @Dummy
	  ORDER BY Tag
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TagsAdd]'
GO
CREATE PROCEDURE [dbo].TagsAdd
	@ObjectTypeId as int ,
	@ObjectId as int ,
	@Tag as nvarchar(50) ,
	@retval int output
as
INSERT INTO Tags (ObjectTypeId, ObjectId, Tag)
  VALUES(@ObjectTypeId, @ObjectId, @Tag)
SELECT @retval = @@identity
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PortalConfig]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TABLE [dbo].[PortalConfig]
(
[SettingId] [int] NOT NULL IDENTITY(1, 1),
[Key] [nvarchar] (100) NOT NULL,
[Value] [ntext] NOT NULL CONSTRAINT [DF_PortalConfig_Value] DEFAULT (N'')
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PortalConfig] on [dbo].[PortalConfig]'
GO
ALTER TABLE [dbo].[PortalConfig] ADD CONSTRAINT [PK_PortalConfig] PRIMARY KEY CLUSTERED  ([SettingId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_PortalConfig] on [dbo].[PortalConfig]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_PortalConfig] ON [dbo].[PortalConfig] ([Key])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_PortalConfigUpdate]'
GO
CREATE PROCEDURE [dbo].[mc_PortalConfigUpdate]
(
@SettingId int,
@Key nvarchar(100),
@Value ntext)
AS
    SET NOCOUNT ON
UPDATE [PortalConfig]
SET
[Key] = @Key,
[Value] = @Value
WHERE
[SettingId] = @SettingId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[EMailRouterPop3Box]'
GO
ALTER TABLE [dbo].[EMailRouterPop3Box] ADD
[UseSecureConnection] [int] NOT NULL CONSTRAINT [DF_EMailRouterPop3Box_UseTls] DEFAULT (0)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_EMailRouterPop3BoxUpdate]'
GO
ALTER PROCEDURE [dbo].[mc_EMailRouterPop3BoxUpdate]
(
@EMailRouterPop3BoxId int,
@Name nvarchar(255),
@Server nvarchar(255),
@Port int,
@Login nvarchar(255),
@Pass nvarchar(255),
@IsInternal bit,
@InternalEMailAddress nvarchar(255) = NULL
,
@Settings ntext,
@UseSecureConnection int = 0)
AS
    SET NOCOUNT ON
UPDATE [EMailRouterPop3Box]
SET
[Name] = @Name,
[Server] = @Server,
[Port] = @Port,
[Login] = @Login,
[Pass] = @Pass,
[IsInternal] = @IsInternal,
[InternalEMailAddress] = @InternalEMailAddress,
[Settings] = @Settings,
[UseSecureConnection] = @UseSecureConnection
WHERE
[EMailRouterPop3BoxId] = @EMailRouterPop3BoxId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Articles]'
GO
CREATE TABLE [dbo].[Articles]
(
[ArticleId] [int] NOT NULL IDENTITY(1, 1),
[Question] [nvarchar] (1000) NOT NULL,
[Answer] [ntext] NOT NULL CONSTRAINT [DF_Articles_Answer] DEFAULT (''),
[AnswerHTML] [ntext] NOT NULL CONSTRAINT [DF_Articles_AnswerHTML] DEFAULT (''),
[Tags] [nvarchar] (1000) NOT NULL CONSTRAINT [DF_Articles_Tags] DEFAULT (''),
[Created] [datetime] NOT NULL CONSTRAINT [DF_Articles_Created] DEFAULT (getutcdate()),
[Counter] [int] NOT NULL CONSTRAINT [DF_Articles_Counter] DEFAULT (0),
[Delimeter] [nchar] (1) NOT NULL CONSTRAINT [DF_Articles_Delimeter] DEFAULT (' ')
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_Articles] on [dbo].[Articles]'
GO
ALTER TABLE [dbo].[Articles] ADD CONSTRAINT [PK_Articles] PRIMARY KEY CLUSTERED  ([ArticleId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_Articles] on [dbo].[Articles]'
GO
CREATE NONCLUSTERED INDEX [IX_Articles] ON [dbo].[Articles] ([Created])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_Articles_1] on [dbo].[Articles]'
GO
CREATE NONCLUSTERED INDEX [IX_Articles_1] ON [dbo].[Articles] ([Counter])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ArticlesGetByTag]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].ArticlesGetByTag
	@Tag nvarchar(50)
as
DECLARE @ArticleObjectType int
SET @ArticleObjectType = 20
SELECT ArticleId, Question, Answer, AnswerHTML, Created
  FROM Articles
  WHERE ArticleId IN (SELECT ObjectId FROM Tags WHERE ObjectTypeId = @ArticleObjectType AND Tag = @Tag)
  ORDER BY Created DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_PortalConfigList]'
GO
CREATE PROCEDURE [dbo].[mc_PortalConfigList]
AS
    SET NOCOUNT ON
SELECT [SettingId],
[Key],
[Value] FROM PortalConfig
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_PortalConfigInsert]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[mc_PortalConfigInsert]
(
@SettingId int = NULL OUTPUT
,
@Key nvarchar(100),
@Value ntext)
AS
    SET NOCOUNT ON
INSERT INTO [PortalConfig]
(
[Key],
[Value])
VALUES(
@Key,
@Value)
SELECT @SettingId = SCOPE_IDENTITY();
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_EMailRouterPop3BoxInsert]'
GO
ALTER PROCEDURE [dbo].[mc_EMailRouterPop3BoxInsert]
(
@EMailRouterPop3BoxId int = NULL OUTPUT
,
@Name nvarchar(255),
@Server nvarchar(255),
@Port int,
@Login nvarchar(255),
@Pass nvarchar(255),
@IsInternal bit,
@InternalEMailAddress nvarchar(255) = NULL
,
@Settings ntext,
@UseSecureConnection int =0)
AS
    SET NOCOUNT ON
INSERT INTO [EMailRouterPop3Box]
(
[Name],
[Server],
[Port],
[Login],
[Pass],
[IsInternal],
[InternalEMailAddress],
[Settings],
[UseSecureConnection])
VALUES(
@Name,
@Server,
@Port,
@Login,
@Pass,
@IsInternal,
@InternalEMailAddress,
@Settings,
@UseSecureConnection)
SELECT @EMailRouterPop3BoxId = SCOPE_IDENTITY();
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_EMailRouterPop3BoxSelect]'
GO
ALTER PROCEDURE [dbo].[mc_EMailRouterPop3BoxSelect]
(
@EMailRouterPop3BoxId int
)
AS
    SET NOCOUNT ON
SELECT [EMailRouterPop3BoxId],
[Name],
[Server],
[Port],
[Login],
[Pass],
[IsInternal],
[InternalEMailAddress],
[Settings], [UseSecureConnection] FROM EMailRouterPop3Box
WHERE
[EMailRouterPop3BoxId] = @EMailRouterPop3BoxId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ArticlesDelete]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].ArticlesDelete
	@ArticleId as int
as
DELETE FROM Tags WHERE ObjectTypeId = 20 AND ObjectId = @ArticleId
DELETE FROM Articles  WHERE ArticleId = @ArticleId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_EMailRouterPop3BoxList]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[mc_EMailRouterPop3BoxList]
(
@IsInternal bit
)
AS
    SET NOCOUNT ON
SELECT [EMailRouterPop3BoxId],
[Name],
[Server],
[Port],
[Login],
[Pass],
[IsInternal],
[InternalEMailAddress],
[Settings], [UseSecureConnection] FROM EMailRouterPop3Box
WHERE
[IsInternal] = @IsInternal
ORDER BY [Name]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ArticlesUpdate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE ArticlesUpdate
	@ArticleId int,
	@Question as nvarchar(1000) ,
	@Answer as ntext,
	@AnswerHTML as ntext,
	@Tags as nvarchar(1000)
as
UPDATE Articles
  SET Question=@Question, Answer=@Answer, AnswerHTML=@AnswerHTML, Tags=@Tags
  WHERE ArticleId = @ArticleId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ToDoGetByProject]'
GO
ALTER PROCEDURE [dbo].ToDoGetByProject
	@ProjectId as int,
	@LanguageId as int
as
SELECT T.ToDoId, T.Title, T.[Description], T.StartDate, T.FinishDate,
	T.IsCompleted, T.PercentCompleted, P.PriorityId, P.PriorityName, T.StateId, T.ReasonId
  FROM TODO T
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE ProjectId = @ProjectId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_PortalConfigDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[mc_PortalConfigDelete]
(
@SettingId int
)
AS
    SET NOCOUNT ON
DELETE FROM [PortalConfig]
WHERE
[SettingId] = @SettingId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ArticlesAdd]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE ArticlesAdd
	@Question as nvarchar(1000) ,
	@Answer as ntext,
	@AnswerHTML as ntext,
	@Tags as nvarchar(1000) ,
	@retval int output
as
INSERT INTO Articles (Question, Answer, AnswerHTML, Tags, Created, Counter)
  VALUES(@Question, @Answer, @AnswerHTML, @Tags, GETUTCDATE(), 0)
SELECT @retval = @@identity
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ArticlesGetByUser]'
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].ArticlesGetByUser
	@UserId as int
as
DECLARE @ArticleObjectType int
SET @ArticleObjectType = 20
SELECT ArticleId, Question, Answer, AnswerHTML
  FROM Articles A
	JOIN HISTORY H ON (A.ArticleId = H.ObjectId AND H.ObjectTypeId = @ArticleObjectType)
  WHERE H.UserId = @UserId
  ORDER BY H.Dt DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ArticlesGet]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].ArticlesGet
       @ArticleId as int
as
SELECT ArticleId, Question, Answer, AnswerHTML, Tags, Created, Counter
  FROM Articles
  WHERE @ArticleId=0 OR ArticleId = @ArticleId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_PortalConfigSelectByKey]'
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[mc_PortalConfigSelectByKey]
(
@Key nvarchar(100)
)
AS
    SET NOCOUNT ON
SELECT [SettingId],
[Key],
[Value] FROM PortalConfig
WHERE
[Key] = @Key
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_IncidentBoxCanDelete]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].[mc_IncidentBoxCanDelete]
	@IncindentBoxId int,
	@Retval int output
AS
	IF EXISTS(SELECT * FROM Incidents WHERE IncidentBoxId = @IncindentBoxId)
		SET @Retval = 0
	ELSE
		SET @Retval = 1
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_PortalConfigSelect]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[mc_PortalConfigSelect]
(
@SettingId int
)
AS
    SET NOCOUNT ON
SELECT [SettingId],
[Key],
[Value] FROM PortalConfig
WHERE
[SettingId] = @SettingId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_FullTextSearchActivate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].fsc_FullTextSearchActivate
	@Language int = 0
AS
	exec sp_fulltext_database 'enable'
	exec sp_fulltext_catalog 'ibnfts', 'Create'
	exec sp_fulltext_table 'fsc_FileBinaries', 'Create', 'ibnfts', 'PK_fsc_FileBinaries'
	exec sp_fulltext_column 'fsc_FileBinaries', 'Data', 'add', @Language, 'ContentType'
	exec sp_fulltext_table 'fsc_FileBinaries', 'activate'
	exec sp_fulltext_table 'fsc_FileBinaries', 'start_change_tracking'
	exec sp_fulltext_table 'fsc_FileBinaries', 'start_background_updateindex'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
IF EXISTS(SELECT * FROM [dbo].[SmtpSettings])
BEGIN
	DECLARE @Server nvarchar(100)
	DECLARE @Port nvarchar(100)
	DECLARE @UseTls nvarchar(100)
	DECLARE @Authenticate nvarchar(100)
	DECLARE @User nvarchar(100)
	DECLARE @Password nvarchar(100)
	SELECT TOP 1
	@Server = Server,
	@Port = CAST(Port AS NVARCHAR(100)),
	@UseTls = (CASE UseTls WHEN 1 THEN N'True' ELSE 'False' END),
	@Authenticate = (CASE Authenticate WHEN 1 THEN N'True' ELSE 'False' END),
	@User = [User],
	@Password = [Password]
	FROM [dbo].[SmtpSettings]
	INSERT INTO [dbo].[PortalConfig] ([Key], [Value]) VALUES (N'email.smtp.default', N'False')
	INSERT INTO [dbo].[PortalConfig] ([Key], [Value]) VALUES (N'email.smtp.servername', @Server)
	INSERT INTO [dbo].[PortalConfig] ([Key], [Value]) VALUES (N'email.smtp.serverport', @Port)
	INSERT INTO [dbo].[PortalConfig] ([Key], [Value]) VALUES (N'email.smtp.tls', @UseTls)
	INSERT INTO [dbo].[PortalConfig] ([Key], [Value]) VALUES (N'email.smtp.authenticate', @Authenticate)
	INSERT INTO [dbo].[PortalConfig] ([Key], [Value]) VALUES (N'email.smtp.user', @User)
	INSERT INTO [dbo].[PortalConfig] ([Key], [Value]) VALUES (N'email.smtp.password', @Password)
END
GO
