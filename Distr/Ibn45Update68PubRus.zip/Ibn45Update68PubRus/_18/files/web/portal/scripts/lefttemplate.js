		var timerId = "";
		var lastTime = (new Date()).getTime();

		window.onresize = ResizeIt
		
		function ResizeIt()
		{
			lastTime = (new Date()).getTime();
			
			if (timerId == "")
				timerId = window.setInterval("CheckResize()", 500);	// ��������� ����� ����������
		}
		
		function CheckResize()
		{
			var curTime = (new Date()).getTime();
			
			// ���� ������� ��� ������ 1/10 ���, �� ������� ����������� �������� � ���������� ������
			if (curTime - lastTime > 100)
			{
				window.clearInterval(timerId);
				timerId = "";
				
				_resizing();
			}
		}
		
		
		function _resizing()
		{
			var iheight = document.body.clientHeight;
			var iwidth = document.body.clientWidth;
			if(window.basicNavBar == null)
				setTimeout('_resizing()', 300);
			else 
			{
				var _H = 26 * window.basicNavBar.Items().length;
				if(_H>iheight)
				{
					window.top.resizeBy(0,_H-iheight+200);
					iheight = document.body.clientHeight;
				}
				iheight = iheight - _H;
				iwidth = iwidth - 7;
			
				if(window.basicNavBar == null)
					setTimeout('NavResize()', 300);
				else
					NavResize();
				
				setTimeout('ResizeDivs(' + iwidth +', '+iheight+')', 300);
			}
			var leftimg = document.getElementById("basicNavBar_item_0_ricon");
			if(leftimg!=null)
			{
				leftimg.onclick = function()
				{
					window.top.up.MoveFrame();
				}
			}
		}
		
		function ResizeDivs(iwidth, iheight)
		{
			var objColl = document.getElementsByTagName("div");
			for(var i = 0; i < objColl.length; i++)
			{
				var obj = objColl[i];
				if(obj.id.indexOf("_Tree_div")>0)
				{
					obj.style.height = iheight;
					obj.style.width = iwidth;
				}
				if(obj.id == "divNewAdmin")
				{
					obj.style.height = iheight;
					obj.style.width = iwidth;
				}
			}
		}
		
		function NavResize()
		{
			var	obj = document.getElementById("basicNavBar_div");
			if(obj!=null && window.basicNavBar!=null)
			{
				obj.style.height = document.body.clientHeight;
				obj.style.width = document.body.clientWidth-2;
				//window.basicNavBar.FullExpandHeight = (document.body.clientHeight - (window.basicNavBar.Height - window.basicNavBar.FullExpandHeight));
				window.basicNavBar.FullExpandHeight = document.body.clientHeight - 25 * window.basicNavBar.Items().length;
				window.basicNavBar.Height = document.body.clientHeight;
				window.basicNavBar.Width = document.body.clientWidth-2;
				window.basicNavBar.Render('basicNavBar_div');
			}
		}
		
		function ExpandNodeItem(_id)
		{
			if(window.basicNavBar == null)
			{
				setTimeout("ExpandNodeItem('"+_id+"')", 500);
			}
			else
			{
				var item = window.basicNavBar.FindItemById(_id);
				item.Expand(item);
			}
		}
		
		function OpenWindow(query,w,h,scroll)
		{
			var l = (screen.width - w) / 2;
			var t = (screen.height - h) / 2;
			
			winprops = 'resizable=1, height='+h+',width='+w+',top='+t+',left='+l;
			if (scroll) winprops+=',scrollbars=1';
			var f = window.open(query, "_blank", winprops);
		}
		
		function ClickMenu(menuItem)
		{
			var contextDataNode = menuItem.ParentMenu.ContextData;
			var tree = contextDataNode.ParentTreeView;
			
			if(menuItem.Value=="tReload")
			{	
				contextDataNode.SaveState();
				contextDataNode.Collapse();
				var childNodes = contextDataNode.Nodes();
				for(var i = childNodes.length-1; i >= 0; i--)
				{
					childNodes[i].Remove();
				}
				var str=tree.ControlId;
				re = /:/g;
				str = str.replace(re,"_");
				tree.Render(str+"_div");
			}
			/*else if(menuItem.Value=="MCust")
			{
				top.frames["right"].location.href = "../Workspace/default.aspx?BTab=Customize";
			}*/
			else if(menuItem.Value=="NewPrj")
			{
				if (contextDataNode.Value.indexOf("NewPrj")>0)
				{
					var str=contextDataNode.Value.substring(0,contextDataNode.Value.indexOf("NewPrj"));
					top.frames["right"].location.href = "../Projects/ProjectEdit.aspx?TemplateId="+str;
				}
				else
					top.frames["right"].location.href = "../Projects/ProjectEdit.aspx";
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("GenCat")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=1',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("PrjCat")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=8',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("PrjTyp")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=6',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("PrjClt")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=7',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("IssCat")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=9',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("IssTyp")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=5',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("IssSev")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=4',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("PrjPhs")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=2',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("LstTyp")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=12',640, 350, false);
			}
			else if(menuItem.Value=="tManage" && contextDataNode.Value.indexOf("DocStat")>=0)
			{
				OpenWindow('../Common/AddCategory.aspx?BtnID=&DictType=11',640, 350, false);
			}
			else if(menuItem.Value=="NewRepTemp")
			{
				OpenWindow('../Reports/XMLReport.aspx?Mode=Temp',750,466,true);
			}
			else if(menuItem.Value=="tNewPrjGrp")
			{
				top.frames["right"].location.href = "../Projects/ProjectGroupEdit.aspx";
			}
			else if(menuItem.Value=="PrjGrpEdit")
			{
				var str = contextDataNode.Value.substring(0, contextDataNode.Value.indexOf("PrjGrp"));
				top.frames["right"].location.href = "../Projects/ProjectGroupEdit.aspx?ProjectGroupId="+str;
			}
			else if(menuItem.Value=="PrjGrpDelete")
			{
				var str = contextDataNode.Value.substring(0, contextDataNode.Value.indexOf("PrjGrp"));
				top.frames["right"].location.href = "../Projects/ProjectGroupView.aspx?ProjectGroupId="+str;
			}
			return true;
		}


		function libContextMenu(treeNode, e)
		{
			var sID = treeNode.ID;
			var sValue = treeNode.Value;
			if(sID.indexOf("folder")>=0 || sID.indexOf("group")>=0 || sValue == "onlyReload")
				ReloadMenu.ShowContextMenu(e, treeNode);
			else if(sValue.indexOf("NewPrj")>=0)
				newPrjMenu.ShowContextMenu(e, treeNode);
			else if(sValue=="GenCatList" 
			 || sValue=="PrjCatList" 
			 || sValue=="PrjTypList" 
			 || sValue=="PrjCltList" 
			 || sValue=="IssCatList" 
			 || sValue=="IssTypList"
			 || sValue=="IssSevList"
			 || sValue=="PrjPhsList"
			 || sValue=="LstTypList"
			 || sValue=="DocStatusList")
				ReloadManageMenu.ShowContextMenu(e, treeNode);
			else if(sValue.indexOf("GenCat")>=0
			 || sValue.indexOf("PrjCat")>=0
			 || sValue.indexOf("PrjTyp")>=0
			 || sValue.indexOf("PrjClt")>=0 
			 || sValue.indexOf("IssCat")>=0
			 || sValue.indexOf("IssTyp")>=0
			 || sValue.indexOf("IssSev")>=0
			 || sValue.indexOf("PrjPhs")>=0
			 || sValue.indexOf("LstTyp")>=0
			 || sValue.indexOf("DocStat")>=0)
				ManageMenu.ShowContextMenu(e, treeNode);
			else if(sValue=="PrjGrp")
				ReloadNewPortfolio.ShowContextMenu(e, treeNode);
			else if(sValue.indexOf("PrjGrp")>=0)
				ManagePortfolio.ShowContextMenu(e, treeNode);
			else if(sValue=="NewPrt")
				newPortfolio.ShowContextMenu(e, treeNode);
			else
				blockAlternates();
		}
		function blockAlternates()
		{   
			document.oncontextmenu = nocontextmenu;
		}

		function nocontextmenu()
		{
			if(browseris.ie5up)
			{
				event.cancelBubble = true;
				event.returnValue = false;
				return false;
			}
			else
				return false;
		}
