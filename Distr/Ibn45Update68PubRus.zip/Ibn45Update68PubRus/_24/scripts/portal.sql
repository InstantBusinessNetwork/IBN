INSERT INTO [OBJECT_TYPES] (ObjectTypeId, ObjectTypeName) VALUES (20, 'KnowledgeBase')
GO
