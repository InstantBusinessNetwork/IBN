SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[mc_ActualFinancesList]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[mc_ActualFinancesList]
(
@ObjectId int,
@ObjectTypeId int
)
AS
    SET NOCOUNT ON
IF @ObjectTypeId = 3
BEGIN
	SELECT [ActualFinancesId],
		[CreatorId],
		[Date],
		[ObjectId],
		[ObjectTypeId],
		[RowId],
		[Value],
		[Comment],
		null AS [UserId]
	FROM ActualFinances
	WHERE
	(
		[ObjectId] = @ObjectId
		AND
		[ObjectTypeId] = 3
	)
	UNION ALL
	SELECT AF.[ActualFinancesId],
		AF.[CreatorId],
		AF.[Date],
		AF.[ObjectId],
		AF.[ObjectTypeId],
		AF.[RowId],
		AF.[Value],
		AF.[Comment],
		null AS [UserId]
	FROM ActualFinances AF
	INNER JOIN INCIDENTS I ON I.IncidentId = AF.ObjectId
	WHERE
	(
		I.ProjectId = @ObjectId
		AND
		AF.[ObjectTypeId] = 7
	)
	UNION ALL
	SELECT AF.[ActualFinancesId],
		AF.[CreatorId],
		AF.[Date],
		AF.[ObjectId],
		AF.[ObjectTypeId],
		AF.[RowId],
		AF.[Value],
		AF.[Comment],
		null AS [UserId]
	FROM ActualFinances AF
	INNER JOIN EVENTS E ON E.EventId = AF.ObjectId
	WHERE
	(
		E.ProjectId = @ObjectId
		AND
		AF.[ObjectTypeId] = 4
	)
	UNION ALL
	SELECT AF.[ActualFinancesId],
		AF.[CreatorId],
		AF.[Date],
		AF.[ObjectId],
		AF.[ObjectTypeId],
		AF.[RowId],
		AF.[Value],
		AF.[Comment],
		null AS [UserId]
	FROM ActualFinances AF
	INNER JOIN TASKS T ON T.TaskId = AF.ObjectId
	WHERE
	(
		T.ProjectId = @ObjectId
		AND
		AF.[ObjectTypeId] = 5
	)
	UNION ALL
	SELECT AF.[ActualFinancesId],
		AF.[CreatorId],
		AF.[Date],
		AF.[ObjectId],
		AF.[ObjectTypeId],
		AF.[RowId],
		AF.[Value],
		AF.[Comment],
		null AS [UserId]
	FROM ActualFinances AF
	INNER JOIN TODO T ON T.TodoId = AF.ObjectId
	WHERE
	(
		T.ProjectId = @ObjectId
		AND
		AF.[ObjectTypeId] = 6
	)
	UNION ALL
	SELECT AF.[ActualFinancesId],
		AF.[CreatorId],
		AF.[Date],
		AF.[ObjectId],
		AF.[ObjectTypeId],
		AF.[RowId],
		AF.[Value],
		AF.[Comment],
		W.[UserId]
	FROM ActualFinances AF
	INNER JOIN TIMESHEETS T ON T.ObjectId = AF.ObjectId AND  T.ObjectTypeId = AF.ObjectTypeId
	INNER JOIN WeekTimeSheet W ON W.WeekTimeSheetId = T.WeekTimeSheetId
	WHERE
	(
		W.ProjectId = @ObjectId
		AND
		AF.[ObjectTypeId] = 11
	)
	UNION ALL
	SELECT AF.[ActualFinancesId],
		AF.[CreatorId],
		AF.[Date],
		AF.[ObjectId],
		AF.[ObjectTypeId],
		AF.[RowId],
		AF.[Value],
		AF.[Comment],
		null AS [UserId]
	FROM ActualFinances AF
	INNER JOIN TIMESHEETS T ON T.ObjectId = AF.ObjectId
	INNER JOIN WeekTimeSheet W ON W.WeekTimeSheetId = T.WeekTimeSheetId
	WHERE
	(
		W.ProjectId = @ObjectId
		AND
		AF.[ObjectTypeId] = 14
	)
	UNION ALL
	SELECT AF.[ActualFinancesId],
		AF.[CreatorId],
		AF.[Date],
		AF.[ObjectId],
		AF.[ObjectTypeId],
		AF.[RowId],
		AF.[Value],
		AF.[Comment],
		null AS [UserId]
	FROM ActualFinances AF
	INNER JOIN DOCUMENTS D ON D.DocumentId = AF.ObjectId
	WHERE
	(
		D.ProjectId = @ObjectId
		AND
		AF.[ObjectTypeId] = 16
	)
END
ELSE
BEGIN
	SELECT [ActualFinancesId],
		[CreatorId],
		[Date],
		[ObjectId],
		[ObjectTypeId],
		[RowId],
		[Value],
		[Comment],
		null AS [UserId]
	FROM ActualFinances
	WHERE
		[ObjectId] = @ObjectId
		AND
		[ObjectTypeId] = @ObjectTypeId
END
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetAssignedToUser]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].[ToDoAndTasksGetAssignedToUser]
	@UserId as int,
	@ShowActive as bit,
	@FromDate datetime,
	@ToDate datetime
as
SET @ToDate = DATEADD(d, 1, @ToDate)
DECLARE @ActiveState int, @OverdueState int
SET @ActiveState = 2
SET @OverdueState  = 3
DECLARE @Now datetime, @MaxValue datetime, @MinValue datetime
SET @Now = getutcdate()
SET @MaxValue = DATEADD(yy, 100, @Now)
SET @MinValue = DATEADD(yy, -100, @Now)
SELECT T.ToDoId AS ItemId, T.Title,  T.IsCompleted, T.CompletionTypeId, T.ReasonId, 1 AS IsToDo, T.StateId, T.ManagerId, U.LastName,
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	ISNULL(T.FinishDate, DATEADD(yy, 100, T.CreationDate)) AS SortFinishDate,
	CASE WHEN T.CompletionTypeId = 1 THEN R.PercentCompleted ELSE T.PercentCompleted END AS PercentCompleted
  FROM TODO T
	JOIN USERS U ON (T.ManagerId = U.PrincipalId)
	JOIN TODO_RESOURCES R ON (T.ToDoId = R.ToDoId)
  WHERE (R.PrincipalId = @UserId OR R.PrincipalId IN (SELECT GroupId FROM USER_GROUP WHERE UserId = @UserId))
	AND NOT (R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0)
	AND
	(@ShowActive = 0 OR T.StateId = @ActiveState OR T.StateId = @OverdueState)
	AND
		CASE
			WHEN T.StartDate IS NOT NULL AND T.StartDate < ISNULL(T.ActualStartDate, @MaxValue) THEN T.StartDate
			WHEN T.ActualStartDate IS NOT NULL AND T.ActualStartDate < ISNULL(T.StartDate, @MaxValue) THEN T.ActualStartDate
			ELSE T.CreationDate
		END < @ToDate
	AND
		CASE
			WHEN T.FinishDate IS NOT NULL AND T.FinishDate > ISNULL(T.ActualFinishDate, @Now) THEN T.FinishDate
			WHEN T.ActualFinishDate IS NOT NULL AND T.ActualFinishDate > ISNULL(T.FinishDate, @MinValue) THEN T.ActualFinishDate
			WHEN T.ActualFinishDate IS NULL THEN @Now
			ELSE T.CreationDate
		END > @FromDate
UNION ALL
SELECT T.TaskId  AS ItemId, T.Title, T.IsCompleted, T.CompletionTypeId, T.ReasonId, 0 AS IsToDo, T.StateId, P.ManagerId, U.LastName,
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate, T.FinishDate AS SortFinishDate,
	CASE WHEN T.CompletionTypeId = 1 THEN R.PercentCompleted ELSE T.PercentCompleted END AS PercentCompleted
  FROM TASKS T
	JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
	JOIN USERS U ON (P.ManagerId = U.PrincipalId)
	JOIN TASK_RESOURCES R ON (T.TaskId = R.TaskId)
  WHERE R.PrincipalId = @UserId AND NOT (R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0)
	AND
	(@ShowActive = 0 OR T.StateId = @ActiveState OR T.StateId = @OverdueState)
	AND
		CASE
			WHEN T.StartDate < ISNULL(T.ActualStartDate, @MaxValue) THEN T.StartDate
			WHEN T.ActualStartDate IS NOT NULL AND T.ActualStartDate < T.StartDate THEN T.ActualStartDate
			ELSE T.CreationDate
		END < @ToDate
	AND
		CASE
			WHEN T.FinishDate > ISNULL(T.ActualFinishDate, @Now) THEN T.FinishDate
			WHEN T.ActualFinishDate IS NOT NULL AND T.ActualFinishDate > T.FinishDate THEN T.ActualFinishDate
			WHEN T.ActualFinishDate IS NULL THEN @Now
			ELSE T.CreationDate
		END > @FromDate
	AND T.IsSummary = 0 AND T.IsMilestone = 0
GO
PRINT N'Altering [dbo].[ProjectsGetForPMAndPPM]'
GO
ALTER PROCEDURE [dbo].[ProjectsGetForPMAndPPM]
	@UserId as int
as
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
SELECT P.ProjectId, P.FormId AS TypeId, P.CalendarId, P.CreatorId, P.ManagerId, U.LastName + ', ' + U.FirstName AS ManagerName,
	P.ExecutiveManagerId, P.Title, P.[Description], P.PercentCompleted,
	P.CreationDate, P.StartDate, P.FinishDate, P.TargetStartDate, P.TargetFinishDate, P.ActualStartDate, P.ActualFinishDate,
	P.FixedHours, P.FixedCost, P.Goals, P.Scope, P.Deliverables, P.StatusId, S.StatusName, S.IsActive,
	CASE WHEN @IsPPM = 1 OR PS.IsManager = 1 THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR PS.IsManager = 1 THEN 1 ELSE 0 END AS CanDelete
  FROM PROJECTS P
	LEFT JOIN PROJECT_SECURITY_ALL PS ON (P.ProjectId = PS.ProjectId AND PS.PrincipalId = @UserId )
	JOIN PROJECT_STATUS S ON (P.StatusId = S.StatusId)
	JOIN USERS U ON (P.ManagerId = U.PrincipalId)
  WHERE @IsPPM = 1 OR @IsExec = 1 OR PS.IsManager = 1
  ORDER BY P.Title
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

EXEC RebuildUserRoles
GO
