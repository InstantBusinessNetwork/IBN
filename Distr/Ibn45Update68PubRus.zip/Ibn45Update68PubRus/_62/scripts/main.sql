DECLARE @ProductId INT

SELECT @ProductId = [ProductId] FROM [DL_PRODUCTS] WHERE [ProductGuid] = '1D12D687-8C24-4ADE-8DA2-73B422E1D110'
IF @ProductId IS NOT NULL
BEGIN
	UPDATE [DL_VERSIONS] SET [Build] = 703, [Date] = CONVERT(smalldatetime, '2008-05-16', 120) WHERE ProductId = @ProductId
END

SELECT @ProductId = [ProductId] FROM [DL_PRODUCTS] WHERE [ProductGuid] = 'F268745E-B9BB-4391-B342-8AD8272F9321'
IF @ProductId IS NOT NULL
BEGIN
	UPDATE [DL_VERSIONS] SET [Build] = 703, [Date] = CONVERT(smalldatetime, '2008-05-16', 120) WHERE ProductId = @ProductId
END
GO
