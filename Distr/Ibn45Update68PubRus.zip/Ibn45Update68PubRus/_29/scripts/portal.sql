SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Dropping foreign keys from [dbo].[IncidentBox]'
GO
ALTER TABLE [dbo].[IncidentBox] DROP
CONSTRAINT [FK_IncidentBox_USERS],
CONSTRAINT [FK_IncidentBox_USERS1]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping constraints from [dbo].[SqlFileStorage]'
GO
ALTER TABLE [dbo].[SqlFileStorage] DROP CONSTRAINT [DF_mf_InnerAttachment_SessionUid]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[SqlFileStorage]'
GO
ALTER TABLE [dbo].[SqlFileStorage] ADD
[FolderUid] [uniqueidentifier] NOT NULL CONSTRAINT [DF_mf_InnerAttachment_SessionUid] DEFAULT (newid())
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
ALTER TABLE [dbo].[SqlFileStorage] DROP
COLUMN [SessionUid]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_SqlFileStorageInsert]'
GO
ALTER PROCEDURE [dbo].[mc_SqlFileStorageInsert]
(
@AttachmentId int = NULL OUTPUT
,
@Uid uniqueidentifier,
@Created datetime,
@FileName nvarchar(255),
@Type int,
@ReferenceUrl ntext,
@FileStream image = NULL,
@Attributes ntext,
@FolderUid uniqueidentifier)
AS
    SET NOCOUNT ON
INSERT INTO [SqlFileStorage]
(
[Uid],
[Created],
[FileName],
[Type],
[ReferenceUrl],
[FileStream],
[Attributes],
[FolderUid])
VALUES(
@Uid,
@Created,
@FileName,
@Type,
@ReferenceUrl,
@FileStream,
@Attributes,
@FolderUid)
SELECT @AttachmentId = SCOPE_IDENTITY();
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_SqlFileStorageSelectBySessionUid]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[mc_SqlFileStorageSelectBySessionUid]
(
@FolderUid uniqueidentifier
)
AS
    SET NOCOUNT ON
SELECT [AttachmentId],
[Uid],
[Created],
[FileName],
[Type],
[ReferenceUrl],
[FileStream],
[Attributes],
FolderUid,
[Size] FROM SqlFileStorage
WHERE
[FolderUid] = @FolderUid
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_SqlFileStorageSelect]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[mc_SqlFileStorageSelect]
(
@AttachmentUId uniqueidentifier
)
AS
    SET NOCOUNT ON
SELECT [AttachmentId],
[Uid],
[Created],
[FileName],
[Type],
[ReferenceUrl],
[FileStream],
[Attributes],
[FolderUid],
[Size] FROM SqlFileStorage
WHERE
[Uid] = @AttachmentUId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_SqlFileStorageUpdate]'
GO
ALTER PROCEDURE [dbo].[mc_SqlFileStorageUpdate]
(
@AttachmentId int,
@Uid uniqueidentifier,
@Created datetime,
@FileName nvarchar(255),
@Type int,
@ReferenceUrl ntext,
@FileStream image = NULL
,
@Attributes ntext,
@FolderUid uniqueidentifier)
AS
    SET NOCOUNT ON
UPDATE [SqlFileStorage]
SET
[Uid] = @Uid,
[Created] = @Created,
[FileName] = @FileName,
[Type] = @Type,
[ReferenceUrl] = @ReferenceUrl,
[FileStream] = @FileStream,
[Attributes] = @Attributes,
[FolderUid] = @FolderUid
WHERE
[AttachmentId] = @AttachmentId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_SqlFileStorageDeleteBySessionUid]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[mc_SqlFileStorageDeleteBySessionUid]
(
@FolderUid uniqueidentifier
)
AS
    SET NOCOUNT ON
DELETE FROM [SqlFileStorage]
WHERE
[FolderUid] = @FolderUid
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_SqlFileStorageDelete]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[mc_SqlFileStorageDelete]
(
@AttachmentId int
)
AS
    SET NOCOUNT ON
DELETE FROM [SqlFileStorage]
WHERE
[AttachmentId] = @AttachmentId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
UPDATE IncidentBox SET  ControllerId = ManagerId WHERE Document LIKE N'%ControllerAssignType&gt;Manager&lt;/ControllerAssignType%'
GO
