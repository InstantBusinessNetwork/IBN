SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[ProjectMemberGetByCode]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ProjectMemberGetByCode]
			@ProjectId INT,
			@RName nVarChar(250) = NULL,
			@Code nVarChar(250) = NULL,
			@RetVal INT OUTPUT
AS
IF EXISTS(SELECT * FROM PROJECT_MEMBERS WHERE ProjectId = @ProjectId AND ((@Code IS NOT NULL AND @Code = Code) OR @RName = Code) AND IsTeamMember=1)
BEGIN
	SELECT TOP 1 @RetVal = PrincipalId FROM PROJECT_MEMBERS WHERE ProjectId = @ProjectId AND (@Code = Code OR @RName = Code) AND IsTeamMember=1
END
ELSE
BEGIN
	SELECT TOP 1 @RetVal = PM.PrincipalId FROM PROJECT_MEMBERS PM JOIN USERS U ON U.PrincipalId = PM.PrincipalId
		 WHERE PM.ProjectId = @ProjectId AND IsTeamMember=1
		 AND (FirstName = @Code OR LastName = @Code OR
		      FirstName + ' ' + LastName = @Code    OR
		      FirstName = @RName OR LastName = @RName OR
		      FirstName + ' ' + LastName = @RName OR
			  LastName + ' ' + FirstName = @RName)
END
IF @@ROWCOUNT = 0
	SET @RetVal = -1
GO
PRINT N'Altering [dbo].[fsc_FilesSearchFts]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[fsc_FilesSearchFts]
	@UserId INT,
	@ContainerKey nvarchar(50) = NULL,
	@DirectoryId int = NULL,
	@Deep bit = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
DECLARE @FtsString NVARCHAR(300)
SET @FtsString = N'"*'+REPLACE(@Keyword,'"','""')+N'*"'
EXEC sp_executesql  N'SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory,
	Description
FROM fsc_Files F WITH(NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH(NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N''Read'' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	(
		@ContainerKey IS NULL
		OR
		D.ContainerKey = @ContainerKey
	)
	AND
	(
		@DirectoryId IS NULL
		OR
		@Deep = 1
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Deep IS NULL
		OR
		@DirectoryId IS NULL
		OR
		@Deep = 0
		OR
		F.DirectoryId IN (SELECT DD.DirectoryId From fsc_Directories DD WHERE DD.Path LIKE (''%.'' + CAST(@DirectoryId AS VARCHAR(10)) + ''.%''))
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE ''%''+@Keyword+''%''
		OR
		F.[Description] LIKE ''%''+@Keyword+''%''
		OR
		CONTAINS(Data, @FtsString)
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)',
N'@UserId INT, 	@ContainerKey nvarchar(50), @DirectoryId int, @Deep bit,
	@Keyword nvarchar(255) ,
	@ContentType int = NULL,
	@ModifiedFrom DateTime,
	@ModifiedTo DateTime,
	@LengthFrom int,
	@LengthTo int, @FtsString NVARCHAR(300)',
@UserId , 	@ContainerKey , @DirectoryId, @Deep,
	@Keyword,
	@ContentType,
	@ModifiedFrom,
	@ModifiedTo,
	@LengthFrom,
	@LengthTo, @FtsString
GO
PRINT N'Creating [dbo].[UsersGetActiveForPartner]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[UsersGetActiveForPartner]
	@UserId as int
as
DECLARE @Active tinyint
SET @Active = 3
DECLARE @PartnerGroupId int
SELECT @PartnerGroupId = ParentPrincipalId FROM Containership WHERE PrincipalId = @UserId
SELECT PrincipalId, Login, [Password], FirstName, LastName, Email, IMGroupId, OriginalId, LastName+', '+FirstName as DisplayName
  FROM USERS
  WHERE Activity = @Active AND IsExternal = 0
	AND PrincipalId IN
		(SELECT UserId FROM USER_GROUP WHERE GroupId = @PartnerGroupId OR GroupId IN
		(SELECT GroupId FROM PARTNER_GROUP WHERE PartnerId = @PartnerGroupId))
ORDER BY LastName, FirstName
GO
PRINT N'Altering [dbo].[INCIDENT_SECURITY]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER VIEW [dbo].[INCIDENT_SECURITY]
AS
SELECT IncidentId, PrincipalId, MAX(IsManager) AS IsManager, MAX(IsCreator) AS IsCreator, MAX(IsResource) AS IsResource,
	MAX(IsRealIncidentManager) AS IsRealIncidentManager, MAX(IsRealIncidentResource) AS IsRealIncidentResource,
	MAX(IsIncidentResponsible) AS IsIncidentResponsible, MAX(IsIncidentController) AS IsIncidentController,
	MAX(IsPendingResponsible) AS IsPendingResponsible
FROM
	(SELECT I.IncidentId, B.ManagerId AS PrincipalId, 1 AS IsManager, 0 AS IsCreator, 0 AS IsResource, 1 AS IsRealIncidentManager, 0 AS IsRealIncidentResource, 0 AS IsIncidentResponsible, 0 AS IsIncidentController, 0 AS IsPendingResponsible
	  FROM INCIDENTS I, IncidentBox B
	  WHERE I.IncidentBoxId = B.IncidentBoxId
	UNION ALL
	SELECT I.IncidentId, I.ResponsibleId AS PrincipalId, 0 AS IsManager, 0 AS IsCreator, 0 AS IsResource, 0 AS IsRealIncidentManager, 0 AS IsRealIncidentResource, 1 AS IsIncidentResponsible, 0 AS IsIncidentController, 0 AS IsPendingResponsible
	  FROM INCIDENTS I, IncidentBox B
	  WHERE I.IncidentBoxId = B.IncidentBoxId AND I.ResponsibleId > 0
	UNION ALL
	SELECT I.IncidentId, B.ControllerId AS PrincipalId, 0 AS IsManager, 0 AS IsCreator, 0 AS IsResource, 0 AS IsRealIncidentManager, 0 AS IsRealIncidentResource, 0 AS IsIncidentResponsible, 1 AS IsIncidentController, 0 AS IsPendingResponsible
	  FROM INCIDENTS I, IncidentBox B
	  WHERE I.IncidentBoxId = B.IncidentBoxId AND B.ControllerId > 0
	UNION ALL
	SELECT IncidentId, PrincipalId,
		CASE WHEN CanManage = 1 THEN 1 ELSE 0 END AS IsManager,
		0 AS IsCreator,
		1 AS IsResource,
		CASE WHEN CanManage = 1 THEN 1 ELSE 0 END AS IsRealIncidentManager,
		1 AS IsRealIncidentResource,
		0 AS IsIncidentResponsible,
		0 AS IsIncidentController,
		0 AS IsPendingResponsible
	  FROM INCIDENT_RESOURCES
	  WHERE (NOT (MustBeConfirmed = 1 AND ResponsePending = 0 AND IsConfirmed = 0 )) AND  IsResponsible =  0
	UNION ALL
	SELECT IncidentId, PrincipalId,
		0 AS IsManager,
		0 AS IsCreator,
		0 AS IsResource,
		0 AS IsRealIncidentManager,
		0 AS IsRealIncidentResource,
		0 AS IsIncidentResponsible,
		0 AS IsIncidentController,
		1 AS IsPendingResponsible
	  FROM INCIDENT_RESOURCES
	  WHERE ( IsResponsible =  1)
	UNION ALL
	SELECT IncidentId, CreatorId AS PrincipalId, 0 AS IsManager, 1 AS IsCreator, 0 AS IsResource, 0 AS IsRealIncidentManager, 0 AS IsRealIncidentResource, 0 AS IsIncidentResponsible, 0 AS IsIncidentController, 0 AS IsPendingResponsible
	  FROM INCIDENTS
	UNION ALL
	SELECT IT.IncidentId, T.PrincipalId, T.IsManager, 0 AS IsCreator, T.IsResource, 0 AS IsRealIncidentManager, 0 AS IsRealIncidentResource, 0 AS IsIncidentResponsible, 0 AS IsIncidentController, 0 AS IsPendingResponsible
	  FROM TODO_SECURITY T
		JOIN INCIDENT_TODO IT ON (T.ToDoId = IT.ToDoId)
	) A
GROUP BY IncidentId, PrincipalId
GO
PRINT N'Altering [dbo].[Cal_GetDurationByFinishDate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[Cal_GetDurationByFinishDate]
	@CalendarId int,
	@StartDate datetime,
	@EndDate datetime,
	@retval int output
AS
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
IF @TimeZoneId IS NULL
BEGIN
	SET @retval = 0
	RETURN
END
DECLARE @SavedDatefirst int
SET @SavedDatefirst = @@DATEFIRST
SET DATEFIRST 7
SET @StartDate = [dbo].GetLocalDate(@TimeZoneId, @StartDate)
SET @EndDate = [dbo].GetLocalDate(@TimeZoneId, @EndDate)
DECLARE @DayOfWeek tinyint
DECLARE @Duration int, @DayDuration int
SET @Duration = 0
SET @DayDuration = 0
DECLARE @StartTime smallint
SET @StartTime = DATEPART(hh, @StartDate) * 60 + DATEPART(mi, @StartDate)
DECLARE @EndTime smallint
SET @EndTime = 24*60
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@StartTime, @StartDate)
WHILE @ProcessDate <= @EndDate BEGIN
	IF DATEDIFF(dd, @ProcessDate, @EndDate) = 0
			SET @EndTime = DATEPART(hh, @EndDate) * 60 + DATEPART(mi, @EndDate)
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(CASE WHEN ToTime < @EndTime THEN ToTime ELSE @EndTime END  - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		  FROM CAL_EXCEPTION_HOURS
		  WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
			AND ToTime > @StartTime AND FromTime < @EndTime
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(CASE WHEN ToTime < @EndTime THEN ToTime ELSE @EndTime END - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		  FROM CAL_WEEKDAYS
		  WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime AND FromTime < @EndTime
	END
	IF @DayDuration IS NOT NULL
		SET @Duration = @Duration + @DayDuration
	SET @ProcessDate = DATEADD(dd, 1, @ProcessDate)
	SET @StartTime = 0
END
SET @retval = @Duration
SET DATEFIRST @SavedDatefirst
GO
PRINT N'Altering [dbo].[DOCUMENT_SECURITY]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER VIEW [dbo].[DOCUMENT_SECURITY]
AS
SELECT DocumentId, PrincipalId, MAX(IsManager) AS IsManager, MAX(IsResource) AS IsResource,
	MAX(IsRealDocumentManager) AS IsRealDocumentManager, MAX(IsRealDocumentResource) AS IsRealDocumentResource
FROM
	(SELECT DocumentId, ManagerId AS PrincipalId, 1 AS IsManager, 0 AS IsResource, 1 AS IsRealDocumentManager, 0 AS IsRealDocumentResource
	  FROM DOCUMENTS
	UNION ALL
	SELECT DocumentId, PrincipalId,
		CASE WHEN CanManage = 1 THEN 1 ELSE 0 END AS IsManager,
		1 AS IsResource,
		CASE WHEN CanManage = 1 THEN 1 ELSE 0 END AS IsRealDocumentManager,
		1 AS IsRealDocumentResource
	  FROM DOCUMENT_RESOURCES
	  WHERE NOT (MustBeConfirmed = 1 AND ResponsePending = 0 AND IsConfirmed = 0)
	UNION ALL
	SELECT DT.DocumentId, T.PrincipalId, T.IsManager, T.IsResource, 0 AS IsRealDocumentManager, 0 AS IsRealDocumentResource
	  FROM TODO_SECURITY T
		JOIN DOCUMENT_TODO DT ON (T.ToDoId = DT.ToDoId)
	) A
GROUP BY DocumentId, PrincipalId
GO
PRINT N'Altering [dbo].[WorkSpaceFilesSearchFts]'
GO
ALTER PROCEDURE [dbo].[WorkSpaceFilesSearchFts]
	@UserId INT,
	@ProjectId INT = NULL,
	@ObjectTypeId INT = NULL,
	@ObjectId INT = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
DECLARE @FtsString NVARCHAR(300)
SET @FtsString = N'"*'+REPLACE(@Keyword,'"','""')+N'*"'
EXEC sp_executesql  N'DECLARE @SelectedContainerKeys TABLE(ContainerKey nvarchar(50) COLLATE database_default)
IF @ProjectId IS NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys SELECT DISTINCT ContainerKey FROM fsc_Directories WITH (NOLOCK)
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 3
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ProjectId_'' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)
		UNION
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO  WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ProjectId_'' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents  WITH (NOLOCK) WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 5
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentVers_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentVers_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId IS NULL
END
SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	F.[Description],
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory
FROM fsc_Files F WITH (NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH (NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N''Read'' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	D.ContainerKey IN (SELECT ContainerKey FROM @SelectedContainerKeys)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE ''%''+@Keyword+''%''
		OR
		F.[Description] LIKE ''%''+@Keyword+''%''
		OR
		CONTAINS(Data, @FtsString)
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)',
N'@UserId INT, @ProjectId INT,	@ObjectTypeId INT,@ObjectId INT,@Keyword nvarchar(255),@ContentType int,@ModifiedFrom DateTime,@ModifiedTo DateTime,@LengthFrom int,	@LengthTo int, 	@FtsString NVARCHAR(300)',
@UserId, @ProjectId,	@ObjectTypeId,	@ObjectId,	@Keyword,	@ContentType,	@ModifiedFrom,	@ModifiedTo,	@LengthFrom,	@LengthTo, 	@FtsString
GO
PRINT N'Creating [dbo].[IncidentCreatorsGetForPartner]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[IncidentCreatorsGetForPartner]
	@UserId int
as
DECLARE @PartnerGroupId int
SELECT @PartnerGroupId = ParentPrincipalId FROM Containership WHERE PrincipalId = @UserId
SELECT DISTINCT I.CreatorId AS UserId, U.LastName + ', ' + U.FirstName AS UserName, U.FirstName +' '+ U.LastName AS UserName2
  FROM INCIDENTS I
	JOIN USERS U ON (I.CreatorId = U.PrincipalId)
  WHERE U.PrincipalId IN (SELECT PrincipalId FROM Containership WHERE ParentPrincipalId = @PartnerGroupId)
	OR U.PrincipalId IN (SELECT PrincipalId FROM Containership WHERE ParentPrincipalId IN
		(SELECT GroupId FROM Partner_Group WHERE PartnerId = @PartnerGroupId))
  ORDER BY UserName
GO
PRINT N'Creating [dbo].[IncidentManagersGetForPartner]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[IncidentManagersGetForPartner]
	@UserId int
as
DECLARE @PartnerGroupId int
SELECT @PartnerGroupId = ParentPrincipalId FROM Containership WHERE PrincipalId = @UserId
SELECT DISTINCT I.ManagerId AS UserId, U.LastName + ', ' + U.FirstName AS UserName, U.FirstName +' '+ U.LastName AS UserName2
  FROM INCIDENTBOX I
	JOIN USERS U ON (I.ManagerId = U.PrincipalId)
  WHERE U.PrincipalId IN (SELECT PrincipalId FROM Containership WHERE ParentPrincipalId = @PartnerGroupId)
	OR U.PrincipalId IN (SELECT PrincipalId FROM Containership WHERE ParentPrincipalId IN
		(SELECT GroupId FROM Partner_Group WHERE PartnerId = @PartnerGroupId))
  ORDER BY UserName
GO
PRINT N'Altering [dbo].[GetDurationByFinishDate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER FUNCTION [dbo].[GetDurationByFinishDate]
		   	(@CalendarId int,
			@StartDate datetime,
			@EndDate datetime
			)
RETURNS INT AS
BEGIN
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
IF @TimeZoneId IS NULL
	RETURN 0
SET @StartDate = [dbo].GetLocalDate(@TimeZoneId, @StartDate)
SET @EndDate = [dbo].GetLocalDate(@TimeZoneId, @EndDate)
DECLARE @DayOfWeek tinyint
DECLARE @Duration int, @DayDuration int
SET @Duration = 0
SET @DayDuration = 0
DECLARE @StartTime smallint
SET @StartTime = DATEPART(hh, @StartDate) * 60 + DATEPART(mi, @StartDate)
DECLARE @EndTime smallint
SET @EndTime = 24*60
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@StartTime, @StartDate)
WHILE @ProcessDate <= @EndDate BEGIN
	IF DATEDIFF(dd, @ProcessDate, @EndDate) = 0
			SET @EndTime = DATEPART(hh, @EndDate) * 60 + DATEPART(mi, @EndDate)
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate >= @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(CASE WHEN ToTime < @EndTime THEN ToTime ELSE @EndTime END  - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		  FROM CAL_EXCEPTION_HOURS
		  WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate >= @ProcessDate)
			AND ToTime > @StartTime AND FromTime < @EndTime
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(CASE WHEN ToTime < @EndTime THEN ToTime ELSE @EndTime END - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		  FROM CAL_WEEKDAYS
		  WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime AND FromTime < @EndTime
	END
	IF @DayDuration IS NOT NULL
		SET @Duration = @Duration + @DayDuration
	SET @ProcessDate = DATEADD(dd, 1, @ProcessDate)
	SET @StartTime = 0
END
RETURN @Duration
END
GO
PRINT N'Altering [dbo].[GetFinishDateByDuration]'
GO
ALTER FUNCTION [dbo].[GetFinishDateByDuration]
		 (@CalendarId int,
		  @StartDate datetime,
		  @Duration int)
RETURNS DateTime AS
BEGIN
DECLARE @EndDate datetime
DECLARE @FromTime smallint, @ToTime smallint
DECLARE @IntervalDuration smallint
DECLARE @DayDuration smallint
DECLARE @DayOfWeek tinyint
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
IF @TimeZoneId IS NULL
	RETURN @StartDate
SET @StartDate = [dbo].GetLocalDate(@TimeZoneId, @StartDate)
DECLARE @StartTime smallint
SET @StartTime = DATEPART(hh, @StartDate) * 60 + DATEPART(mi, @StartDate)
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@StartTime, @StartDate)
WHILE @Duration >= 0 BEGIN
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate >= @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(ToTime - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		 FROM CAL_EXCEPTION_HOURS
		 WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate >= @ProcessDate)
			AND ToTime > @StartTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration <= @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END AS FromTime, ToTime
					 FROM CAL_EXCEPTION_HOURS
					 WHERE ExceptionId IN
						(SELECT ExceptionId
						  FROM CAL_EXCEPTIONS
						  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate >= @ProcessDate)
						AND ToTime > @StartTime
					 ORDER BY FromTime
				BREAK
			END
		END
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(ToTime - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		 FROM CAL_WEEKDAYS
		 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration <= @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END AS FromTime, ToTime
					 FROM CAL_WEEKDAYS
					 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime
					 ORDER BY FromTime
				BREAK
			END
		END
	END
	SET @ProcessDate = DATEADD(dd, 1, @ProcessDate)
	SET @StartTime = 0
END
OPEN HoursCursor
FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @IntervalDuration = @ToTime - @FromTime
	IF @IntervalDuration <= @Duration
		SET @Duration = @Duration - @IntervalDuration
	ELSE BEGIN
		SET @EndDate = DATEADD(mi, @FromTime + @Duration,@ProcessDate)
		BREAK
	END
	FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
END
CLOSE HoursCursor
DEALLOCATE HoursCursor
return [dbo].GetUTCDateFromLocal(@TimeZoneId, @EndDate)
END
GO
PRINT N'Altering [dbo].[GetStartDateByDuration]'
GO
ALTER FUNCTION [dbo].[GetStartDateByDuration]
		 (@CalendarId int,
		  @FinishDate datetime,
		  @Duration int)
RETURNS DateTime AS
BEGIN
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
IF @TimeZoneId IS NULL
	RETURN @FinishDate
SET @FinishDate = [dbo].GetLocalDate(@TimeZoneId, @FinishDate)
DECLARE @StartdDate datetime
DECLARE @FromTime smallint, @ToTime smallint
DECLARE @IntervalDuration smallint
DECLARE @DayDuration smallint
DECLARE @DayOfWeek tinyint
DECLARE @FinishTime smallint
SET @FinishTime = DATEPART(hh, @FinishDate) * 60 + DATEPART(mi, @FinishDate)
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@FinishTime, @FinishDate)
WHILE @Duration >= 0 BEGIN
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate >= @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END - FromTime)
		 FROM CAL_EXCEPTION_HOURS
		 WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate >= @ProcessDate)
			AND FromTime <= @FinishTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration < @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT FromTime, CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END AS ToTime
					 FROM CAL_EXCEPTION_HOURS
					 WHERE ExceptionId IN
						(SELECT ExceptionId
						  FROM CAL_EXCEPTIONS
						  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate >= @ProcessDate)
						AND FromTime <= @FinishTime
					 ORDER BY ToTime DESC
				BREAK
			END
		END
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END - FromTime)
		 FROM CAL_WEEKDAYS
		 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND FromTime <= @FinishTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration < @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT FromTime, CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END AS ToTime
					 FROM CAL_WEEKDAYS
					 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND FromTime <= @FinishTime
					 ORDER BY ToTime DESC
				BREAK
			END
		END
	END
	SET @ProcessDate = DATEADD(dd, -1, @ProcessDate)
	SET @FinishTime = 24*60
END
OPEN HoursCursor
FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @IntervalDuration = @ToTime - @FromTime
	IF @IntervalDuration < @Duration
		SET @Duration = @Duration - @IntervalDuration
	ELSE BEGIN
		SET @StartdDate = DATEADD(mi, @ToTime - @Duration, @ProcessDate)
		BREAK
	END
	FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
END
CLOSE HoursCursor
DEALLOCATE HoursCursor
return [dbo].GetUTCDateFromLocal(@TimeZoneId, @StartdDate)
END
GO
PRINT N'Altering [dbo].[Cal_GetFinishDateByDuration]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[Cal_GetFinishDateByDuration]
	@CalendarId int,
	@StartDate datetime,
	@Duration int,
	@retval datetime output
AS
DECLARE @EndDate datetime
DECLARE @FromTime smallint, @ToTime smallint
DECLARE @IntervalDuration smallint
DECLARE @DayDuration smallint
DECLARE @DayOfWeek tinyint
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
IF @TimeZoneId IS NULL
BEGIN
	SET @retval = @StartDate
	RETURN
END
DECLARE @SavedDatefirst int
SET @SavedDatefirst = @@DATEFIRST
SET DATEFIRST 7
SET @StartDate = [dbo].GetLocalDate(@TimeZoneId, @StartDate)
DECLARE @StartTime smallint
SET @StartTime = DATEPART(hh, @StartDate) * 60 + DATEPART(mi, @StartDate)
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@StartTime, @StartDate)
WHILE @Duration >= 0 BEGIN
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(ToTime - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		 FROM CAL_EXCEPTION_HOURS
		 WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
			AND ToTime > @StartTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration <= @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END AS FromTime, ToTime
					 FROM CAL_EXCEPTION_HOURS
					 WHERE ExceptionId IN
						(SELECT ExceptionId
						  FROM CAL_EXCEPTIONS
						  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
						AND ToTime > @StartTime
					 ORDER BY FromTime
				BREAK
			END
		END
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(ToTime - CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END)
		 FROM CAL_WEEKDAYS
		 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration <= @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT CASE WHEN FromTime > @StartTime THEN FromTime ELSE @StartTime END AS FromTime, ToTime
					 FROM CAL_WEEKDAYS
					 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND ToTime > @StartTime
					 ORDER BY FromTime
				BREAK
			END
		END
	END
	SET @ProcessDate = DATEADD(dd, 1, @ProcessDate)
	SET @StartTime = 0
END
OPEN HoursCursor
FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @IntervalDuration = @ToTime - @FromTime
	IF @IntervalDuration <= @Duration
		SET @Duration = @Duration - @IntervalDuration
	ELSE BEGIN
		SET @EndDate = DATEADD(mi, @FromTime + @Duration,@ProcessDate)
		BREAK
	END
	FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
END
CLOSE HoursCursor
DEALLOCATE HoursCursor
SET @retval = [dbo].GetUTCDateFromLocal(@TimeZoneId, @EndDate)
SET DATEFIRST @SavedDatefirst
GO
PRINT N'Altering [dbo].[Cal_GetStartDateByDuration]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].[Cal_GetStartDateByDuration]
	@CalendarId int,
	@FinishDate datetime,
	@Duration int,
	@retval datetime output
AS
DECLARE @TimeZoneId int
SELECT @TimeZoneId = TimeZoneId FROM CALENDARS WHERE CalendarId = @CalendarId
IF @TimeZoneId IS NULL
BEGIN
	SET @retval = @FinishDate
	RETURN
END
DECLARE @SavedDatefirst int
SET @SavedDatefirst = @@DATEFIRST
SET DATEFIRST 7
SET @FinishDate = [dbo].GetLocalDate(@TimeZoneId, @FinishDate)
DECLARE @StartdDate datetime
DECLARE @FromTime smallint, @ToTime smallint
DECLARE @IntervalDuration smallint
DECLARE @DayDuration smallint
DECLARE @DayOfWeek tinyint
DECLARE @FinishTime smallint
SET @FinishTime = DATEPART(hh, @FinishDate) * 60 + DATEPART(mi, @FinishDate)
DECLARE @ProcessDate datetime
SET @ProcessDate = DATEADD(mi, -@FinishTime, @FinishDate)
WHILE @Duration >= 0 BEGIN
	IF EXISTS(SELECT * FROM CAL_EXCEPTIONS WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
	BEGIN
		SELECT @DayDuration = SUM(CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END - FromTime)
		 FROM CAL_EXCEPTION_HOURS
		 WHERE ExceptionId IN
			(SELECT ExceptionId
			  FROM CAL_EXCEPTIONS
			  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
			AND FromTime <= @FinishTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration < @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT FromTime, CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END AS ToTime
					 FROM CAL_EXCEPTION_HOURS
					 WHERE ExceptionId IN
						(SELECT ExceptionId
						  FROM CAL_EXCEPTIONS
						  WHERE CalendarId = @CalendarId AND FromDate <= @ProcessDate AND ToDate > @ProcessDate)
						AND FromTime <= @FinishTime
					 ORDER BY ToTime DESC
				BREAK
			END
		END
	END
	ELSE BEGIN
		SET @DayOfWeek = CASE WHEN DATEPART(dw, @ProcessDate) = 1 THEN 7 ELSE DATEPART(dw, @ProcessDate) - 1 END
		SELECT @DayDuration = SUM(CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END - FromTime)
		 FROM CAL_WEEKDAYS
		 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND FromTime <= @FinishTime
		IF @DayDuration IS NOT NULL BEGIN
			IF @DayDuration < @Duration
				SET @Duration =  @Duration - @DayDuration
			ELSE BEGIN
				DECLARE HoursCursor CURSOR FOR
					SELECT FromTime, CASE WHEN ToTime > @FinishTime THEN @FinishTime ELSE ToTime END AS ToTime
					 FROM CAL_WEEKDAYS
					 WHERE CalendarId = @CalendarId  AND [DayOfWeek] = @DayOfWeek AND FromTime <= @FinishTime
					 ORDER BY ToTime DESC
				BREAK
			END
		END
	END
	SET @ProcessDate = DATEADD(dd, -1, @ProcessDate)
	SET @FinishTime = 24*60
END
OPEN HoursCursor
FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @IntervalDuration = @ToTime - @FromTime
	IF @IntervalDuration < @Duration
		SET @Duration = @Duration - @IntervalDuration
	ELSE BEGIN
		SET @StartdDate = DATEADD(mi, @ToTime - @Duration, @ProcessDate)
		BREAK
	END
	FETCH NEXT FROM HoursCursor INTO @FromTime, @ToTime
END
CLOSE HoursCursor
DEALLOCATE HoursCursor
SET @StartdDate = [dbo].GetUTCDateFromLocal(@TimeZoneId, @StartdDate)
SET @retval = @StartdDate
SET DATEFIRST @SavedDatefirst
GO
PRINT N'Altering [dbo].[fsc_ForumThreadNodeCreate]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[fsc_ForumThreadNodeCreate]
@ThreadId int,
@Text ntext,
@Created datetime,
@CreatorId int,
@CreatorName nvarchar(255),
@CreatorEmail nvarchar(50),
@EMailMessageId int,
@NodeType int,
@Retval int out
AS
INSERT INTO [fsc_ForumThreadNodes]([ThreadId], [Text], [Created], [CreatorId], [CreatorName], [CreatorEmail], EMailMessageId, NodeType)
VALUES(@ThreadId, @Text, @Created, @CreatorId, @CreatorName, @CreatorEmail, @EMailMessageId, @NodeType)
SET @Retval = @@IDENTITY
DECLARE @ForumId int, @ContainerKey nvarchar(50), @IncidentId int
SELECT @ForumId = ForumId FROM fsc_ForumThreads WHERE ThreadId = @ThreadId
SELECT @ContainerKey = ContainerKey FROM fsc_Forums WHERE ForumId = @ForumId
IF LEFT(@ContainerKey, 11) = 'IncidentId_'
BEGIN
	SET @IncidentId = CAST(REPLACE(@ContainerKey, 'IncidentId_', '') as int)
	UPDATE INCIDENTS SET ModifiedDate = getutcdate() WHERE IncidentId = @IncidentId
	IF @NodeType = 1
	BEGIN
		DECLARE @SavedDatefirst int
		SET @SavedDatefirst = @@DATEFIRST
		SET DATEFIRST 7
		DECLARE @CalendarId int, @ExpectedResponseDate datetime, @ExpectedResponseTime int
		SELECT @CalendarId = B.CalendarId, @ExpectedResponseTime = I.ExpectedResponseTime
			FROM Incidents I
				JOIN IncidentBox B ON (I.IncidentBoxId = B.IncidentBoxId)
			WHERE I.IncidentId = @IncidentId
		IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
			SET @CalendarId = (SELECT MIN(CalendarId) FROM Calendars)
		SET @ExpectedResponseDate = [dbo].GetFinishDateByDuration(@CalendarId, getutcdate(), @ExpectedResponseTime)
		UPDATE INCIDENTS SET ExpectedResponseDate = @ExpectedResponseDate WHERE IncidentId = @IncidentId
		SET DATEFIRST @SavedDatefirst
	END
END
GO
PRINT N'Altering [dbo].[TaskGetMinPossibleStartDate]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[TaskGetMinPossibleStartDate]
			@TaskId INT,
			@CalendarId INT,
			@retval Datetime output
AS
DECLARE @SavedDatefirst int
SET @SavedDatefirst = @@DATEFIRST
SET DATEFIRST 7
SET @retval = null
DECLARE @ProjectId INT, @OutlineNumber VARCHAR(255)
SELECT @OutlineNumber = OutlineNumber, @ProjectId = ProjectId FROM TASKS WHERE TaskId = @TaskId
SELECT @retval = MAX( CASE
			WHEN TL.Lag >= 0 THEN dbo.GetFinishDateByDuration(@CalendarId,T.FinishDate,TL.Lag)
			WHEN TL.Lag < 0 THEN dbo.GetStartDateByDuration(@CalendarId,T.FinishDate, -TL.Lag)
			    END)
  FROM TASKS T JOIN TASK_LINKS TL ON (T.TaskId = TL.PredId)
  WHERE 	T.ProjectId = @ProjectId
		AND TL.SuccId  IN (SELECT TaskId FROM TASKS WHERE ProjectId= @ProjectId AND (TaskId = @TaskId OR @OutlineNumber LIKE  OutlineNumber + '.%' ))
SET DATEFIRST @SavedDatefirst
GO
PRINT N'Altering [dbo].[TaskGetPredecessorDates]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].[TaskGetPredecessorDates]
			@TaskId INT,
			@CalendarId INT
AS
DECLARE @SavedDatefirst int
SET @SavedDatefirst = @@DATEFIRST
SET DATEFIRST 7
SELECT LinkId, PredId, FinishDate, Lag, CASE
	when lag >= 0 then DBO.GetFinishDateByDuration(@CalendarId,FinishDate,Lag)
	when lag < 0 then DBO.GetStartDateByDuration(@CalendarId,FinishDate,-Lag)
END As PossibleStartDate FROM  TASK_LINKS JOIN TASKS ON PredId = TaskId
WHERE SuccId = @TaskId
SET DATEFIRST @SavedDatefirst
GO
PRINT N'Altering [dbo].[Act_IssueUpdateExpectedValues]'
GO
ALTER PROCEDURE [dbo].[Act_IssueUpdateExpectedValues]
	@IssueId int,
	@ExpectedResponseTime int,
	@ExpectedDuration int,
	@retval int output
AS
UPDATE INCIDENTS
 SET ExpectedResponseTime = @ExpectedResponseTime, ExpectedDuration = @ExpectedDuration
 WHERE IncidentId = @IssueId AND
	(ExpectedResponseTime != @ExpectedResponseTime OR ExpectedDuration != @ExpectedDuration)
SET @retval = @@ROWCOUNT
IF @retval > 0
BEGIN
	DECLARE @SavedDatefirst int
	SET @SavedDatefirst = @@DATEFIRST
	SET DATEFIRST 7
	DECLARE @CalendarId int, @ExpectedResponseDate datetime, @ExpectedResolveDate datetime, @CreationDate datetime, @ActualOpenDate datetime
	SELECT @CalendarId = B.CalendarId, @CreationDate  = I.CreationDate, @ActualOpenDate = I.ActualOpenDate
	  FROM Incidents I
		JOIN IncidentBox B ON (I.IncidentBoxId = B.IncidentBoxId)
	  WHERE I.IncidentId = @IssueId
	IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
	        SET @CalendarId = (SELECT MIN(CalendarId) FROM Calendars)
	DECLARE @ContainerKey nvarchar(50), @ForumId int, @ThreadId int, @LastInDt datetime
	SET @ContainerKey = 'IncidentId_' + CAST(@IssueId AS varchar(10))
	SELECT @ForumId = ForumId FROM fsc_Forums WHERE ContainerKey = @ContainerKey
	IF @ForumId IS NOT NULL
	BEGIN
		SELECT @ThreadId = ThreadId FROM fsc_ForumThreads WHERE ForumId = @ForumId
		IF @ThreadId IS NOT NULL
		BEGIN
			SELECT @LastInDt = MAX(Created) FROM fsc_ForumThreadNodes WHERE ThreadId = @ThreadId AND NodeType = 1
		END
	END
	IF @LastInDt IS NULL
		SET @LastInDt = @CreationDate
	SET @ExpectedResponseDate = [dbo].GetFinishDateByDuration(@CalendarId, @LastInDt, @ExpectedResponseTime)
	SET @ExpectedResolveDate = [dbo].GetFinishDateByDuration(@CalendarId, @ActualOpenDate, @ExpectedDuration)
	UPDATE INCIDENTS
	 SET ExpectedResponseDate = @ExpectedResponseDate, ExpectedResolveDate = @ExpectedResolveDate
	 WHERE IncidentId = @IssueId
	SET DATEFIRST @SavedDatefirst
END
GO
PRINT N'Altering [dbo].[Act_IssueUpdateState]'
GO
ALTER PROCEDURE [dbo].[Act_IssueUpdateState]
	@IssueId int,
	@ValueId int,
	@retval int output
AS
IF @ValueId = 4 OR @ValueId = 5
	UPDATE INCIDENTS
	 SET StateId = @ValueId, ActualFinishDate = getutcdate()
	 WHERE IncidentId = @IssueId AND StateId != @ValueId
else
	UPDATE INCIDENTS
	 SET StateId = @ValueId, ActualFinishDate = null
	 WHERE IncidentId = @IssueId AND StateId != @ValueId
SET @retval = @@ROWCOUNT
IF @retval > 0 AND (@ValueId = 2 OR @ValueId = 6)
BEGIN
	DECLARE @SavedDatefirst int
	SET @SavedDatefirst = @@DATEFIRST
	SET DATEFIRST 7
	DECLARE @CalendarId int, @ExpectedResolveDate datetime, @ExpectedDuration int
	SELECT @CalendarId = B.CalendarId, @ExpectedDuration = I.ExpectedDuration
	  FROM Incidents I
		JOIN IncidentBox B ON (I.IncidentBoxId = B.IncidentBoxId)
	  WHERE I.IncidentId = @IssueId
	IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
	        SET @CalendarId = (SELECT MIN(CalendarId) FROM Calendars)
	SET @ExpectedResolveDate = [dbo].GetFinishDateByDuration(@CalendarId, getutcdate(), @ExpectedDuration)
	UPDATE INCIDENTS
		SET ActualOpenDate = getutcdate(), ExpectedResolveDate = @ExpectedResolveDate
		WHERE IncidentId = @IssueId
	SET DATEFIRST @SavedDatefirst
END
GO
PRINT N'Altering [dbo].[IncidentCreate]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[IncidentCreate]
	@ProjectId as int=null ,
	@CreatorId as int ,
	@Title as nvarchar(255) ,
	@Description as ntext,
	@CreationDate as datetime ,
	@TypeId as int ,
	@PriorityId as int ,
	@StateId as int ,
	@SeverityId as int ,
	@IsEmail as bit,
	@TaskTime int,
	@IncidentBoxId int,
	@ResponsibleId int,
	@IsResponsibleGroup int,
	@VCardId int,
	@OrgId int,
	@ExpectedDuration int,
	@ExpectedResponseTime int,
	@Identifier nvarchar(255) = NULL,
	@retval int output
as
DECLARE @SavedDatefirst int
SET @SavedDatefirst = @@DATEFIRST
SET DATEFIRST 7
IF @IncidentBoxId < 0
	SET @IncidentBoxId = null
IF @VCardId < 0
	SET @VCardId = null
IF @OrgId < 0
	SET @OrgId = null
DECLARE @CalendarId int, @ExpectedResponseDate datetime, @ExpectedResolveDate datetime
SELECT @CalendarId = CalendarId FROM IncidentBox WHERE IncidentBoxId = @IncidentBoxId
IF NOT EXISTS (SELECT * FROM Calendars WHERE CalendarId = @CalendarId)
        SET @CalendarId = (SELECT MIN(CalendarId) FROM Calendars)
SET @ExpectedResponseDate = [dbo].GetFinishDateByDuration(@CalendarId, @CreationDate, @ExpectedResponseTime)
SET @ExpectedResolveDate = [dbo].GetFinishDateByDuration(@CalendarId, @CreationDate, @ExpectedDuration)
INSERT INTO INCIDENTS (ProjectId, CreatorId, Title, [Description], CreationDate, TypeId, PriorityId, SeverityId, IsEmail, StateId, TaskTime,
	IncidentBoxId, ResponsibleId, IsResponsibleGroup,  VCardId, OrgId, ExpectedDuration, ExpectedResponseTime, Identifier,
	ModifiedDate, ActualOpenDate, ExpectedResponseDate, ExpectedResolveDate)
  VALUES(@ProjectId, @CreatorId, @Title, @Description, @CreationDate, @TypeId, @PriorityId, @SeverityId, @IsEmail, @StateId, @TaskTime,
	@IncidentBoxId,@ResponsibleId, @IsResponsibleGroup, @VCardId, @OrgId, @ExpectedDuration, @ExpectedResponseTime, @Identifier,
	@CreationDate, @CreationDate, @ExpectedResponseDate, @ExpectedResolveDate)
select @retval = @@identity
SET DATEFIRST @SavedDatefirst
GO
SET ANSI_NULLS ON
GO
