SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[OM_BINARYDELETE]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[OM_BINARYDELETE]
	@fid char(36),
	@retval int output
AS
IF(SELECT count(*) FROM BINARY_DATA f WHERE f.fid=@fid)=0
BEGIN
	SET @retval = 0
	RETURN
END
BEGIN TRAN
DECLARE @Error INT
DELETE FROM BINARY_DATA WHERE fid=@fid
SELECT @Error = @@Error, @retval=@@rowcount;
IF @Error = 0
	COMMIT
ELSE
	ROLLBACK
GO
PRINT N'Altering [dbo].[OM_KILL_ALL]'
GO
ALTER PROCEDURE [dbo].[OM_KILL_ALL]
	@TIME int,
	@RETVAL INT OUTPUT
AS
DECLARE @OFFLINE int
SET @OFFLINE = 0
BEGIN TRAN
	UPDATE Sessions SET Dt_End = @TIME WHERE Dt_End IS NULL
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE CHAT_USERS SET USER_STATUS = 0, [TIME] = @TIME WHERE USER_STATUS <> 0
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE [USER] SET status_time = @TIME WHERE [user_id] IN (SELECT [user_id] FROM Active_User)
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	INSERT INTO STATUS_LOG ([user_id], dt, status)
	  SELECT A.[user_id], getutcdate(), @OFFLINE
	  FROM Active_User A
		JOIN [USER] U ON (A.[user_id] = U.[user_id])
		JOIN IMGROUPS G ON (U.imgroup_id = G.imgroup_id)
		JOIN COMPANIES C ON (G.company_id = C.company_id)
	  WHERE C.log_user_status = 1
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	DECLARE @Error INT
	DELETE FROM Active_User
	SELECT @Error = @@ERROR, @RETVAL = @@ROWCOUNT;
	IF @Error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO
PRINT N'Altering [dbo].[OM_LOGOFF]'
GO
ALTER PROCEDURE [dbo].[OM_LOGOFF]
	@USER_ID INT,
	@DT_END INT,
	@RETVAL INT OUTPUT
AS
DECLARE @log_user_status bit, @OFFLINE int
SET @OFFLINE = 0
SELECT @log_user_status = log_user_status
  FROM COMPANIES C
	JOIN IMGROUPS G ON (C.company_id = G.company_id)
	JOIN [USER] U ON (G.imgroup_id = U.imgroup_id)
  WHERE [user_id] = @USER_ID
BEGIN TRAN
	UPDATE Sessions SET Dt_End = @DT_END WHERE [user_id] = @USER_ID AND Dt_End IS NULL
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE [USER] SET status_time = @DT_END WHERE [user_id] = @USER_ID
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	IF @log_user_status = 1
	BEGIN
		INSERT INTO STATUS_LOG ([user_id], dt, status)
		  VALUES (@USER_ID, getutcdate(), @OFFLINE)
		IF @@error != 0
		BEGIN
			ROLLBACK TRAN
			RETURN
		END
	END
	DECLARE @Error INT
	DELETE FROM Active_User WHERE [user_id] = @USER_ID
	SELECT @Error = @@Error, @retval=@@rowcount;
	IF @Error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO
PRINT N'Altering [dbo].[OM_ADD_ACTIVE_USER]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[OM_ADD_ACTIVE_USER]
	@USER_ID INT,
	@SID CHAR(36),
	@STATUS INT,
	@DT_BEGIN INT,
	@RETVAL INT OUTPUT
AS
DECLARE @log_user_status bit, @ACTIVE int
SET @ACTIVE = 1
SELECT @log_user_status = log_user_status
  FROM COMPANIES C
	JOIN IMGROUPS G ON (C.company_id = G.company_id)
	JOIN [USER] U ON (G.imgroup_id = U.imgroup_id)
  WHERE [user_id] = @USER_ID
BEGIN TRAN
	DELETE FROM Sessions WHERE [user_id] = @USER_ID AND Dt_Begin = @DT_BEGIN
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE Sessions SET Dt_End = Dt_Begin WHERE [user_id] = @USER_ID AND Dt_End IS NULL
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	INSERT INTO Sessions ([user_id], Dt_Begin) VALUES (@USER_ID, @DT_BEGIN)
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE [USER] SET status_time = @DT_BEGIN WHERE [user_id] = @USER_ID
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	IF @log_user_status = 1
	BEGIN
		INSERT INTO STATUS_LOG ([user_id], dt, status)
		  VALUES (@USER_ID, getutcdate(), @ACTIVE)
		IF @@error != 0
		BEGIN
			ROLLBACK TRAN
			RETURN
		END
	END
	DECLARE @Error INT
	INSERT INTO Active_User ([user_id], sid, status) VALUES (@USER_ID, @SID, @STATUS)
	SELECT @Error = @@ERROR, @RETVAL = @@ROWCOUNT;
	IF @Error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO
PRINT N'Altering [dbo].[OM_CHANGE_STATUS]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[OM_CHANGE_STATUS]
	@USER_ID INT,
	@STATUS INT,
	@RETVAL INT OUTPUT
AS
DECLARE @DT_BEGIN int, @NOW datetime
SET @NOW = GETUTCDATE()
SET @DT_BEGIN = DATEDIFF(s, '1970-01-01 00:00:00', @NOW)
DECLARE @log_user_status bit
SELECT @log_user_status = log_user_status
  FROM COMPANIES C
	JOIN IMGROUPS G ON (C.company_id = G.company_id)
	JOIN [USER] U ON (G.imgroup_id = U.imgroup_id)
  WHERE [user_id] = @USER_ID
BEGIN TRAN
	UPDATE [USER] SET status_time = @DT_BEGIN WHERE [user_id] = @USER_ID
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	IF @log_user_status = 1
	BEGIN
		INSERT INTO STATUS_LOG ([user_id], dt, status)
		  VALUES (@USER_ID, @NOW, @STATUS)
		IF @@error != 0
		BEGIN
			ROLLBACK TRAN
			RETURN
		END
	END
	DECLARE @Error INT
	UPDATE Active_User SET status = @STATUS WHERE [user_id] = @USER_ID
	SELECT @Error = @@ERROR, @RETVAL = @@ROWCOUNT;
	IF @Error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO
PRINT N'Creating [dbo].[ProductVersionGet]'
GO
CREATE PROCEDURE [dbo].[ProductVersionGet]
AS
SELECT SERVERPROPERTY('productversion')
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


DECLARE @ProductId INT

SELECT @ProductId = [ProductId] FROM [DL_PRODUCTS] WHERE [ProductGuid] = '1D12D687-8C24-4ADE-8DA2-73B422E1D110'
IF @ProductId IS NOT NULL
BEGIN
	UPDATE [DL_VERSIONS] SET [Build] = 705, [Date] = CONVERT(smalldatetime, '2008-08-28', 120) WHERE ProductId = @ProductId
END

SELECT @ProductId = [ProductId] FROM [DL_PRODUCTS] WHERE [ProductGuid] = 'F268745E-B9BB-4391-B342-8AD8272F9321'
IF @ProductId IS NOT NULL
BEGIN
	UPDATE [DL_VERSIONS] SET [Build] = 705, [Date] = CONVERT(smalldatetime, '2008-08-28', 120) WHERE ProductId = @ProductId
END
GO
