SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[TRIAL_REQUESTS]'
GO
ALTER TABLE [dbo].[TRIAL_REQUESTS] ADD
[Referrer] [nvarchar] (2048) COLLATE Cyrillic_General_CI_AS NULL
GO
PRINT N'Altering [dbo].[TRIAL_REQUESTS_FAILED]'
GO
ALTER TABLE [dbo].[TRIAL_REQUESTS_FAILED] ADD
[Referrer] [nvarchar] (2048) COLLATE Cyrillic_General_CI_AS NULL
GO
PRINT N'Altering [dbo].[TRIAL_RESELLERS]'
GO
ALTER TABLE [dbo].[TRIAL_RESELLERS] ADD
[ScopeId] [int] NULL
GO
PRINT N'Altering [dbo].[ASP_FAILED_TRIAL_REQUEST_GET]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ASP_FAILED_TRIAL_REQUEST_GET]
	@RequestID as int
AS
SELECT RequestID,ErrorCode, CompanyName, SizeOfGroup, [Description], Domain, FirstName, LastName, Email, Phone, Country, TimeZone, Login, Password, TimeZoneId, Locale, Referrer, R.ResellerId, RS.Title AS ResellerTitle
  FROM TRIAL_REQUESTS_FAILED R
  LEFT JOIN TRIAL_RESELLERS RS ON (R.ResellerId = RS.ResellerId)
  WHERE RequestID = @RequestID OR @RequestID = 0
GO
PRINT N'Altering [dbo].[ASP_TRIAL_REQUEST_CREATE]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[ASP_TRIAL_REQUEST_CREATE]
	@CompanyName as nvarchar(100),
	@SizeOfGroup as nvarchar(50),
	@Description as nvarchar(100),
	@Domain as nvarchar(255),
	@FirstName as nvarchar(100),
	@LastName as nvarchar(100),
	@Email as nvarchar(100),
	@Phone as nvarchar(50),
	@Country as nvarchar(100),
	@TimeZone as nvarchar(100),
	@Login as nvarchar(50),
	@Password as nvarchar(50),
	@ResellerGuid as uniqueidentifier,
	@Xml as nvarchar(4000),
	@UseIm as bit,
	@Locale as nvarchar(10),
	@TimeZoneId INT,
	@Referrer as nvarchar(2048),
	@retval as int output
AS
DECLARE @ResellerId int
SELECT @ResellerId = ResellerId FROM TRIAL_RESELLERS WHERE Guid = @ResellerGuid
IF @ResellerId IS NULL
	SELECT @ResellerId = ResellerId FROM TRIAL_RESELLERS WHERE IsDefault = 1
INSERT INTO TRIAL_REQUESTS (CompanyName, SizeOfGroup, Description, Domain, FirstName, LastName, Email, Phone, Country, TimeZone, Login, Password, ResellerId, Xml, UseIm, Locale, TimeZoneId, Referrer)
  VALUES (@CompanyName, @SizeOfGroup, @Description, @Domain, @FirstName, @LastName, @Email, @Phone, @Country, @TimeZone, @Login, @Password, @ResellerId, @Xml, @UseIm, @Locale, @TimeZoneId, @Referrer)
SET @retval = @@identity
GO
PRINT N'Altering [dbo].[ASP_TRIAL_REQUEST_GET]'
GO
ALTER PROCEDURE [dbo].[ASP_TRIAL_REQUEST_GET]
	@RequestId as int,
	@IncludeInactive as bit,
	@IncludeDeleted BIT
AS
SELECT R.RequestID, CompanyName, R.CompanyID, SizeOfGroup, R.Description, Domain, FirstName, LastName, Email, Phone, Country, TimeZone, Login, Password, R.ResellerId, RS.Title AS ResellerTitle, XML, R.GUID, UseIM, IsActive, IsDeleted, CreationDate, Locale, TimeZoneId, Referrer,
	CC.StatusId, S.Name AS StatusName, CC.Description AS StatusDescription, DATALENGTH(S.Icon) AS StatusIconLength
 FROM TRIAL_REQUESTS R
 JOIN TRIAL_RESELLERS RS ON (R.ResellerId = RS.ResellerId)
 LEFT JOIN CompanyComment CC ON CC.RequestId = R.RequestId
 LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE (R.RequestID = @RequestId OR @RequestId = 0)
	AND (IsActive = 1 OR @IncludeInactive = 1)
	AND (IsDeleted = 0 OR @IncludeDeleted = 1)
GO
PRINT N'Creating [dbo].[TrialScope]'
GO
SET ANSI_NULLS ON
GO
CREATE TABLE [dbo].[TrialScope]
(
[ScopeId] [int] NOT NULL IDENTITY(1, 1),
[Title] [nvarchar] (255) COLLATE Cyrillic_General_CI_AS NOT NULL
) ON [PRIMARY]
GO
PRINT N'Creating primary key [PK_TrialScope] on [dbo].[TrialScope]'
GO
ALTER TABLE [dbo].[TrialScope] ADD CONSTRAINT [PK_TrialScope] PRIMARY KEY CLUSTERED  ([ScopeId]) ON [PRIMARY]
GO
PRINT N'Altering [dbo].[ASP_FAILED_TRIAL_REQUEST_CREATE]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ASP_FAILED_TRIAL_REQUEST_CREATE]
	@CompanyName as nvarchar(100),
	@SizeOfGroup as nvarchar(50),
	@Description as nvarchar(100),
	@Domain as nvarchar(255),
	@FirstName as nvarchar(100),
	@LastName as nvarchar(100),
	@EMail as nvarchar(100),
	@Phone as nvarchar(50),
	@Country as nvarchar(100),
	@TimeZone as nvarchar(100),
	@Login as nvarchar(50),
	@Password as nvarchar(50),
	@ResellerGuid as uniqueidentifier,
	@TimeZoneId INT,
	@Locale NVARCHAR(10),
	@ErrorCode as int,
	@Referrer as nvarchar(2048),
	@retval as int output
AS
DECLARE @ResellerId int
SELECT @ResellerId = ResellerId FROM TRIAL_RESELLERS WHERE Guid = @ResellerGuid
INSERT INTO TRIAL_REQUESTS_FAILED (ErrorCode, CompanyName, SizeOfGroup, Description, Domain, FirstName, LastName, EMail, Phone, Country, TimeZone, Login, Password, ResellerId, TimeZoneId, Locale, Referrer)
  VALUES (@ErrorCode, @CompanyName, @SizeOfGroup, @Description, @Domain, @FirstName, @LastName, @EMail, @Phone, @Country, @TimeZone, @Login, @Password, @ResellerId, @TimeZoneId, @Locale, @Referrer)
SET @retval = @@identity
GO
SET ANSI_NULLS ON
GO
PRINT N'Adding foreign keys to [dbo].[TRIAL_RESELLERS]'
GO
ALTER TABLE [dbo].[TRIAL_RESELLERS] ADD
CONSTRAINT [FK_TRIAL_RESELLERS_TrialScope] FOREIGN KEY ([ScopeId]) REFERENCES [dbo].[TrialScope] ([ScopeId])
GO
