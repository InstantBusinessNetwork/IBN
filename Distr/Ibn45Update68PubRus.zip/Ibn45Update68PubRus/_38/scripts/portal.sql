SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[TaskResourcesResetPercent]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].TaskResourcesResetPercent
	@TaskId as int,
	@PercentCompleted int,
	@LastSavedDate datetime
as
UPDATE TASK_RESOURCES
  SET PercentCompleted = @PercentCompleted, LastSavedDate = @LastSavedDate, ActualFinishDate = null
  WHERE TaskId = @TaskId AND PercentCompleted = 100
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
if exists (select * from sysobjects where id = object_id(N'IBN.[ArticlesAdd]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure IBN.[ArticlesAdd]
GO
if exists (select * from sysobjects where id = object_id(N'[ArticlesAdd]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [ArticlesAdd]
GO
if exists (select * from dbo.sysobjects where id = object_id(N'IBN.[ArticlesIncreaseCounter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure IBN.[ArticlesIncreaseCounter]
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[ArticlesIncreaseCounter]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [ArticlesIncreaseCounter]
GO
if exists (select * from dbo.sysobjects where id = object_id(N'IBN.[ArticlesUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure IBN.[ArticlesUpdate]
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[ArticlesUpdate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [ArticlesUpdate]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].ArticlesAdd
	@Question as nvarchar(1000) ,
	@Answer as ntext,
	@AnswerHTML as ntext,
	@Tags as nvarchar(1000) ,
	@Delimiter nchar(1),
	@retval int output
as
INSERT INTO Articles (Question, Answer, AnswerHTML, Tags, Created, Counter, Delimiter)
  VALUES(@Question, @Answer, @AnswerHTML, @Tags, GETUTCDATE(), 0, @Delimiter)
SELECT @retval = @@identity
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].ArticlesIncreaseCounter
	@ArticleId int
as
UPDATE Articles
  SET Counter = Counter + 1
  WHERE ArticleId = @ArticleId
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].ArticlesUpdate
	@ArticleId int,
	@Question as nvarchar(1000) ,
	@Answer as ntext,
	@AnswerHTML as ntext,
	@Tags as nvarchar(1000),
	@Delimiter nchar(1)
as
UPDATE Articles
  SET Question=@Question, Answer=@Answer, AnswerHTML=@AnswerHTML, Tags=@Tags, Delimiter=@Delimiter
  WHERE ArticleId = @ArticleId
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON
GO
