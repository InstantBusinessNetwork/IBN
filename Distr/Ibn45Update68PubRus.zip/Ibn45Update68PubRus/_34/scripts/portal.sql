UPDATE [CONTENT_TYPES] SET ContentTypeString = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' WHERE Extension='docx'
UPDATE [CONTENT_TYPES] SET ContentTypeString = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' WHERE Extension='xlsx'
