SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[mc_ActualFinancesSelect]'
GO
ALTER PROCEDURE [dbo].[mc_ActualFinancesSelect]
(
@ActualFinancesId int
)
AS
    SET NOCOUNT ON
SELECT [ActualFinancesId],
[CreatorId],
[Date],
[ObjectId],
[ObjectTypeId],
[RowId],
[Value],
[Comment],
null AS [UserId]
FROM ActualFinances
WHERE
[ActualFinancesId] = @ActualFinancesId
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetAssignedToUser]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ToDoAndTasksGetAssignedToUser]
	@UserId as int,
	@ShowActive as bit,
	@FromDate datetime,
	@ToDate datetime
as
SET @ToDate = DATEADD(d, 1, @ToDate)
DECLARE @ActiveState int, @OverdueState int
SET @ActiveState = 2
SET @OverdueState  = 3
DECLARE @Now datetime, @MaxValue datetime, @MinValue datetime
SET @Now = getutcdate()
SET @MaxValue = DATEADD(yy, 100, @Now)
SET @MinValue = DATEADD(yy, -100, @Now)
SELECT DISTINCT T.ToDoId AS ItemId, T.Title,  T.IsCompleted, T.CompletionTypeId, T.ReasonId, 1 AS IsToDo, T.StateId, T.ManagerId, U.LastName,
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	ISNULL(T.FinishDate, DATEADD(yy, 100, T.CreationDate)) AS SortFinishDate,
	CASE WHEN T.CompletionTypeId = 1 THEN R.PercentCompleted ELSE T.PercentCompleted END AS PercentCompleted
  FROM TODO T
	JOIN USERS U ON (T.ManagerId = U.PrincipalId)
	JOIN TODO_RESOURCES R ON (T.ToDoId = R.ToDoId)
  WHERE (R.PrincipalId = @UserId OR R.PrincipalId IN (SELECT GroupId FROM USER_GROUP WHERE UserId = @UserId))
	AND NOT (R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0)
	AND
	(@ShowActive = 0 OR T.StateId = @ActiveState OR T.StateId = @OverdueState)
	AND
		CASE
			WHEN T.StartDate IS NOT NULL AND T.StartDate < ISNULL(T.ActualStartDate, @MaxValue) THEN T.StartDate
			WHEN T.ActualStartDate IS NOT NULL AND T.ActualStartDate < ISNULL(T.StartDate, @MaxValue) THEN T.ActualStartDate
			ELSE T.CreationDate
		END < @ToDate
	AND
		CASE
			WHEN T.FinishDate IS NOT NULL AND T.FinishDate > ISNULL(T.ActualFinishDate, @Now) THEN T.FinishDate
			WHEN T.ActualFinishDate IS NOT NULL AND T.ActualFinishDate > ISNULL(T.FinishDate, @MinValue) THEN T.ActualFinishDate
			WHEN T.ActualFinishDate IS NULL THEN @Now
			ELSE T.CreationDate
		END > @FromDate
UNION ALL
SELECT DISTINCT T.TaskId  AS ItemId, T.Title, T.IsCompleted, T.CompletionTypeId, T.ReasonId, 0 AS IsToDo, T.StateId, P.ManagerId, U.LastName,
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate, T.FinishDate AS SortFinishDate,
	CASE WHEN T.CompletionTypeId = 1 THEN R.PercentCompleted ELSE T.PercentCompleted END AS PercentCompleted
  FROM TASKS T
	JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
	JOIN USERS U ON (P.ManagerId = U.PrincipalId)
	JOIN TASK_RESOURCES R ON (T.TaskId = R.TaskId)
  WHERE R.PrincipalId = @UserId AND NOT (R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0)
	AND
	(@ShowActive = 0 OR T.StateId = @ActiveState OR T.StateId = @OverdueState)
	AND
		CASE
			WHEN T.StartDate < ISNULL(T.ActualStartDate, @MaxValue) THEN T.StartDate
			WHEN T.ActualStartDate IS NOT NULL AND T.ActualStartDate < T.StartDate THEN T.ActualStartDate
			ELSE T.CreationDate
		END < @ToDate
	AND
		CASE
			WHEN T.FinishDate > ISNULL(T.ActualFinishDate, @Now) THEN T.FinishDate
			WHEN T.ActualFinishDate IS NOT NULL AND T.ActualFinishDate > T.FinishDate THEN T.ActualFinishDate
			WHEN T.ActualFinishDate IS NULL THEN @Now
			ELSE T.CreationDate
		END > @FromDate
	AND T.IsSummary = 0 AND T.IsMilestone = 0
GO
PRINT N'Altering [dbo].[ObjectsGetForManagerViewGroupedByCategory]'
GO
ALTER PROCEDURE [dbo].[ObjectsGetForManagerViewGroupedByCategory]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
DECLARE @EventType int
SET @EventType = 4
SELECT DISTINCT C.CategoryId, C.CategoryName, 3 AS ItemType, PR.ProjectId AS ItemId, PR.Title, PR.PriorityId, P.PriorityName, PR.CreationDate, PR.StartDate, PR.FinishDate, PR.PercentCompleted, CAST(0 as bit) as IsCompleted,
	PR.ManagerId, 0 as ReasonId, PR.ProjectId, 0 as StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM CATEGORIES C
	JOIN OBJECT_CATEGORY OC ON (OC.ObjectTypeId=3 AND OC.CategoryId = C.CategoryId)
	JOIN PROJECTS PR ON (OC.ObjectId = PR.ProjectId)
	JOIN PROJECT_MEMBERS PM ON (PR.ProjectId = PM.ProjectId)
	JOIN PRIORITY_LANGUAGE P ON (PR.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN PROJECT_STATUS PS ON (PR.StatusId = PS.StatusId)
  WHERE (PM.PrincipalId = @PrincipalId OR PM.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND(PM.IsTeamMember=1)
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR PR.ProjectId=@ProjectId)
	AND
	(
	((@StartDate is not null)AND(PR.StartDate<=@StartDate)AND(PR.StatusId=4))
	OR((@CompletedDate is not null)AND(PR.ActualFinishDate>=@CompletedDate)AND(PS.IsActive=0))
	OR((@ShowActive=1 AND PS.IsActive = 1))
	)
UNION ALL
SELECT DISTINCT C.CategoryId, C.CategoryName, 5 AS ItemType, T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate, T.PercentCompleted, T.IsCompleted,
	PR.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM CATEGORIES C
	JOIN OBJECT_CATEGORY OC ON (OC.ObjectTypeId=5 AND OC.CategoryId = C.CategoryId)
	JOIN TASKS T ON (OC.ObjectId = T.TaskId)
	JOIN TASK_SECURITY TS ON (T.TaskId = TS.TaskId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN PROJECTS PR ON (T.ProjectId=PR.ProjectId)
  WHERE  (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (TS.IsRealTaskResource=1)
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId OR T.TaskId IN (SELECT TaskId FROM TASK_RESOURCES WHERE PrincipalId = @ManagerId AND CanManage = 1))
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT DISTINCT C.CategoryId, C.CategoryName, 6 AS ItemType, T.TodoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate, T.PercentCompleted, T.IsCompleted,
	T.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM CATEGORIES C
	JOIN OBJECT_CATEGORY OC ON (OC.ObjectTypeId=6 AND OC.CategoryId = C.CategoryId)
	JOIN TODO T ON (OC.ObjectId = T.TodoId)
	JOIN TODO_SECURITY_ALL TS ON (T.TodoId = TS.TodoId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (TS.IsResource=1)
	AND (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT DISTINCT C.CategoryId, C.CategoryName, 7 AS ItemType, I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, I.CreationDate, I.CreationDate as StartDate,
	I.ActualFinishdate as FinishDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	B.ManagerId, 0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM CATEGORIES C
	JOIN OBJECT_CATEGORY OC ON (OC.ObjectTypeId=7 AND OC.CategoryId = C.CategoryId)
	JOIN INCIDENTS I ON (OC.ObjectId = I.IncidentId)
	JOIN INCIDENT_SECURITY_ALL S ON (I.IncidentId = S.IncidentId)
	JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN PROJECTS PR ON (I.ProjectId = PR.ProjectId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealIncidentResource=1 OR S.IsIncidentResponsible = 1)
	AND (@ManagerId=0 OR B.ManagerId=@ManagerId OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
UNION ALL
SELECT DISTINCT C.CategoryId, C.CategoryName, 4 AS ItemType, E.EventId AS ItemId, E.Title, E.PriorityId, P.PriorityName, E.CreationDate, E.StartDate, E.FinishDate, 0 as PercentCompleted, CAST(0 as bit) as IsCompleted,
	E.ManagerId, 0 as ReasonId, E.ProjectId, E.StateId, 0 as CompletionTypeId,
	CASE WHEN R.RecurrenceId IS NULL THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS HasRecurrence
  FROM CATEGORIES C
	JOIN OBJECT_CATEGORY OC ON (OC.ObjectTypeId=4 AND OC.CategoryId = C.CategoryId)
	JOIN EVENTS E ON (OC.ObjectId = E.EventId)
	JOIN EVENT_SECURITY_ALL S ON (E.EventId = S.EventId)
	JOIN PRIORITY_LANGUAGE P ON (E.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	LEFT JOIN RECURRENCE R ON (E.EventId = R.ObjectId AND R.ObjectTypeId = @EventType)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsResource=1)
	AND (@ManagerId=0 OR E.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR E.ProjectId=@ProjectId)
	AND
	(
		(
			R.RecurrenceId IS NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.StateId=@UpcomingState)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StateId=@CompletedState)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
		OR
		(
			R.RecurrenceId IS NOT NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.FinishDate>=@dt)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StartDate<=@dt)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
	)
UNION ALL
SELECT DISTINCT C.CategoryId, C.CategoryName, 16 AS ItemType, D.DocumentId AS ItemId, D.Title, D.PriorityId, P.PriorityName, D.CreationDate, D.CreationDate as StartDate, D.ClosedDate as FinishDate, 0 as PercentCompleted, D.IsCompleted,
	D.ManagerId, D.ReasonId, D.ProjectId, D.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM CATEGORIES C
	JOIN OBJECT_CATEGORY OC ON (OC.ObjectTypeId=16 AND OC.CategoryId = C.CategoryId)
	JOIN DOCUMENTS D ON (OC.ObjectId = D.DocumentId)
	JOIN DOCUMENT_SECURITY_ALL S ON (D.DocumentId = S.DocumentId)
	JOIN PRIORITY_LANGUAGE P ON (D.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealDocumentResource=1)
	AND (@ManagerId=0 OR D.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR D.ProjectId=@ProjectId)
	AND
	(
	((@StartDate is not null)AND(D.CreationDate<=@StartDate)AND(D.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(D.ClosedDate>=@CompletedDate)AND(D.IsCompleted=1))
	OR((@ShowActive=1 AND (D.StateId=@ActiveState OR D.StateId=@OverdueState)))
	)
ORDER BY C.CategoryId, ItemType
GO
PRINT N'Altering [dbo].[ObjectsGetForManagerViewGroupedByUser]'
GO
ALTER PROCEDURE [dbo].[ObjectsGetForManagerViewGroupedByUser]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
DECLARE @EventType int
SET @EventType = 4
SELECT U.PrincipalId, U.FirstName, U.LastName, 5 AS ItemType, T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate,
	T.ActualStartDate, T.ActualFinishDate, T.PercentCompleted, T.IsCompleted,
	PR.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN TASK_SECURITY TS ON (U.PrincipalId = TS.PrincipalId)
	JOIN TASKS T ON (TS.TaskId = T.TaskId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN PROJECTS PR ON (T.ProjectId=PR.ProjectId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND(TS.IsRealTaskResource=1)
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId OR T.TaskId IN (SELECT TaskId FROM TASK_RESOURCES WHERE PrincipalId = @ManagerId AND CanManage = 1))
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND @OrgId=0 AND @VCardId=0 AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 6 AS ItemType, T.TodoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate,
	T.ActualStartDate, T.ActualFinishDate, T.PercentCompleted, T.IsCompleted,
	T.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN TODO_SECURITY_ALL TS ON (U.PrincipalId = TS.PrincipalId)
	JOIN TODO T ON (TS.TodoId = T.TodoId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (TS.IsResource=1)
	AND (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND (@OrgId=0 OR T.OrgId=@OrgId)
	AND (@VCardId=0 OR T.VCardId=@VCardId)
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 7 AS ItemType, I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, I.CreationDate, I.CreationDate as StartDate, null as FinishDate,
	I.ActualOpenDate as ActualStartDate, I.ActualfinishDate as ActualFinishDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	B.ManagerId, 0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN INCIDENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN INCIDENTS I ON (S.IncidentId = I.IncidentId)
	JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN PROJECTS PR ON (I.ProjectId = PR.ProjectId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealIncidentResource=1 OR S.IsIncidentResponsible = 1)
	AND (@ManagerId=0 OR B.ManagerId=@ManagerId OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND (@OrgId=0 OR I.OrgId=@OrgId)
	AND (@VCardId=0 OR I.VCardId=@VCardId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 4 AS ItemType, E.EventId AS ItemId, E.Title, E.PriorityId, P.PriorityName, E.CreationDate, E.StartDate, E.FinishDate,
	null as ActualStartDate, null as ActualFinishDate, 0 as PercentCompleted, CAST(0 as bit) as IsCompleted,
	E.ManagerId, 0 as ReasonId, E.ProjectId, E.StateId, 0 as CompletionTypeId,
	CASE WHEN R.RecurrenceId IS NULL THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS HasRecurrence
  FROM Users U
	JOIN EVENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN EVENTS E ON (S.EventId = E.EventId)
	JOIN PRIORITY_LANGUAGE P ON (E.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	LEFT JOIN RECURRENCE R ON (E.EventId = R.ObjectId AND R.ObjectTypeId = @EventType)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsResource=1)
	AND (@ManagerId=0 OR E.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR E.ProjectId=@ProjectId)
	AND (@OrgId=0 OR E.OrgId=@OrgId)
	AND (@VCardId=0 OR E.VCardId=@VCardId)
	AND
	(
		(
			R.RecurrenceId IS NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.StateId=@UpcomingState)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StateId=@CompletedState)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
		OR
		(
			R.RecurrenceId IS NOT NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.FinishDate>=@dt)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StartDate<=@dt)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 16 AS ItemType, D.DocumentId AS ItemId, D.Title, D.PriorityId, P.PriorityName, D.CreationDate, D.CreationDate as StartDate, null as FinishDate,
	null as ActualStartDate, D.ClosedDate as ActualFinishDate, 0 as PercentCompleted, D.IsCompleted,
	D.ManagerId, D.ReasonId, D.ProjectId, D.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN DOCUMENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN DOCUMENTS D ON (S.DocumentId = D.DocumentId)
	JOIN PRIORITY_LANGUAGE P ON (D.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealDocumentResource=1)
	AND (@ManagerId=0 OR D.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR D.ProjectId=@ProjectId)
	AND (@OrgId=0 OR D.OrgId=@OrgId)
	AND (@VCardId=0 OR D.VCardId=@VCardId)
	AND
	(
	((@StartDate is not null)AND(D.CreationDate<=@StartDate)AND(D.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(D.ClosedDate>=@CompletedDate)AND(D.IsCompleted=1))
	OR((@ShowActive=1 AND (D.StateId=@ActiveState OR D.StateId=@OverdueState)))
	)
ORDER BY U.PrincipalId, ItemType, ItemId
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
