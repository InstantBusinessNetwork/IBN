SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[COMPANIES]'
GO
ALTER TABLE [dbo].[COMPANIES] ADD
[DisableScheduleService] [bit] NOT NULL CONSTRAINT [DF_COMPANIES_DisableScheduleService] DEFAULT ((0))
GO
PRINT N'Altering [dbo].[ASP_GET_COMPANY]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ASP_GET_COMPANY]
	@company_type INT,
	@company_id INT
AS
SELECT company_id, company_name, domain, [db_name], app_id, C.description, contact_name, contact_phone, contact_email, support_name, support_email, product_name,
	theme, use_im, title1, title2, text1, text2, max_users, max_external_users, is_global, creation_date, company_type, start_date, end_date, rate_per_user, is_active, max_disk_space,
	enable_alerts, show_admin_wizard, use_ssl, firstdayofweek, Port, DisableScheduleService,
	CC.StatusId, S.Name AS StatusName, CC.Description AS StatusDescription, DATALENGTH(S.Icon) AS StatusIconLength, C.log_user_status
 FROM Companies C
LEFT JOIN CompanyComment CC ON CC.CompanyId = company_id
LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE (company_id = @company_id OR @company_id = 0) AND (company_type=@company_type OR @company_type=0)
 ORDER BY company_name
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


DECLARE @ProductId INT

SELECT @ProductId = [ProductId] FROM [DL_PRODUCTS] WHERE [ProductGuid] = '1D12D687-8C24-4ADE-8DA2-73B422E1D110'
IF @ProductId IS NOT NULL
BEGIN
	UPDATE [DL_VERSIONS] SET [Build] = 704, [Date] = CONVERT(smalldatetime, '2008-06-18', 120) WHERE ProductId = @ProductId
END

SELECT @ProductId = [ProductId] FROM [DL_PRODUCTS] WHERE [ProductGuid] = 'F268745E-B9BB-4391-B342-8AD8272F9321'
IF @ProductId IS NOT NULL
BEGIN
	UPDATE [DL_VERSIONS] SET [Build] = 704, [Date] = CONVERT(smalldatetime, '2008-06-18', 120) WHERE ProductId = @ProductId
END
GO
