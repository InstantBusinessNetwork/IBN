SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Altering [dbo].[HISTORY]'
GO
ALTER TABLE [dbo].[HISTORY] ADD
[IsView] [bit] NOT NULL CONSTRAINT [DF_HISTORY_IsView] DEFAULT (1)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ListDelete]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].ListDelete
	@ListId as int
 as
DECLARE @ListObjectType int
SET @ListObjectType = 15
DELETE FROM FAVORITES WHERE ObjectId = @ListId AND ObjectTypeId = @ListObjectType
DELETE SUBSCRIPTIONS WHERE ObjectId = @ListId AND EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @ListObjectType)
DELETE FROM TAGS WHERE ObjectId = @ListId AND ObjectTypeId = @ListObjectType
DELETE FROM HISTORY WHERE ObjectId = @ListId AND ObjectTypeId = @ListObjectType
DELETE FROM LISTS  WHERE ListId = @ListId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[EventDelete]'
GO
ALTER PROCEDURE [dbo].EventDelete
	@EventId as int
as
DECLARE @EventObjectType int
SET @EventObjectType = 4
BEGIN TRAN
	DELETE DISCUSSIONS WHERE ObjectTypeId = @EventObjectType AND ObjectId = @EventId
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @EventObjectType AND ObjectId = @EventId
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @EventObjectType AND ObjectId = @EventId
	IF @@ERROR != 0
		GOTO err
	DELETE RECURRENCE WHERE ObjectTypeId = @EventObjectType AND ObjectId = @EventId
	IF @@ERROR != 0
		GOTO err
	DELETE EVENT_RESOURCES WHERE EventId = @EventId
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @EventObjectType AND ObjectId = @EventId
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId = @EventId AND EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @EventObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE REMINDER_SUBSCRIPTIONS WHERE ObjectId = @EventId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @EventObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE ObjectId = @EventId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @EventObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_HOOKS WHERE ObjectId = @EventId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @EventObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @EventObjectType AND ObjectId = @EventId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @EventObjectType AND ObjectId = @EventId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM EVENTS  WHERE EventId = @EventId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ArticlesDelete]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].ArticlesDelete
	@ArticleId as int
as
DECLARE @ArticleType int
SET @ArticleType = 20
DELETE FROM History WHERE ObjectTypeId = @ArticleType AND ObjectId = @ArticleId
DELETE FROM Tags WHERE ObjectTypeId = @ArticleType AND ObjectId = @ArticleId
DELETE FROM Articles  WHERE ArticleId = @ArticleId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mc_VCardDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[mc_VCardDelete]
(
@VCardId int
)
AS
    SET NOCOUNT ON
DECLARE @ObjectType int
SET @ObjectType = 22
DELETE FROM TAGS WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM [VCard] WHERE [VCardId] = @VCardId RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ArticlesIncreaseCounter]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE ArticlesIncreaseCounter
	@ArticleId int
as
UPDATE Articles
  SET Counter = Counter + 1
  WHERE ArticleId = @ArticleId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[HistoryAdd]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].HistoryAdd
	@ObjectTypeId as int ,
	@ObjectId as int ,
	@ObjectTitle nvarchar(250),
	@UserId as int,
	@IsView as bit
AS
IF  NOT EXISTS(SELECT * FROM HISTORY WHERE ObjectTypeId = @ObjectTypeId AND ObjectId = @ObjectId AND UserId = @UserId AND IsView = @IsView)
	INSERT INTO HISTORY (ObjectTypeId, ObjectId, UserId, ObjectTitle, IsView) VALUES(@ObjectTypeId, @ObjectId, @UserId, @ObjectTitle, @IsView)
ELSE
	UPDATE HISTORY
	  SET Dt = getutcdate(), ObjectTitle = @ObjectTitle
	  WHERE ObjectTypeId = @ObjectTypeId AND ObjectId = @ObjectId AND UserId = @UserId AND IsView = @IsView
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[HistoryGetFull]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].HistoryGetFull
	@UserId as int
as
SELECT  HistoryId, ObjectTypeId, ObjectId, ObjectTitle, Dt, IsView
  FROM HISTORY
  WHERE UserId = @UserId
  ORDER BY IsView, Dt DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ArticlesGetByUser]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].ArticlesGetByUser
	@UserId as int
as
DECLARE @ArticleObjectType int
SET @ArticleObjectType = 20
SELECT ArticleId, Question, Answer, AnswerHTML
  FROM Articles A
	JOIN HISTORY H ON (A.ArticleId = H.ObjectId AND H.ObjectTypeId = @ArticleObjectType)
  WHERE H.UserId = @UserId AND IsView = 0
  ORDER BY H.Dt DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fsc_ForumContainerKeyByNodeId]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].[fsc_ForumContainerKeyByNodeId]
@NodeId int
AS
SELECT [ContainerKey]
FROM fsc_Forums F
INNER JOIN fsc_ForumThreads FT ON F.ForumId = FT.ForumId
INNER JOIN fsc_ForumThreadNodes FTN ON FT.ThreadId = FTN.ThreadId
WHERE FTN.NodeId = @NodeId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[HistoryGet]'
GO
ALTER PROCEDURE [dbo].HistoryGet
	@UserId as int
as
SELECT TOP 100 HistoryId, ObjectTypeId, ObjectId, ObjectTitle, Dt
  FROM HISTORY
  WHERE UserId = @UserId AND IsView = 1
  ORDER BY Dt DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[HistoryGetByObject]'
GO
ALTER PROCEDURE [dbo].HistoryGetByObject
	@ObjectId as int,
	@ObjectTypeId as int
as
SELECT UserId, Dt
  FROM HISTORY
  WHERE ObjectId = @ObjectId AND ObjectTypeId = @ObjectTypeId AND IsView = 1
  ORDER BY Dt DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ToDoDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].ToDoDelete
	@ToDoId as int
AS
DECLARE @TodoObjectType int
SET @TodoObjectType = 6
BEGIN TRAN
	DELETE DISCUSSIONS WHERE ObjectTypeId = @TodoObjectType AND ObjectId = @ToDoId
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @TodoObjectType AND ObjectId = @ToDoId
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @TodoObjectType AND ObjectId = @ToDoId
	IF @@ERROR != 0
		GOTO err
	DELETE TODO_RESOURCES WHERE ToDoId = @ToDoId
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @TodoObjectType AND ObjectId = @ToDoId
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId = @ToDoId AND EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @TodoObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE REMINDER_SUBSCRIPTIONS WHERE ObjectId = @ToDoId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TodoObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE ObjectId = @ToDoId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TodoObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_HOOKS WHERE ObjectId = @ToDoId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TodoObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @TodoObjectType AND ObjectId = @ToDoId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @TodoObjectType AND ObjectId = @ToDoId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM TODO  WHERE ToDoId = @ToDoId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[mdpsp_sys_CreateMetaClass]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].mdpsp_sys_CreateMetaClass
	@Namespace 		NVARCHAR(1024),
	@Name 		NVARCHAR(256),
	@FriendlyName		NVARCHAR(256),
	@TableName 		NVARCHAR(256),
	@ParentClassId 		INT,
	@IsSystem		BIT,
	@IsAbstract		BIT	=	0,
	@Description 		NTEXT,
	@Retval 		INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON
	SET @Retval = -1
BEGIN TRAN
	INSERT INTO [MetaClass] ([Namespace],[Name], [FriendlyName],[Description], [TableName], [ParentClassId], [IsSystem], [IsAbstract])
		VALUES (@Namespace, @Name, @FriendlyName, @Description, @TableName, @ParentClassId, @IsSystem, @IsAbstract)
	IF @@ERROR <> 0 GOTO ERR
	SET @Retval = @@IDENTITY
	IF @IsSystem = 1
	BEGIN
		IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE [NAME] = @TableName AND [type] = 'U')
		BEGIN
			RAISERROR ('Wrong System TableName.', 16,1 )
			GOTO ERR
		END
		INSERT INTO [MetaField]  ([Namespace], [Name], [FriendlyName], [SystemMetaClassId], [DataTypeId], [Length], [AllowNulls],  [SaveHistory], [MultiLanguageValue], [AllowSearch])
			 SELECT @Namespace+ N'.' + @Name, SC .[name] , SC .[name] , @Retval ,MDT .[DataTypeId], SC .[length], SC .[isnullable], 0, 0, 0  FROM SYSCOLUMNS AS SC
				INNER JOIN SYSOBJECTS SO ON SO.[ID] = SC.ID
				INNER JOIN SYSTYPES ST ON ST.[xtype] = SC .[xtype]
				INNER JOIN MetaDataType MDT ON MDT.[Name] = ST .[name]
			WHERE SO.[ID]  = object_id( @TableName) and OBJECTPROPERTY( SO.[ID], N'IsTable') = 1 and ST.name<>'sysname'
		IF @@ERROR<> 0 GOTO ERR
		INSERT INTO [MetaClassMetaFieldRelation]  (MetaClassId, MetaFieldId)
			SELECT @Retval, MetaFieldId FROM MetaField WHERE [SystemMetaClassId] = @Retval
	END
	ELSE
	BEGIN
		IF @IsAbstract = 0
		BEGIN
			IF EXISTS(SELECT * FROM SYSOBJECTS WHERE [NAME] = @TableName AND [type] = 'U')
				EXEC('DROP TABLE [dbo].[' + @TableName  + ']')
			IF EXISTS(SELECT * FROM SYSOBJECTS WHERE [NAME] = (@TableName + '_History') AND [type] = 'U')
				EXEC('DROP TABLE [dbo].[' + @TableName + '_History]')
			EXEC('CREATE TABLE [dbo].[' + @TableName  + '] ([ObjectId] [int] NOT NULL , [CreatorId] [int]  , [Created] [datetime], [ModifierId] [int]  , [Modified] [datetime] ) ON [PRIMARY]')
			IF @@ERROR <> 0 GOTO ERR
			EXEC('ALTER TABLE [dbo].[' + @TableName  + '] WITH NOCHECK ADD CONSTRAINT [PK_' + @TableName  + '] PRIMARY KEY  CLUSTERED ([ObjectId])  ON [PRIMARY]')
			IF @@ERROR <> 0 GOTO ERR
			EXEC('CREATE TABLE [dbo].[' + @TableName  + '_History] ([Id] [int] IDENTITY (1, 1)  NOT NULL, [ObjectId] [int] NOT NULL , [ModifierId] [int]  ,	[Modified] [datetime] ) ON [PRIMARY]')
			IF @@ERROR <> 0 GOTO ERR
			EXEC('ALTER TABLE [dbo].[' + @TableName  + '_History] WITH NOCHECK ADD CONSTRAINT [PK_' + @TableName  + '_History] PRIMARY KEY  CLUSTERED ([Id])  ON [PRIMARY]')
			IF @@ERROR<> 0 GOTO ERR
			IF EXISTS(SELECT * FROM MetaClass WHERE MetaClassId = @ParentClassId  )
			BEGIN
				INSERT INTO [MetaClassMetaFieldRelation]  (MetaClassId, MetaFieldId)
					SELECT @Retval, MetaFieldId FROM MetaField WHERE [SystemMetaClassId] = @ParentClassId
			END
			IF @@ERROR<> 0 GOTO ERR
			EXEC mdpsp_sys_CreateMetaClassProcedure @Retval
			IF @@ERROR <> 0 GOTO ERR
		END
	END
	DECLARE @PrimaryKeyName	NVARCHAR(256)
	SELECT @PrimaryKeyName = name FROM Sysobjects WHERE OBJECTPROPERTY(id, N'IsPrimaryKey') = 1 and parent_obj = OBJECT_ID(@TableName) and OBJECTPROPERTY(parent_obj, N'IsUserTable') = 1
	IF @PrimaryKeyName IS NOT NULL
		UPDATE [MetaClass] SET PrimaryKeyName = @PrimaryKeyName WHERE MetaClassId = @Retval
	COMMIT TRAN
RETURN
ERR:
	ROLLBACK TRAN
	SET @Retval = -1
RETURN
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[IncidentDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].IncidentDelete
	@IncidentId as int
as
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
BEGIN TRAN
	DELETE DISCUSSIONS WHERE ObjectTypeId = @IncidentObjectType AND ObjectId = @IncidentId
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @IncidentObjectType AND ObjectId = @IncidentId
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @IncidentObjectType AND ObjectId = @IncidentId
	IF @@ERROR != 0
		GOTO err
	DELETE INCIDENT_RESOURCES WHERE IncidentId = @IncidentId
	IF @@ERROR != 0
		GOTO err
	DELETE INCIDENT_RELATIONS WHERE IncidentId = @IncidentId OR RelIncidentId = @IncidentId
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @IncidentObjectType AND ObjectId = @IncidentId
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId = @IncidentId AND EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @IncidentObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @IncidentObjectType AND ObjectId = @IncidentId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @IncidentObjectType AND ObjectId = @IncidentId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM INCIDENTS  WHERE IncidentId = @IncidentId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[OrganizationDelete]'
GO
ALTER PROCEDURE [dbo].OrganizationDelete
	@OrgId as int
as
DECLARE @ObjectType int
SET @ObjectType = 21
DELETE FROM TAGS WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM ORGANIZATIONS WHERE OrgId = @OrgId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[UserDelete]'
GO
ALTER PROCEDURE [dbo].UserDelete
	@UserId as int
as
DECLARE @BatchAlertType int
SET @BatchAlertType = 9
DECLARE @UserType int
SET @UserType = 1
BEGIN TRAN
	DELETE COLLAPSED_TASKS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_ACCOUNTS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_INCIDENTS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_USERTIMESHEETS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_MANAGERTIMESHEETS WHERE UserId = @UserId OR ManagerId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_PROJECT_TEAM WHERE MemberId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_PROJECT_TEAM WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE CONTAINERSHIP WHERE PrincipalId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE SCHEDULE WHERE UserId = @UserId OR ContUserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE SHARING WHERE UserId = @UserId OR ProUserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE DateTypeId = @BatchAlertType AND ObjectId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE TIMESHEET_TODO WHERE TimesheetToDoId IN
		(SELECT ObjectId FROM TIMESHEETS T WHERE T.ObjectTypeId = 11 AND WeekTimeSheetId IN
			(SELECT WeekTimeSheetId FROM WeekTimeSheet WHERE UserId = @UserId))
	IF @@ERROR != 0
		GOTO err
	DELETE TIMESHEETS WHERE WeekTimeSheetId IN (SELECT WeekTimeSheetId FROM WeekTimeSheet WHERE UserId = @UserId)
	IF @@ERROR != 0
		GOTO err
	DELETE WeekTimeSheet WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE STUBS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE BroadCastMessages WHERE CreatorId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE PORTAL_LOGINS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	UPDATE SYSTEM_EVENTS SET UserId = NULL WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE LIST_ACCESS WHERE PrincipalId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @UserType AND ObjectId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @UserType AND ObjectId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_GROUP WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_SETTINGS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_PREFERENCES WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USER_DETAILS WHERE UserId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE USERS WHERE PrincipalId = @UserId
	IF @@ERROR != 0
		GOTO err
	DELETE PRINCIPALS WHERE PrincipalId = @UserId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[HistoryPurge]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE [dbo].HistoryPurge
as
DELETE HISTORY
  WHERE ObjectTypeId = 1
	AND ObjectId NOT IN (SELECT PrincipalId FROM Users)
DELETE HISTORY
  WHERE ObjectTypeId = 2
	AND ObjectId NOT IN (SELECT PrincipalId FROM Groups)
DELETE HISTORY
  WHERE ObjectTypeId = 3
	AND ObjectId NOT IN (SELECT ProjectId FROM Projects)
DELETE HISTORY
  WHERE ObjectTypeId = 4
	AND ObjectId NOT IN (SELECT EventId FROM Events)
DELETE HISTORY
  WHERE ObjectTypeId = 5
	AND ObjectId NOT IN (SELECT TaskId FROM Tasks)
DELETE HISTORY
  WHERE ObjectTypeId = 6
	AND ObjectId NOT IN (SELECT TodoId FROM Todo)
DELETE HISTORY
  WHERE ObjectTypeId = 7
	AND ObjectId NOT IN (SELECT IncidentId FROM Incidents)
DELETE HISTORY
  WHERE ObjectTypeId = 8
	AND ObjectId NOT IN (SELECT FileId FROM fsc_Files)
DELETE HISTORY
  WHERE ObjectTypeId = 10
	AND ObjectId NOT IN (SELECT DirectoryId FROM fsc_Directories)
DELETE HISTORY
  WHERE ObjectTypeId = 11
	AND ObjectId NOT IN (SELECT TimesheetTodoId FROM TIMESHEET_TODO)
DELETE HISTORY
  WHERE ObjectTypeId = 13
	AND ObjectId NOT IN (SELECT ProjectGroupId FROM PROJECT_GROUPS)
DELETE HISTORY
  WHERE ObjectTypeId = 14
	AND ObjectId NOT IN (SELECT TimesheetId FROM TIMESHEETS)
DELETE HISTORY
  WHERE ObjectTypeId = 15
	AND ObjectId NOT IN (SELECT ListId FROM LISTS)
DELETE HISTORY
  WHERE ObjectTypeId = 16
	AND ObjectId NOT IN (SELECT DocumentId FROM Documents)
DELETE HISTORY
  WHERE ObjectTypeId = 19
	AND ObjectId NOT IN (SELECT IncidentBoxId FROM IncidentBox)
DELETE HISTORY
  WHERE ObjectTypeId = 20
	AND ObjectId NOT IN (SELECT ArticleId FROM Articles)
DELETE HISTORY
  WHERE ObjectTypeId = 21
	AND ObjectId NOT IN (SELECT OrgId FROM Organizations)
DELETE HISTORY
  WHERE ObjectTypeId = 22
	AND ObjectId NOT IN (SELECT VCardId FROM VCard)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[TaskDelete]'
GO
ALTER PROCEDURE [dbo].TaskDelete
	@UpdateId char(36),
	@TaskId as int
AS
DECLARE @TaskObjectType int
DECLARE @AfterTaskNum int
SET @TaskObjectType = 5
DECLARE @ProjectId INT, @OutlineNumber VarChar(255)
SELECT @ProjectId = ProjectId, @OutlineNumber = OutlineNumber, @AfterTaskNum = TaskNum - 1 FROM TASKS WHERE TaskId = @TaskId
BEGIN TRAN
	DECLARE @AfterId INT
	SET @AfterId = -1
	DECLARE @DeletedTask TABLE (TaskId INT)
	DECLARE @DelCount INT
	INSERT INTO @DeletedTask (TaskId) SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId AND (OutlineNumber LIKE @OutlineNumber + '.%' OR TaskId = @TaskId)
	IF @@ERROR != 0
		GOTO err
	SELECT @DelCount = COUNT(*) FROM @DeletedTask
	SELECT @AfterId = TaskId FROM TASKS WHERE ProjectId = @ProjectId AND TaskNum = 1+ (SELECT MAX(TaskNum) FROM TASKS WHERE ProjectId = @ProjectId AND (OutlineNumber LIKE @OutlineNumber + '.%' OR TaskId = @TaskId))
	IF @@ERROR != 0
		GOTO err
	INSERT INTO TASK_UPDATES (UpdateId, TaskId) SELECT @UpdateId,SuccId FROM TASK_LINKS WHERE EXISTS(SELECT TaskId FROM @DeletedTask WHERE PredId = TaskId)
				   									 AND NOT EXISTS(SELECT TaskId FROM @DeletedTask WHERE SuccId = TaskId)
	Select * from TASK_UPDATES
	IF @@ERROR != 0
		GOTO err
	DELETE FROM TASK_LINKS WHERE EXISTS(SELECT TaskId FROM @DeletedTask WHERE PredId = TaskId)
			  OR EXISTS(SELECT TaskId FROM @DeletedTask WHERE SuccId = TaskId)
	IF @@ERROR != 0
		GOTO err
	UPDATE TASKS SET TaskNum = TaskNum - @DelCount WHERE ProjectId = @ProjectId AND TaskNum > @AfterTaskNum
	DECLARE @OutlineLevel INT
	SET @OutlineLevel = -1
	SELECT @OutlineLevel = OutlineLevel FROM TASKS WHERE ProjectId = @ProjectId AND TaskNum = @AfterTaskNum
	UPDATE TASKS SET  IsSummary = 0 WHERE ProjectId = @ProjectId AND TaskNum = @AfterTaskNum
	DELETE FROM TASKS WHERE TaskId IN (SELECT TaskId FROM @DeletedTask)
	IF @@ERROR != 0
		GOTO err
	UPDATE TASKS SET  IsSummary = 1 WHERE ProjectId = @ProjectId AND TaskId IN
	(SELECT F.TaskId FROM TASKS F
	JOIN TASKS S ON (F.TaskNum +1 = S.TaskNum)
	WHERE @ProjectId = S.ProjectId AND @ProjectId = F.ProjectId AND F.OutlineLevel +1 = S.OutlineLevel)
	IF(@AfterId != -1)
		EXEC TaskRenumFrom @AfterId
		IF @@ERROR != 0
		GOTO err
	DELETE DISCUSSIONS WHERE ObjectTypeId = @TaskObjectType AND ObjectId = @TaskId
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @TaskObjectType AND ObjectId = @TaskId
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @TaskObjectType AND ObjectId = @TaskId
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @TaskObjectType AND ObjectId = @TaskId
	IF @@ERROR != 0
		GOTO err
	DELETE TASK_RESOURCES WHERE TaskId = @TaskId
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId = @TaskId AND EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @TaskObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE REMINDER_SUBSCRIPTIONS WHERE ObjectId = @TaskId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TaskObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE ObjectId = @TaskId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TaskObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_HOOKS WHERE ObjectId = @TaskId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TaskObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE TASK_LINKS  WHERE PredId = @TaskId OR SuccId = @TaskId
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @TaskObjectType AND ObjectId = @TaskId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @TaskObjectType AND ObjectId = @TaskId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM TASKS  WHERE TaskId = @TaskId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ProjectDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].ProjectDelete
	@ProjectId as int
as
DECLARE @ProjectObjectType int
SET @ProjectObjectType = 3
BEGIN TRAN
	DELETE DISCUSSIONS WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE PROJECT_MEMBERS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_INCIDENTS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE COLLAPSED_USERTIMESHEETS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE PROJECT_SNAPSHOTS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE ACTUAL_FINANCES WHERE AccountId IN (SELECT AccountId FROM ACCOUNTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE ACCOUNTS WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId = @ProjectId AND EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @ProjectObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE REMINDER_SUBSCRIPTIONS WHERE ObjectId = @ProjectId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @ProjectObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE ObjectId = @ProjectId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @ProjectObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_HOOKS WHERE ObjectId = @ProjectId AND DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @ProjectObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE PROJECT_RELATIONS WHERE ProjectId = @ProjectId OR RelProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @ProjectObjectType AND ObjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM PROJECTS  WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[GroupDelete]'
GO
ALTER PROCEDURE [dbo].GroupDelete
	@GroupId as int
as
DECLARE @GroupType int
SET @GroupType = 2
BEGIN TRAN
	DELETE FROM BroadCastRecipients WHERE GroupId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM EVENT_RESOURCES WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM INCIDENT_RESOURCES WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM PARTNER_GROUP WHERE GroupId = @GroupId OR PartnerId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM HISTORY WHERE ObjectId = @GroupId AND ObjectTypeId = @GroupType
	IF @@ERROR != 0
		GOTO err
	DELETE FROM GROUPS WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM PRINCIPALS WHERE PrincipalId = @GroupId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[DocumentDelete]'
GO
ALTER PROCEDURE [dbo].DocumentDelete
	@DocumentId as int
as
DECLARE @DocumentObjectType int
SET @DocumentObjectType = 16
BEGIN TRAN
	DELETE DISCUSSIONS WHERE ObjectTypeId = @DocumentObjectType AND ObjectId = @DocumentId
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @DocumentObjectType AND ObjectId = @DocumentId
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @DocumentObjectType AND ObjectId = @DocumentId
	IF @@ERROR != 0
		GOTO err
	DELETE DOCUMENT_RESOURCES WHERE DocumentId = @DocumentId
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @DocumentObjectType AND ObjectId = @DocumentId
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId = @DocumentId AND EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @DocumentObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE TAGS WHERE ObjectTypeId = @DocumentObjectType AND ObjectId = @DocumentId
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @DocumentObjectType AND ObjectId = @DocumentId
	IF @@ERROR != 0
		GOTO err
	DELETE FROM DOCUMENTS  WHERE DocumentId = @DocumentId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[fsc_FileCopy]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].fsc_FileCopy
	@FileId INT,
	@DestDirectoryId INT,
	@OverwriteExisting bit = 0,
	@Retval INT OUT
AS
SET NOCOUNT ON
BEGIN TRAN
	IF NOT EXISTS(SELECT * FROM fsc_Directories WHERE DirectoryId = @DestDirectoryId)
	BEGIN
		RAISERROR('Invalid DestDirectoryId.',16,1)
		GOTO ERR
	END
	IF NOT EXISTS(SELECT * FROM fsc_Files WHERE FileId = @FileId)
	BEGIN
		RAISERROR('Invalid FileId.',16,1)
		GOTO ERR
	END
	DECLARE @SrcDirectoryId INT
	DECLARE @SrcAllowHistory BIT
	DECLARE @SrcName NVARCHAR(255)
	SELECT @SrcDirectoryId = DirectoryId, @SrcAllowHistory = AllowHistory, @SrcName = [Name] FROM fsc_Files WHERE FileId = @FileId
	IF @SrcDirectoryId<>@DestDirectoryId
	BEGIN
		IF @OverwriteExisting = 1
		BEGIN
			DECLARE @DelFileId INT
			SET @DelFileId = (SELECT [FileId] FROM fsc_Files WHERE [Name] = @SrcName AND [DirectoryId] = @DestDirectoryId)
			IF @DelFileId > 0
				EXEC [dbo].fsc_FileDelete @DelFileId
		END
		INSERT INTO [fsc_Files]([Name],  [DirectoryId], [FileBinaryId], [CreatorId], [Created], [ModifierId], [Modified], [AllowHistory])
		SELECT [Name],  @DestDirectoryId, [FileBinaryId], [CreatorId], [Created], [ModifierId], [Modified], [AllowHistory] FROM fsc_Files WHERE FileId = @FileId
		IF @@ERROR <> 0 GOTO ERR
		SET @Retval = @@IDENTITY
		IF @SrcAllowHistory = 1
		BEGIN
			INSERT INTO fsc_Files_History ([FileId], [Name], [DirectoryId], [FileBinaryId], [ModifierId], [Modified])
			SELECT @Retval, [Name], [DirectoryId], [FileBinaryId], [ModifierId], [Modified] FROM fsc_Files_History WHERE FileId = @FileId
			IF @@ERROR <> 0 GOTO ERR
		END
	END
COMMIT TRAN
RETURN
ERR:
	ROLLBACK TRAN
RETURN
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO

INSERT INTO [OBJECT_TYPES] (ObjectTypeId, ObjectTypeName) VALUES (21, 'Organization')
INSERT INTO [OBJECT_TYPES] (ObjectTypeId, ObjectTypeName) VALUES (22, 'VCard')
GO
