SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[CompanyStatus]'
GO
CREATE TABLE [dbo].[CompanyStatus]
(
[StatusId] [int] NOT NULL,
[Name] [nvarchar] (50) NOT NULL,
[Icon] [image] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CompanyStatus] on [dbo].[CompanyStatus]'
GO
ALTER TABLE [dbo].[CompanyStatus] ADD CONSTRAINT [PK_CompanyStatus] PRIMARY KEY CLUSTERED  ([StatusId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CompanyComment]'
GO
CREATE TABLE [dbo].[CompanyComment]
(
[CommentId] [int] NOT NULL IDENTITY(1, 1),
[CompanyId] [int] NULL,
[RequestId] [int] NULL,
[StatusId] [int] NULL,
[Description] [ntext] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CompanyComment] on [dbo].[CompanyComment]'
GO
ALTER TABLE [dbo].[CompanyComment] ADD CONSTRAINT [PK_CompanyComment] PRIMARY KEY CLUSTERED  ([CommentId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CompanyStatus_SetIcon]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].CompanyStatus_SetIcon
	@StatusId INT,
	@Icon IMAGE
AS
UPDATE CompanyStatus SET Icon = @Icon WHERE StatusId = @StatusId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CompanyStatus_CreateUpdate]'
GO
CREATE PROCEDURE [dbo].CompanyStatus_CreateUpdate
	@StatusId INT,
	@Name NVARCHAR(50),
	@retval INT OUTPUT
AS
IF EXISTS (SELECT * FROM CompanyStatus WHERE StatusId = @StatusId)
BEGIN
	UPDATE CompanyStatus SET Name = @Name WHERE StatusId = @StatusId
	SELECT @retval = @StatusId
END
ELSE
BEGIN
	INSERT INTO CompanyStatus (Name) VALUES (@Name)
	SELECT @retval = @@IDENTITY
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CompanyStatus_GetList]'
GO
CREATE PROCEDURE [dbo].CompanyStatus_GetList
AS
SELECT StatusId, Name FROM CompanyStatus
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CompanyStatus_GetIcon]'
GO
CREATE PROCEDURE [dbo].CompanyStatus_GetIcon
	@StatusId INT
AS
SELECT Icon FROM CompanyStatus WHERE StatusId = @StatusId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CompanyStatus_Delete]'
GO
CREATE PROCEDURE [dbo].CompanyStatus_Delete
	@StatusId INT
AS
DELETE CompanyStatus WHERE StatusId = @StatusId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Comment_UpdateForCompany]'
GO
CREATE PROCEDURE [dbo].Comment_UpdateForCompany
	@CompanyId INT,
	@StatusId INT,
	@Description NTEXT
AS
IF EXISTS (SELECT * FROM CompanyComment WHERE CompanyId = @CompanyId)
	UPDATE [CompanyComment] SET StatusId = @StatusId, Description = @Description WHERE CompanyId = @CompanyId
ELSE
BEGIN
	DECLARE @RequestId INT
	SELECT @RequestId = RequestId FROM TRIAL_REQUESTS WHERE CompanyId = @CompanyId
	INSERT INTO [CompanyComment] (CompanyId, RequestId, StatusId, Description) VALUES (@CompanyId, @RequestId, @StatusId, @Description)
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_TRIAL_REQUEST_GET]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].ASP_TRIAL_REQUEST_GET
	@RequestID as int,
	@IncludeInactive as bit
AS
SELECT R.RequestID, CompanyName, R.CompanyID, SizeOfGroup, R.Description, Domain, FirstName, LastName, Email, Phone, Country, TimeZone, Login, Password, R.ResellerId, RS.Title AS ResellerTitle, XML, R.GUID, UseIM, IsActive, IsDeleted, CreationDate, Locale, TimeZoneId, CC.StatusId, S.Name AS StatusName
 FROM TRIAL_REQUESTS R
 JOIN TRIAL_RESELLERS RS ON (R.ResellerId = RS.ResellerId)
 LEFT JOIN CompanyComment CC ON CC.RequestId = R.RequestId
 LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE (@IncludeInactive = 1 OR IsActive = 1)  AND (R.RequestID = @RequestID OR @RequestID = 0) AND IsDeleted = 0
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_GET_DATA_SIZE]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].ASP_GET_DATA_SIZE
	@company_id as int,
	@retval bigint output
as
DECLARE @FileSize bigint
DECLARE @MessSize bigint
SELECT @FileSize = SUM(CAST(file_size AS BIGINT))
 FROM
 (
  SELECT DISTINCT F.file_id, F.file_size
   FROM [FILE] F
   JOIN BINARY_DATA B ON B.FID = F.file_id
   JOIN [USER] U ON U.user_id = F.from_user_id
   JOIN IMGROUPS G ON G.imgroup_id = U.imgroup_id
   WHERE G.company_id = @company_id
 ) A
IF @FileSize IS NULL
	SET @FileSize = 0
SELECT @MessSize = SUM(CAST(DATALENGTH(M.mess_text) AS BIGINT))
 FROM USER_MESS M
 JOIN [USER] U ON U.user_id = M.from_user_id
 JOIN IMGROUPS G ON G.imgroup_id = U.imgroup_id
 WHERE G.company_id = @company_id
IF @MessSize IS NULL
	SET @MessSize = 0
SET @retval = @FileSize + @MessSize
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Comment_UpdateForRequest]'
GO
CREATE PROCEDURE [dbo].Comment_UpdateForRequest
	@RequestId INT,
	@StatusId INT,
	@Description NTEXT
AS
IF EXISTS (SELECT * FROM CompanyComment WHERE RequestId = @RequestId)
	UPDATE [CompanyComment] SET StatusId = @StatusId, Description = @Description WHERE RequestId = @RequestId
ELSE
BEGIN
	DECLARE @CompanyId INT
	SELECT @CompanyId = CompanyId FROM TRIAL_REQUESTS WHERE RequestId = @RequestId
	INSERT INTO [CompanyComment] (CompanyId, RequestId, StatusId, Description) VALUES (@CompanyId, @RequestId, @StatusId, @Description)
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Comment_GetForCompany]'
GO
CREATE PROCEDURE [dbo].Comment_GetForCompany
	@CompanyId INT
AS
SELECT C.company_id AS CompanyId, CC.StatusId, S.Name AS StatusName, CC.Description
 FROM Companies C
 LEFT JOIN CompanyComment CC ON CC.CompanyId = C.company_id
 LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE C.company_id = @CompanyId OR @CompanyId = 0
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_TRIAL_REQUEST_SET_ACTIVE]'
GO
ALTER PROCEDURE [dbo].ASP_TRIAL_REQUEST_SET_ACTIVE
	@RequestId as int,
	@CompanyId as int,
	@IsActive as bit
AS
UPDATE TRIAL_REQUESTS SET IsActive = @IsActive, CompanyID = @CompanyId WHERE RequestId = @RequestId
UPDATE CompanyComment SET CompanyId = @CompanyId WHERE RequestId = @RequestId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Comment_GetForRequest]'
GO
CREATE PROCEDURE [dbo].Comment_GetForRequest
	@RequestId INT
AS
SELECT R.RequestId, CC.StatusId, S.Name AS StatusName, CC.Description
 FROM TRIAL_REQUESTS R
 LEFT JOIN CompanyComment CC ON CC.RequestId = R.RequestId
 LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE R.RequestId = @RequestId OR @RequestId = 0
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_EmptyTables]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].ASP_EmptyTables
	@company_id INT,
	@delete_trial_requests BIT = 0,
	@delete_company BIT = 0
AS
DECLARE @TempGroups TABLE (GroupId INT)
INSERT INTO @TempGroups SELECT imgroup_id AS GroupId FROM IMGROUPS WHERE company_id = @company_id
DECLARE @TempUsers TABLE (UserId INT)
INSERT INTO @TempUsers SELECT [user_id] AS UserId FROM [User] WHERE imgroup_id IN (SELECT GroupId FROM @TempGroups)
DECLARE @TempFiles TABLE (FileId CHAR(36))
INSERT INTO @TempFiles SELECT DISTINCT [file_id] AS FileId FROM [File] WHERE from_user_id IN (SELECT UserId FROM @TempUsers) OR to_user_id IN (SELECT UserId FROM @TempUsers)
DELETE FROM [ACTIVE_USER] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [AUTH_LIST] WHERE [from_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [AUTH_LIST] WHERE [to_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CHAT_MESS] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CHAT_USERS] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CHAT_USERS] WHERE [from_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CHATS] WHERE [owner_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CONTACT_LIST] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CONTACT_LIST] WHERE [cont_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [DEPENDENCES] WHERE [imgroup_id] IN (SELECT GroupId FROM @TempGroups)
DELETE FROM [DEPENDENCES] WHERE [dep_imgroup_id] IN (SELECT GroupId FROM @TempGroups)
DELETE FROM [BINARY_DATA] WHERE [FID] IN (SELECT FileId COLLATE database_default FROM @TempFiles)
DELETE FROM [FILE] WHERE [file_id] IN (SELECT FileId COLLATE database_default FROM @TempFiles)
DELETE FROM [SESSIONS] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [PORTAL_SESSIONS] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [USER_MESS] WHERE [from_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [USER_MESS] WHERE [to_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [USER] WHERE [imgroup_id] IN (SELECT GroupId FROM @TempGroups)
DELETE FROM [IMGROUPS] WHERE company_id = @company_id
DELETE FROM [TRIAL_NOTIFICATIONS] WHERE company_id = @company_id
IF @delete_trial_requests = 1
BEGIN
	UPDATE [CompanyComment] SET RequestId = NULL WHERE RequestId IN (SELECT RequestId FROM TRIAL_REQUESTS WHERE CompanyId = @company_id)
	DELETE FROM [TRIAL_REQUESTS] WHERE CompanyId = @company_id
END
ELSE
	UPDATE TRIAL_REQUESTS SET IsDeleted=1 WHERE CompanyId = @company_id
IF @delete_company = 1
BEGIN
	UPDATE [CompanyComment] SET CompanyId = NULL WHERE CompanyId = @company_id
	DELETE FROM [COMPANIES] WHERE company_id = @company_id
END
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_GET_COMPANY]'
GO
ALTER PROCEDURE [dbo].ASP_GET_COMPANY
	@company_type INT,
	@company_id INT
AS
SELECT company_id, company_name, domain, [db_name], app_id, C.description, contact_name, contact_phone, contact_email, support_name, support_email, product_name,
	theme, use_im, title1, title2, text1, text2, max_users, max_external_users, is_global, creation_date, company_type, start_date, end_date, rate_per_user, is_active, max_disk_space,
	enable_alerts, show_admin_wizard, use_ssl, firstdayofweek, Port, CC.StatusId, S.Name AS StatusName
 FROM Companies C
 LEFT JOIN CompanyComment CC ON CC.CompanyId = company_id
 LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE (company_id = @company_id OR @company_id = 0) AND (company_type=@company_type OR @company_type=0)
 ORDER BY company_name
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
PRINT N'Creating primary key [PK_TRIAL_REQUESTS] on [dbo].[TRIAL_REQUESTS]'
GO
ALTER TABLE [dbo].[TRIAL_REQUESTS] ADD CONSTRAINT [PK_TRIAL_REQUESTS] PRIMARY KEY CLUSTERED  ([RequestId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[CompanyComment]'
GO
ALTER TABLE [dbo].[CompanyComment] ADD
CONSTRAINT [FK_CompanyComment_COMPANIES] FOREIGN KEY ([CompanyId]) REFERENCES [dbo].[COMPANIES] ([company_id]),
CONSTRAINT [FK_CompanyComment_TRIAL_REQUESTS] FOREIGN KEY ([RequestId]) REFERENCES [dbo].[TRIAL_REQUESTS] ([RequestId]),
CONSTRAINT [FK_CompanyComment_CompanyStatus] FOREIGN KEY ([StatusId]) REFERENCES [dbo].[CompanyStatus] ([StatusId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
