BEGIN TRAN
DECLARE @DirectoryId INT
DECLARE @ContainerKey NVARCHAR(255)
DECLARE @Created DATETIME
DECLARE @CreatorId INT
DECLARE DirectoryCursor CURSOR FOR
SELECT D.DirectoryId, D.ContainerKey, D.Created, D.CreatorId  FROM fsc_Directories D
WHERE D.ContainerKey LIKE 'IncidentId_%'
AND
EXISTS(SELECT * FROM fsc_Files F WHERE F.DirectoryId = D.DirectoryId)
OPEN DirectoryCursor
FETCH NEXT FROM DirectoryCursor
INTO @DirectoryId, @ContainerKey, @Created, @CreatorId
WHILE @@FETCH_STATUS = 0
BEGIN
	DECLARE @ForumId INT
	DECLARE @ForumThreadId INT
	SET @ForumId = (SELECT ForumId FROM fsc_Forums WHERE ContainerKey = @ContainerKey)
	SET @ForumThreadId = (SELECT TOP 1 [ThreadId] FROM [fsc_ForumThreads] WHERE ForumId = @ForumId)
	PRINT @ForumId
	PRINT @ForumThreadId
	IF @ForumThreadId IS NOT NULL
	BEGIN
		DECLARE @ThreadNodeId INT
		EXEC fsc_ForumThreadNodeCreate @ForumThreadId, N'', @Created, @CreatorId, NULL, NULL, NULL, 1, @ThreadNodeId OUT
		DECLARE @NewContainerKey NVARCHAR(255)
		SET @NewContainerKey = (N'ForumNodeId_' + CAST(@ThreadNodeId AS NVARCHAR(10)))
		UPDATE fsc_Directories SET ContainerKey =  @NewContainerKey
		WHERE DirectoryId = @DirectoryId
		DECLARE @AclId INT
		SET @AclId = (SELECT AclID FROM fsc_AccessControlLists  WHERE DirectoryId = @DirectoryId )
		EXEC fsc_AccessControlEntriesClear @AclId
		DECLARE @AceId INT
		EXEC fsc_AccessControlEntryAdd @AclId, NULL, 1, N'Read', 1, 0, @AceId OUT
	END
	FETCH NEXT FROM DirectoryCursor
	INTO @DirectoryId, @ContainerKey, @Created, @CreatorId
END
CLOSE DirectoryCursor
DEALLOCATE DirectoryCursor
COMMIT TRAN
