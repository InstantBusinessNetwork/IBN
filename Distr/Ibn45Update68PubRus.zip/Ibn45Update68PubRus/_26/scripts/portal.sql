SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[mf_InnerAttachment]'
GO
CREATE TABLE [dbo].[mf_InnerAttachment]
(
[AttachmentId] [int] NOT NULL IDENTITY(1, 1),
[Uid] [uniqueidentifier] NOT NULL CONSTRAINT [DF_mf_InnerAttachment_Uid] DEFAULT (newid()),
[Created] [datetime] NOT NULL CONSTRAINT [DF_mf_InnerAttachment_Created] DEFAULT (getutcdate()),
[FileName] [nvarchar] (255) NOT NULL,
[Type] [int] NOT NULL,
[ReferenceUrl] [ntext] NOT NULL,
[FileStream] [image] NULL,
[Attributes] [ntext] NOT NULL CONSTRAINT [DF_mf_InnerAttachment_Attributes] DEFAULT (N'')
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_mf_InnerAttachment] on [dbo].[mf_InnerAttachment]'
GO
ALTER TABLE [dbo].[mf_InnerAttachment] ADD CONSTRAINT [PK_mf_InnerAttachment] PRIMARY KEY CLUSTERED  ([AttachmentId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mf_Forum]'
GO
CREATE TABLE [dbo].[mf_Forum]
(
[ForumId] [int] NOT NULL IDENTITY(1, 1),
[Uid] [uniqueidentifier] NOT NULL CONSTRAINT [DF_mf_Forum_Uid] DEFAULT (newid()),
[Created] [datetime] NOT NULL CONSTRAINT [DF_mf_Forum_Created] DEFAULT (getutcdate()),
[Creator] [int] NOT NULL CONSTRAINT [DF_mf_Forum_Creator] DEFAULT (0),
[Container] [nvarchar] (50) NOT NULL,
[Attributes] [ntext] NOT NULL CONSTRAINT [DF_mf_Forum_Attributes] DEFAULT (N'')
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_mf_Forum] on [dbo].[mf_Forum]'
GO
ALTER TABLE [dbo].[mf_Forum] ADD CONSTRAINT [PK_mf_Forum] PRIMARY KEY CLUSTERED  ([ForumId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_mf_Forum] on [dbo].[mf_Forum]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_mf_Forum] ON [dbo].[mf_Forum] ([Uid])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mf_ForumNode]'
GO
CREATE TABLE [dbo].[mf_ForumNode]
(
[NodeId] [int] NOT NULL IDENTITY(1, 1),
[Uid] [uniqueidentifier] NOT NULL CONSTRAINT [DF_mf_ForumNode_Uid] DEFAULT (newid()),
[Subject] [ntext] NOT NULL CONSTRAINT [DF_mf_ForumNode_Subject] DEFAULT (N''),
[Body] [ntext] NOT NULL CONSTRAINT [DF_mf_ForumNode_Body] DEFAULT (N''),
[Created] [datetime] NOT NULL CONSTRAINT [DF_mf_ForumNode_Created] DEFAULT (getutcdate()),
[Creator] [int] NOT NULL CONSTRAINT [DF_mf_ForumNode_Creator] DEFAULT (0),
[Attributes] [ntext] NOT NULL CONSTRAINT [DF_mf_ForumNode_Attributes] DEFAULT (N''),
[Type] [nvarchar] (50) NOT NULL CONSTRAINT [DF_mf_ForumNode_Type] DEFAULT (N''),
[Key] [nvarchar] (50) NOT NULL CONSTRAINT [DF_mf_ForumNode_Key] DEFAULT (N''),
[Attachments] [ntext] NOT NULL CONSTRAINT [DF_mf_ForumNode_Attachments] DEFAULT (N''),
[ContainerEvents] [ntext] NOT NULL CONSTRAINT [DF_mf_ForumNode_ContainerEvents] DEFAULT (N''),
[ForumUid] [uniqueidentifier] NOT NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_mf_ForumNode] on [dbo].[mf_ForumNode]'
GO
ALTER TABLE [dbo].[mf_ForumNode] ADD CONSTRAINT [PK_mf_ForumNode] PRIMARY KEY CLUSTERED  ([NodeId])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_InnerAttachmentInsert]'
GO
CREATE PROCEDURE [dbo].[mc_mf_InnerAttachmentInsert]
(
@AttachmentId int = NULL OUTPUT
,
@Uid uniqueidentifier,
@Created datetime,
@FileName nvarchar(255),
@Type int,
@ReferenceUrl ntext,
@FileStream image = NULL
,
@Attributes ntext)
AS
    SET NOCOUNT ON
INSERT INTO [mf_InnerAttachment]
(
[Uid],
[Created],
[FileName],
[Type],
[ReferenceUrl],
[FileStream],
[Attributes])
VALUES(
@Uid,
@Created,
@FileName,
@Type,
@ReferenceUrl,
@FileStream,
@Attributes)
SELECT @AttachmentId = SCOPE_IDENTITY();
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mf_InnerAttachmentCleanUp]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].[mf_InnerAttachmentCleanUp]
	@expiredDate datetime
AS
	DELETE FROM mf_InnerAttachment WHERE Type=0 AND Created < @expiredDate
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_ForumNodeInsert]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[mc_mf_ForumNodeInsert]
(
@NodeId int = NULL OUTPUT
,
@Uid uniqueidentifier,
@Subject ntext,
@Body ntext,
@Created datetime,
@Creator int,
@Attributes ntext,
@Type nvarchar(50),
@Key nvarchar(50),
@Attachments ntext,
@ContainerEvents ntext,
@ForumUid uniqueidentifier)
AS
    SET NOCOUNT ON
INSERT INTO [mf_ForumNode]
(
[Uid],
[Subject],
[Body],
[Created],
[Creator],
[Attributes],
[Type],
[Key],
[Attachments],
[ContainerEvents],
[ForumUid])
VALUES(
@Uid,
@Subject,
@Body,
@Created,
@Creator,
@Attributes,
@Type,
@Key,
@Attachments,
@ContainerEvents,
@ForumUid)
SELECT @NodeId = SCOPE_IDENTITY();
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_ForumInsert]'
GO
CREATE PROCEDURE [dbo].[mc_mf_ForumInsert]
(
@ForumId int = NULL OUTPUT
,
@Uid uniqueidentifier,
@Created datetime,
@Creator int,
@Container nvarchar(50),
@Attributes ntext)
AS
    SET NOCOUNT ON
INSERT INTO [mf_Forum]
(
[Uid],
[Created],
[Creator],
[Container],
[Attributes])
VALUES(
@Uid,
@Created,
@Creator,
@Container,
@Attributes)
SELECT @ForumId = SCOPE_IDENTITY();
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_ForumSelect]'
GO
CREATE PROCEDURE [dbo].[mc_mf_ForumSelect]
(
@ForumUId uniqueidentifier
)
AS
    SET NOCOUNT ON
SELECT [ForumId],
[Uid],
[Created],
[Creator],
[Container],
[Attributes] FROM mf_Forum
WHERE
[UId] = @ForumUId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_ForumUpdate]'
GO
CREATE PROCEDURE [dbo].[mc_mf_ForumUpdate]
(
@ForumId int,
@Uid uniqueidentifier,
@Created datetime,
@Creator int,
@Container nvarchar(50),
@Attributes ntext)
AS
    SET NOCOUNT ON
UPDATE [mf_Forum]
SET
[Uid] = @Uid,
[Created] = @Created,
[Creator] = @Creator,
[Container] = @Container,
[Attributes] = @Attributes
WHERE
[ForumId] = @ForumId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_InnerAttachmentSelect]'
GO
CREATE PROCEDURE [dbo].[mc_mf_InnerAttachmentSelect]
(
@AttachmentUId uniqueidentifier
)
AS
    SET NOCOUNT ON
SELECT [AttachmentId],
[Uid],
[Created],
[FileName],
[Type],
[ReferenceUrl],
[FileStream],
[Attributes] FROM mf_InnerAttachment
WHERE
[Uid] = @AttachmentUId
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_ForumNodeUpdate]'
GO
CREATE PROCEDURE [dbo].[mc_mf_ForumNodeUpdate]
(
@NodeId int,
@Uid uniqueidentifier,
@Subject ntext,
@Body ntext,
@Created datetime,
@Creator int,
@Attributes ntext,
@Type nvarchar(50),
@Key nvarchar(50),
@Attachments ntext,
@ContainerEvents ntext,
@ForumUid uniqueidentifier)
AS
    SET NOCOUNT ON
UPDATE [mf_ForumNode]
SET
[Uid] = @Uid,
[Subject] = @Subject,
[Body] = @Body,
[Created] = @Created,
[Creator] = @Creator,
[Attributes] = @Attributes,
[Type] = @Type,
[Key] = @Key,
[Attachments] = @Attachments,
[ContainerEvents] = @ContainerEvents,
[ForumUid] = @ForumUid
WHERE
[NodeId] = @NodeId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[HistoryGetFull]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].HistoryGetFull
	@UserId as int
as
SELECT ObjectTypeId, ObjectId, ObjectTitle, Dt, IsView
  FROM HISTORY
  WHERE UserId = @UserId AND IsView = 0
UNION ALL
SELECT ObjectTypeId, ObjectId, ObjectTitle, Dt, IsView
  FROM HISTORY H1
  WHERE UserId = @UserId AND IsView = 1
	AND NOT EXISTS (SELECT * FROM HISTORY H2 WHERE UserId = @UserId AND IsView = 0 AND H1.ObjectTypeId = H2.ObjectTypeId AND H1.ObjectId = H2.ObjectId)
  ORDER BY IsView, Dt DESC
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_InnerAttachmentUpdate]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[mc_mf_InnerAttachmentUpdate]
(
@AttachmentId int,
@Uid uniqueidentifier,
@Created datetime,
@FileName nvarchar(255),
@Type int,
@ReferenceUrl ntext,
@FileStream image = NULL
,
@Attributes ntext)
AS
    SET NOCOUNT ON
UPDATE [mf_InnerAttachment]
SET
[Uid] = @Uid,
[Created] = @Created,
[FileName] = @FileName,
[Type] = @Type,
[ReferenceUrl] = @ReferenceUrl,
[FileStream] = @FileStream,
[Attributes] = @Attributes
WHERE
[AttachmentId] = @AttachmentId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_ForumDelete]'
GO
CREATE PROCEDURE [dbo].[mc_mf_ForumDelete]
(
@ForumId int
)
AS
    SET NOCOUNT ON
DELETE FROM [mf_Forum]
WHERE
[ForumId] = @ForumId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_ForumNodeSelect]'
GO
CREATE PROCEDURE [dbo].[mc_mf_ForumNodeSelect]
(
@Uid uniqueidentifier
)
AS
    SET NOCOUNT ON
SELECT [NodeId],
[Uid],
[Subject],
[Body],
[Created],
[Creator],
[Attributes],
[Type],
[Key],
[Attachments],
[ContainerEvents],
[ForumUid] FROM mf_ForumNode
WHERE
[Uid] = @Uid
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_InnerAttachmentDelete]'
GO
CREATE PROCEDURE [dbo].[mc_mf_InnerAttachmentDelete]
(
@AttachmentId int
)
AS
    SET NOCOUNT ON
DELETE FROM [mf_InnerAttachment]
WHERE
[AttachmentId] = @AttachmentId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[mc_mf_ForumNodeDelete]'
GO
CREATE PROCEDURE [dbo].[mc_mf_ForumNodeDelete]
(
@NodeId int
)
AS
    SET NOCOUNT ON
DELETE FROM [mf_ForumNode]
WHERE
[NodeId] = @NodeId
RETURN @@Error
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[mf_ForumNode]'
GO
ALTER TABLE [dbo].[mf_ForumNode] ADD
CONSTRAINT [FK_mf_ForumNode_mf_Forum] FOREIGN KEY ([ForumUid]) REFERENCES [dbo].[mf_Forum] ([Uid]) ON DELETE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
