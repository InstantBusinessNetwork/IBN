SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Dropping foreign keys from [dbo].[fsc_Files_History]'
GO
ALTER TABLE [dbo].[fsc_Files_History] DROP
CONSTRAINT [FK_fsc_Files_History_fsc_Files]
GO
PRINT N'Dropping foreign keys from [dbo].[USER_DETAILS]'
GO
ALTER TABLE [dbo].[USER_DETAILS] DROP
CONSTRAINT [FK_USER_DETAILS_fsc_Files]
GO
PRINT N'Dropping foreign keys from [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] DROP
CONSTRAINT [FK_fsc_Files_fsc_Folders],
CONSTRAINT [FK_fsc_Files_fsc_FileBinaries]
GO
PRINT N'Dropping foreign keys from [dbo].[PROJECT_USER_DATE]'
GO
ALTER TABLE [dbo].[PROJECT_USER_DATE] DROP
CONSTRAINT [FK_PROJECT_USER_DATE_PROJECTS],
CONSTRAINT [FK_PROJECT_USER_DATE_USERS]
GO
PRINT N'Dropping constraints from [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] DROP CONSTRAINT [PK_fsc_Files]
GO
PRINT N'Dropping constraints from [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] DROP CONSTRAINT [IX_fsc_Files]
GO
PRINT N'Dropping constraints from [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] DROP CONSTRAINT [DF_fsc_Files_Created]
GO
PRINT N'Dropping constraints from [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] DROP CONSTRAINT [DF_fsc_Files_Modified]
GO
PRINT N'Dropping constraints from [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] DROP CONSTRAINT [DF_fsc_Files_AllowHistory]
GO
PRINT N'Dropping constraints from [dbo].[FieldSets]'
GO
ALTER TABLE [dbo].[FieldSets] DROP CONSTRAINT [PK_FieldSets]
GO
PRINT N'Dropping constraints from [dbo].[PROJECT_USER_DATE]'
GO
ALTER TABLE [dbo].[PROJECT_USER_DATE] DROP CONSTRAINT [PK_PROJECT_USER_DATE]
GO
PRINT N'Dropping constraints from [dbo].[PROJECT_USER_DATE]'
GO
ALTER TABLE [dbo].[PROJECT_USER_DATE] DROP CONSTRAINT [IX_PROJECT_USER_DATE_2]
GO
PRINT N'Dropping index [IX_PROJECT_USER_DATE] from [dbo].[PROJECT_USER_DATE]'
GO
DROP INDEX [dbo].[PROJECT_USER_DATE].[IX_PROJECT_USER_DATE]
GO
PRINT N'Dropping index [IX_PROJECT_USER_DATE_1] from [dbo].[PROJECT_USER_DATE]'
GO
DROP INDEX [dbo].[PROJECT_USER_DATE].[IX_PROJECT_USER_DATE_1]
GO
PRINT N'Dropping [dbo].[FieldSetUpdate]'
GO
DROP PROCEDURE [dbo].[FieldSetUpdate]
GO
PRINT N'Dropping [dbo].[FieldSetsGetByListUid]'
GO
DROP PROCEDURE [dbo].[FieldSetsGetByListUid]
GO
PRINT N'Dropping [dbo].[FieldSetGet]'
GO
DROP PROCEDURE [dbo].[FieldSetGet]
GO
PRINT N'Dropping [dbo].[FieldSetAdd]'
GO
DROP PROCEDURE [dbo].[FieldSetAdd]
GO
PRINT N'Dropping [dbo].[FieldSets]'
GO
DROP TABLE [dbo].[FieldSets]
GO
PRINT N'Dropping [dbo].[ProjectUserGanttStartDateSet]'
GO
DROP PROCEDURE [dbo].[ProjectUserGanttStartDateSet]
GO
PRINT N'Dropping [dbo].[ProjectUserGanttStartDateGet]'
GO
DROP PROCEDURE [dbo].[ProjectUserGanttStartDateGet]
GO
PRINT N'Dropping [dbo].[ProjectUserGanttDateLengthSet]'
GO
DROP PROCEDURE [dbo].[ProjectUserGanttDateLengthSet]
GO
PRINT N'Dropping [dbo].[ProjectUserGanttDateLengthGet]'
GO
DROP PROCEDURE [dbo].[ProjectUserGanttDateLengthGet]
GO
PRINT N'Dropping [dbo].[PROJECT_USER_DATE]'
GO
DROP TABLE [dbo].[PROJECT_USER_DATE]
GO
PRINT N'Altering [dbo].[MetaClassMetaFieldRelation]'
GO
ALTER TABLE [dbo].[MetaClassMetaFieldRelation] ADD
[IsRequired] [bit] NOT NULL CONSTRAINT [DF_MetaClassMetaFieldRelation_IsRequired] DEFAULT (0),
[Width] [int] NOT NULL CONSTRAINT [DF_MetaClassMetaFieldRelation_Width] DEFAULT (0)
GO
PRINT N'Creating [dbo].[mdpsp_sys_LoadMetaFieldWidth]'
GO
CREATE PROCEDURE [dbo].[mdpsp_sys_LoadMetaFieldWidth]
	@MetaClassId	INT,
	@MetaFieldId	INT
AS
	IF NOT EXISTS(	SELECT * FROM MetaClassMetaFieldRelation WHERE MetaClassId = @MetaClassId AND MetaFieldId = @MetaFieldId)
		RAISERROR ('Wrong @MetaClassId or @MetaFieldId.', 16,1)
	SELECT Width FROM MetaClassMetaFieldRelation WHERE MetaClassId = @MetaClassId AND MetaFieldId = @MetaFieldId
GO
PRINT N'Creating [dbo].[Act_TaskUpdateConfigurationInfo]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].Act_TaskUpdateConfigurationInfo
	@TaskId int,
	@ActivationTypeId int,
	@CompletionTypeId int,
	@MustBeConfirmed bit,
	@retval int output
AS
UPDATE TASKS
 SET ActivationTypeId = @ActivationTypeId, CompletionTypeId = @CompletionTypeId, MustBeConfirmed = @MustBeConfirmed
 WHERE TaskId = @TaskId AND (ActivationTypeId != @ActivationTypeId OR CompletionTypeId != @CompletionTypeId OR MustBeConfirmed != @MustBeConfirmed)
SET @retval = @@ROWCOUNT
GO
PRINT N'Creating [dbo].[Act_TaskUpdatePhase]'
GO
CREATE PROCEDURE [dbo].Act_TaskUpdatePhase
	@ObjectId int,
	@ValueId int,
	@retval int output
AS
UPDATE TASKS
 SET PhaseId = @ValueId
 WHERE TaskId = @ObjectId AND PhaseId != @ValueId
SET @retval = @@ROWCOUNT
GO
PRINT N'Creating [dbo].[Act_TaskUpdateTasktime]'
GO
CREATE PROCEDURE [dbo].Act_TaskUpdateTasktime
	@objectId int,
	@value int,
	@retval int output
AS
UPDATE TASKS SET TaskTime = @value  WHERE TaskId = @objectId AND TaskTime != @value
SET @retval = @@ROWCOUNT
GO
PRINT N'Rebuilding [dbo].[fsc_Files]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TABLE [dbo].[tmp_rg_xx_fsc_Files]
(
[FileId] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (255) NOT NULL,
[DirectoryId] [int] NOT NULL,
[FileBinaryId] [int] NULL,
[CreatorId] [int] NULL,
[Created] [datetime] NOT NULL CONSTRAINT [DF_fsc_Files_Created] DEFAULT (getutcdate()),
[ModifierId] [int] NULL,
[Modified] [datetime] NOT NULL CONSTRAINT [DF_fsc_Files_Modified] DEFAULT (getutcdate()),
[AllowHistory] [bit] NOT NULL CONSTRAINT [DF_fsc_Files_AllowHistory] DEFAULT (0),
[Description] [ntext] NOT NULL CONSTRAINT [DF_fsc_Files_Description] DEFAULT (N'')
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[tmp_rg_xx_fsc_Files] ON
GO
INSERT INTO [dbo].[tmp_rg_xx_fsc_Files]([FileId], [Name], [DirectoryId], [FileBinaryId], [CreatorId], [Created], [ModifierId], [Modified], [AllowHistory]) SELECT [FileId], [Name], [DirectoryId], [FileBinaryId], [CreatorId], [Created], [ModifierId], [Modified], [AllowHistory] FROM [dbo].[fsc_Files]
GO
SET IDENTITY_INSERT [dbo].[tmp_rg_xx_fsc_Files] OFF
GO
DROP TABLE [dbo].[fsc_Files]
GO
EXEC sp_rename N'[dbo].[tmp_rg_xx_fsc_Files]', N'fsc_Files'
GO
PRINT N'Creating primary key [PK_fsc_Files] on [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] ADD CONSTRAINT [PK_fsc_Files] PRIMARY KEY CLUSTERED  ([FileId]) ON [PRIMARY]
GO
PRINT N'Altering [dbo].[MetaDictionary]'
GO
ALTER TABLE [dbo].[MetaDictionary] ADD
[Index] [int] NOT NULL CONSTRAINT [DF_MetaDictionary_Index] DEFAULT (0)
GO
PRINT N'Altering [dbo].[mdpsp_sys_UpdateMetaDictionary]'
GO
ALTER PROCEDURE [dbo].[mdpsp_sys_UpdateMetaDictionary]
	@MetaDictionaryId	INT,
	@Tag		IMAGE,
	@Value			NVARCHAR(1024)
AS
	SET NOCOUNT ON
BEGIN TRAN
	IF NOT EXISTS(SELECT * FROM MetaDictionary WHERE MetaDictionaryId = @MetaDictionaryId )
	BEGIN
		RAISERROR('Wrong @MetaDictionaryId.',16,1)
		GOTO ERR
	END
	UPDATE MetaDictionary SET [Value] = @Value,	[Tag] = @Tag
	WHERE MetaDictionaryId = @MetaDictionaryId
	IF @@ERROR <> 0 GOTO ERR
	COMMIT TRAN
RETURN
ERR:
	ROLLBACK TRAN
RETURN
GO
PRINT N'Creating [dbo].[mdpsp_sys_UpdateMetaDictionaryIndex]'
GO
CREATE PROCEDURE [dbo].[mdpsp_sys_UpdateMetaDictionaryIndex]
	@MetaDictionaryId	INT,
	@Index			INT
AS
	SET NOCOUNT ON
BEGIN TRAN
	IF NOT EXISTS(SELECT * FROM MetaDictionary WHERE MetaDictionaryId = @MetaDictionaryId )
	BEGIN
		RAISERROR('Wrong @MetaDictionaryId.',16,1)
		GOTO ERR
	END
	UPDATE MetaDictionary SET [Index] = @Index WHERE MetaDictionaryId = @MetaDictionaryId
	IF @@ERROR <> 0 GOTO ERR
	COMMIT TRAN
RETURN
ERR:
	ROLLBACK TRAN
RETURN
GO
PRINT N'Creating [dbo].[mdpsp_sys_UpdateMetaFieldIsRequired]'
GO
CREATE PROCEDURE [dbo].[mdpsp_sys_UpdateMetaFieldIsRequired]
	@MetaClassId	INT,
	@MetaFieldId	INT,
	@IsRequired	BIT
AS
	IF NOT EXISTS(	SELECT * FROM MetaClassMetaFieldRelation WHERE MetaClassId = @MetaClassId AND MetaFieldId = @MetaFieldId)
		RAISERROR ('Wrong @MetaClassId or @MetaFieldId.', 16,1)
	ELSE
		UPDATE MetaClassMetaFieldRelation SET  IsRequired = @IsRequired WHERE MetaClassId = @MetaClassId AND MetaFieldId = @MetaFieldId
GO
PRINT N'Altering [dbo].[fsc_FileCreate]'
GO
ALTER PROCEDURE [dbo].[fsc_FileCreate]
	@Name as nvarchar(255),
	@DirectoryId as int,
	@CreatorId as int,
	@Created as datetime,
	@Description as ntext = N''
AS
	DECLARE @FileId INT
	IF EXISTS(SELECT * FROM fsc_Files WHERE DirectoryId = @DirectoryId AND [Name] = @Name)
	BEGIN
		SELECT TOP 1 @FileId = FileId FROM fsc_Files WHERE DirectoryId = @DirectoryId AND [Name] = @Name
	END
	ELSE
	BEGIN
		INSERT INTO fsc_Files(Name, DirectoryId, CreatorId, Created, ModifierId, Modified, Description)
		VALUES (@Name, @DirectoryId, @CreatorId, @Created, @CreatorId, @Created, @Description)
		SET @FileId = @@identity
	END
	SELECT FileId, Name, DirectoryId, FileBinaryId, CreatorId, Created, ModifierId, Modified, 0 as Length, NULL as ContentTypeString, NULL as ContentTypeId, AllowHistory, Description
	FROM fsc_Files t
	WHERE FileId=@FileId
GO
PRINT N'Creating [dbo].[mdpsp_sys_UpdateMetaFieldWidth]'
GO
CREATE PROCEDURE [dbo].[mdpsp_sys_UpdateMetaFieldWidth]
	@MetaClassId	INT,
	@MetaFieldId	INT,
	@Width	INT
AS
	IF NOT EXISTS(	SELECT * FROM MetaClassMetaFieldRelation WHERE MetaClassId = @MetaClassId AND MetaFieldId = @MetaFieldId)
		RAISERROR ('Wrong @MetaClassId or @MetaFieldId.', 16,1)
	ELSE
		UPDATE MetaClassMetaFieldRelation SET  Width = @Width WHERE MetaClassId = @MetaClassId AND MetaFieldId = @MetaFieldId
GO
PRINT N'Altering [dbo].[fsc_FileGetById]'
GO
ALTER PROCEDURE [dbo].[fsc_FileGetById]
	@FileId as int
AS
	SELECT FileId,
		t.Name,
		D.DirectoryId,
		t.FileBinaryId, t.CreatorId, t.Created, t.ModifierId, t.Modified,
		DATALENGTH(FB.Data) as Length,
		CT.ContentTypeString, CT.ContentTypeId, AllowHistory,
		D.ContainerKey,
		t.Description
	FROM fsc_Files t
		LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = t.FileBinaryId
		LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
		INNER JOIN fsc_Directories D ON T.DirectoryId = D.DirectoryId
	WHERE FileId=@FileId
GO
PRINT N'Altering [dbo].[fsc_FileGetByName]'
GO
ALTER PROCEDURE [dbo].[fsc_FileGetByName]
	@Name as nvarchar(255),
	@DirectoryId as int,
	@ContainerKey as nvarchar(255)
AS
	IF NOT EXISTS(SELECT * FROM fsc_Directories WHERE DirectoryId=@DirectoryId AND ContainerKey=@ContainerKey)
	BEGIN
		RAISERROR ('Invalid @ParentDirectoryId. The folder doesn''t exist or isn''t  in the current container', 16,1)
		GOTO ERR
	END
	SELECT FileId, Name, DirectoryId, t.FileBinaryId, CreatorId, Created, ModifierId, Modified, DATALENGTH(FB.Data) as Length, CT.ContentTypeString, CT.ContentTypeId, AllowHistory, Description
	FROM fsc_Files t
		LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = t.FileBinaryId
		LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	WHERE Name=@Name AND DirectoryId=@DirectoryId
RETURN
ERR:
RETURN
GO
PRINT N'Altering [dbo].[fsc_FileModify]'
GO
ALTER PROCEDURE [dbo].[fsc_FileModify]
	@FileId as int,
	@ModifierId as int,
	@Modified as datetime
AS
	IF EXISTS(SELECT * FROM fsc_Files WHERE FileId=@FileId AND AllowHistory=1)
		INSERT INTO fsc_Files_History (FileId, Name, DirectoryId, FileBinaryId, ModifierId, Modified)
		SELECT FileId, Name, DirectoryId, FileBinaryId, ModifierId, Modified
		FROM fsc_Files
		WHERE FileId=@FileId
	UPDATE fsc_Files SET ModifierId=@ModifierId, Modified=@Modified
	WHERE FileId=@FileId
	SELECT FileId, Name, DirectoryId, t.FileBinaryId, CreatorId, Created, ModifierId, Modified, DATALENGTH(FB.Data) as Length, CT.ContentTypeString, CT.ContentTypeId, AllowHistory, Description
	FROM fsc_Files t
		LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = t.FileBinaryId
		LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	WHERE FileId=@FileId
GO
PRINT N'Altering [dbo].[fsc_FileMove]'
GO
ALTER PROCEDURE [dbo].[fsc_FileMove]
	@FileId int,
	@DestDirectoryId int
AS
	UPDATE fsc_Files SET DirectoryId=@DestDirectoryId
	WHERE FileId=@FileId
	SELECT FileId, Name, DirectoryId, t.FileBinaryId, CreatorId, Created, ModifierId, Modified, DATALENGTH(FB.Data) as Length, CT.ContentTypeString, CT.ContentTypeId, AllowHistory, Description
	FROM fsc_Files t
		LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = t.FileBinaryId
		LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	WHERE FileId=@FileId
GO
PRINT N'Altering [dbo].[fsc_FileRename]'
GO
ALTER PROCEDURE [dbo].[fsc_FileRename]
	@FileId as int,
	@NewName as nvarchar(255),
	@ModifierId as int,
	@Modified as datetime
AS
	IF EXISTS(SELECT * FROM fsc_Files WHERE FileId=@FileId AND AllowHistory=1)
		INSERT INTO fsc_Files_History (FileId, Name, DirectoryId, FileBinaryId, ModifierId, Modified)
		SELECT FileId, Name, DirectoryId, FileBinaryId, @ModifierId, @Modified
		FROM fsc_Files
		WHERE FileId=@FileId
	UPDATE fsc_Files SET Name=@NewName, ModifierId=@ModifierId, Modified=@Modified
	WHERE FileId=@FileId
	SELECT FileId, Name, DirectoryId, t.FileBinaryId, CreatorId, Created, ModifierId, Modified, DATALENGTH(FB.Data) as Length, CT.ContentTypeString, CT.ContentTypeId, AllowHistory, Description
	FROM fsc_Files t
		LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = t.FileBinaryId
		LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	WHERE FileId=@FileId
GO
PRINT N'Altering [dbo].[fsc_FilesGetByDirectoryId]'
GO
ALTER PROCEDURE [dbo].[fsc_FilesGetByDirectoryId]
	@DirectoryId as int,
	@ContainerKey nvarchar(255)
AS
	IF NOT EXISTS(SELECT * FROM fsc_Directories WHERE DirectoryId=@DirectoryId AND ContainerKey=@ContainerKey)
	BEGIN
		RAISERROR ('Invalid @DirectoryId. The folder doesn''t exist or isn''t  in the current container', 16,1)
		GOTO ERR
	END
	SELECT FileId, Name, DirectoryId, t.FileBinaryId, CreatorId, Created, ModifierId, Modified, DATALENGTH(FB.Data) as Length, CT.ContentTypeString, CT.ContentTypeId, AllowHistory, Description
	FROM fsc_Files t
		LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = t.FileBinaryId
		LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	WHERE DirectoryId=@DirectoryId
RETURN
ERR:
RETURN
GO
PRINT N'Altering [dbo].[fsc_FilesSearchFts]'
GO
ALTER PROCEDURE [dbo].[fsc_FilesSearchFts]
	@UserId INT,
	@ContainerKey nvarchar(50) = NULL,
	@DirectoryId int = NULL,
	@Deep bit = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
DECLARE @FtsString NVARCHAR(300)
SET @FtsString = N'"*'+@Keyword+N'*"'
EXEC sp_executesql  N'SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory,
	Description
FROM fsc_Files F WITH(NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH(NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N''Read'' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	(
		@ContainerKey IS NULL
		OR
		D.ContainerKey = @ContainerKey
	)
	AND
	(
		@DirectoryId IS NULL
		OR
		@Deep = 1
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Deep IS NULL
		OR
		@DirectoryId IS NULL
		OR
		@Deep = 0
		OR
		F.DirectoryId IN (SELECT DD.DirectoryId From fsc_Directories DD WHERE DD.Path LIKE (''%.'' + CAST(@DirectoryId AS VARCHAR(10)) + ''.%''))
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE ''%''+@Keyword+''%''
		OR
		F.[Description] LIKE ''%''+@Keyword+''%''
		OR
		CONTAINS(Data, @FtsString)
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)',
N'@UserId INT, 	@ContainerKey nvarchar(50), @DirectoryId int, @Deep bit,
	@Keyword nvarchar(255) ,
	@ContentType int = NULL,
	@ModifiedFrom DateTime,
	@ModifiedTo DateTime,
	@LengthFrom int,
	@LengthTo int, @FtsString NVARCHAR(300)',
@UserId , 	@ContainerKey , @DirectoryId, @Deep,
	@Keyword,
	@ContentType,
	@ModifiedFrom,
	@ModifiedTo,
	@LengthFrom,
	@LengthTo, @FtsString
GO
PRINT N'Creating [dbo].[fsc_FileUpdateDescription]'
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE PROCEDURE dbo.[fsc_FileUpdateDescription]
	@FileId as int,
	@Description as ntext
AS
BEGIN
	UPDATE [fsc_Files] SET Description = @Description
	WHERE FileId = @FileId
END
GO
PRINT N'Altering [dbo].[TimeSheetResetProject]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].TimeSheetResetProject
	@ProjectId as int
as
DECLARE @WeekTimeSheetId int, @UserId int, @StartDate datetime, @NewWeekTimeSheetId int
DECLARE WeekTimeSheet_Cursor CURSOR FOR
	SELECT WeekTimeSheetId, UserId, StartDate
	  FROM WeekTimeSheet
	  WHERE ProjectId = @ProjectId
OPEN WeekTimeSheet_Cursor
FETCH NEXT FROM WeekTimeSheet_Cursor INTO @WeekTimeSheetId, @UserId, @StartDate
WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT @NewWeekTimeSheetId = WeekTimeSheetId
	  FROM WeekTimeSheet
	  WHERE ProjectId IS NULL AND UserId = @UserId AND StartDate = @StartDate
	IF @@ROWCOUNT = 0
	BEGIN
		UPDATE WeekTimeSheet SET ProjectId = NULL WHERE WeekTimeSheetId = @WeekTimeSheetId
	END
	ELSE
	BEGIN
		UPDATE TimeSheets SET WeekTimeSheetId = @NewWeekTimeSheetId WHERE WeekTimeSheetId = @WeekTimeSheetId
		DELETE FROM WeekTimeSheet WHERE WeekTimeSheetId = @WeekTimeSheetId
	END
	FETCH NEXT FROM WeekTimeSheet_Cursor INTO @WeekTimeSheetId, @UserId, @StartDate
END
CLOSE WeekTimeSheet_Cursor
DEALLOCATE WeekTimeSheet_Cursor
GO
PRINT N'Altering [dbo].[GetUTCDateFromLocal]'
GO
ALTER FUNCTION [dbo].GetUTCDateFromLocal
		 (@TimeZoneId int,
		  @LocalDate datetime)
RETURNS DateTime AS
BEGIN
IF @LocalDate > '21000101' OR @LocalDate < '19000101'
	RETURN @LocalDate
DECLARE @TimeOffset  int
SELECT @TimeOffset = TimeOffset
FROM TimeZones_Local_Utc
WHERE TimeZoneId = @TimeZoneId AND Start <= @LocalDate AND [End] > @LocalDate
IF @TimeOffset IS NULL
	SELECT @TimeOffset = Bias FROM TimeZones WHERE TimeZoneId = @TimeZoneId
RETURN DATEADD(mi, @TimeOffset, @LocalDate)
END
GO
PRINT N'Creating [dbo].[ToDoAndTasksGetAssignedByUser]'
GO
CREATE PROCEDURE [dbo].ToDoAndTasksGetAssignedByUser
	@UserId as int,
	@ShowActive as bit,
	@FromDate datetime,
	@ToDate datetime
as
SET @ToDate = DATEADD(d, 1, @ToDate)
DECLARE @ActiveState int, @OverdueState int
SET @ActiveState = 2
SET @OverdueState  = 3
DECLARE @Now datetime, @MaxValue datetime, @MinValue datetime
SET @Now = getutcdate()
SET @MaxValue = DATEADD(yy, 100, @Now)
SET @MinValue = DATEADD(yy, -100, @Now)
SELECT ToDoId AS ItemId, Title, IsCompleted, CompletionTypeId, ReasonId, 1 AS IsToDo, StateId,
	CreationDate, StartDate, FinishDate, ActualStartDate, ActualFinishDate, ISNULL(FinishDate, DATEADD(yy, 100, CreationDate)) AS SortFinishDate
  FROM TODO
  WHERE (ManagerId = @UserId OR CreatorId = @UserId)
	AND
	(@ShowActive = 0 OR StateId = @ActiveState OR StateId = @OverdueState)
	AND
		CASE
			WHEN StartDate IS NOT NULL AND StartDate < ISNULL(ActualStartDate, @MaxValue) THEN StartDate
			WHEN ActualStartDate IS NOT NULL AND ActualStartDate < ISNULL(StartDate, @MaxValue) THEN ActualStartDate
			ELSE CreationDate
		END < @ToDate
	AND
		CASE
			WHEN FinishDate IS NOT NULL AND FinishDate > ISNULL(ActualFinishDate, @Now) THEN FinishDate
			WHEN ActualFinishDate IS NOT NULL AND ActualFinishDate > ISNULL(FinishDate, @MinValue) THEN ActualFinishDate
			WHEN ActualFinishDate IS NULL THEN @Now
			ELSE CreationDate
		END > @FromDate
UNION ALL
SELECT T.TaskId  AS ItemId, T.Title, T.IsCompleted, T.CompletionTypeId, T.ReasonId, 0 AS IsToDo, T.StateId,
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate, T.FinishDate AS SortFinishDate
  FROM TASKS T
	JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
  WHERE (P.ManagerId = @UserId OR T.CreatorId = @UserId)
	AND
	(@ShowActive = 0 OR T.StateId = @ActiveState OR T.StateId = @OverdueState)
	AND
		CASE
			WHEN T.StartDate < ISNULL(T.ActualStartDate, @MaxValue) THEN T.StartDate
			WHEN T.ActualStartDate IS NOT NULL AND T.ActualStartDate < T.StartDate THEN T.ActualStartDate
			ELSE T.CreationDate
		END < @ToDate
	AND
		CASE
			WHEN T.FinishDate > ISNULL(T.ActualFinishDate, @Now) THEN T.FinishDate
			WHEN T.ActualFinishDate IS NOT NULL AND T.ActualFinishDate > T.FinishDate THEN T.ActualFinishDate
			WHEN T.ActualFinishDate IS NULL THEN @Now
			ELSE T.CreationDate
		END > @FromDate
	AND T.IsSummary = 0 AND T.IsMilestone = 0
GO
PRINT N'Altering [dbo].[WorkSpaceFilesSearchFts]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[WorkSpaceFilesSearchFts]
	@UserId INT,
	@ProjectId INT = NULL,
	@ObjectTypeId INT = NULL,
	@ObjectId INT = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
DECLARE @FtsString NVARCHAR(300)
SET @FtsString = N'"*'+@Keyword+N'*"'
EXEC sp_executesql  N'DECLARE @SelectedContainerKeys TABLE(ContainerKey nvarchar(50) COLLATE database_default)
IF @ProjectId IS NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys SELECT DISTINCT ContainerKey FROM fsc_Directories WITH (NOLOCK)
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 3
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ProjectId_'' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)
		UNION
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO  WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ProjectId_'' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents  WITH (NOLOCK) WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 5
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''TaskId_'' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentVers_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''IncidentId_'' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentId_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''DocumentVers_'' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''EventId_'' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N''ToDoId_'' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId IS NULL
END
SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	F.[Description],
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory
FROM fsc_Files F WITH (NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH (NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N''Read'' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	D.ContainerKey IN (SELECT ContainerKey FROM @SelectedContainerKeys)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE ''%''+@Keyword+''%''
		OR
		F.[Description] LIKE ''%''+@Keyword+''%''
		OR
		CONTAINS(Data, @FtsString)
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)',
N'@UserId INT, @ProjectId INT,	@ObjectTypeId INT,@ObjectId INT,@Keyword nvarchar(255),@ContentType int,@ModifiedFrom DateTime,@ModifiedTo DateTime,@LengthFrom int,	@LengthTo int, 	@FtsString NVARCHAR(300)',
@UserId, @ProjectId,	@ObjectTypeId,	@ObjectId,	@Keyword,	@ContentType,	@ModifiedFrom,	@ModifiedTo,	@LengthFrom,	@LengthTo, 	@FtsString
GO
PRINT N'Altering [dbo].[TaskGetVacantPredecessors]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].TaskGetVacantPredecessors
			@TaskId INT
AS
DECLARE @ProjectId INT
DECLARE @ShareTable TABLE(TaskId INT)
DECLARE @ParetsChildTable TABLE(TaskId INT)
DECLARE @SuccTable TABLE(TaskId INT, OutlineNumber varchar(255) COLLATE database_default)
DECLARE @OutlineNumber VarChar(255)
SELECT @OutlineNumber = OutlineNumber, @ProjectId = ProjectId FROM TASKS WHERE TaskId = @TaskId
INSERT INTO @ParetsChildTable (TaskId) SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId AND
					(OutlineNumber LIKE @OutlineNumber + '.%' OR @OutlineNumber LIKE OutlineNumber + '.%' OR TaskId = @TaskId)
WHILE(EXISTS(SELECT TaskId FROM @ParetsChildTable WHERE TaskId NOT IN (SELECT TaskId FROM @ShareTable)))
BEGIN
INSERT INTO @ShareTable (TaskId) SELECT TaskId FROM @ParetsChildTable WHERE TaskId NOT IN (SELECT TaskId FROM @ShareTable)
INSERT INTO @SuccTable (TaskId,OutlineNumber) SELECT SuccId, OutlineNumber FROM TASK_LINKS TL JOIN TASKS T ON TL.SuccId = T.TaskId
				WHERE TL.PredId IN (SELECT TaskId FROM @ParetsChildTable) AND TL.SuccId NOT IN (SELECT TaskId FROM @ShareTable)
WHILE EXISTS (SELECT SuccId, OutlineNumber FROM TASK_LINKS TL JOIN TASKS T ON TL.SuccId = T.TaskId
				WHERE TL.PredId IN (SELECT TaskId FROM @SuccTable) AND TL.SuccId NOT IN (SELECT TaskId FROM @SuccTable))
INSERT INTO @SuccTable (TaskId,OutlineNumber) SELECT SuccId, OutlineNumber FROM TASK_LINKS TL JOIN TASKS T ON TL.SuccId = T.TaskId
				WHERE TL.PredId IN (SELECT TaskId FROM @SuccTable) AND TL.SuccId NOT IN (SELECT TaskId FROM @SuccTable)
DELETE @ParetsChildTable
INSERT INTO @ShareTable (TaskId) SELECT TaskId FROM @SuccTable WHERE TaskId NOT IN (SELECT TaskId FROM @ShareTable)
INSERT INTO @ParetsChildTable (TaskId) SELECT DISTINCT T.TaskId FROM TASKS T, @SuccTable PT  WHERE T.ProjectId = @ProjectId AND
					(T.OutlineNumber LIKE PT.OutlineNumber + '.%' OR PT.OutlineNumber LIKE T.OutlineNumber + '.%')
					AND T.TaskId NOT IN (SELECT TaskId FROM @ShareTable)
DELETE @SuccTable
END
INSERT INTO @ShareTable (TaskId) SELECT PredId FROM TASK_LINKS TL WHERE SuccId = @TaskId AND PredId NOT IN  (SELECT TaskId FROM @ShareTable)
SELECT TaskId, TaskNum, Title, CAST(TaskNum as varchar(10)) + ' ' + Title AS FullTitle FROM TASKS WHERE  ProjectId = @ProjectId AND TaskId NOT IN (SELECT TaskId FROM @ShareTable) ORDER BY TaskNum
GO
PRINT N'Altering [dbo].[TaskGetVacantSuccessors]'
GO
ALTER PROCEDURE [dbo].TaskGetVacantSuccessors
			@TaskId INT
AS
DECLARE @ProjectId INT
DECLARE @ShareTable TABLE(TaskId INT)
DECLARE @ParetsChildTable TABLE(TaskId INT)
DECLARE @SuccTable TABLE(TaskId INT, OutlineNumber varchar(255) COLLATE database_default)
DECLARE @OutlineNumber VarChar(255)
SELECT @OutlineNumber = OutlineNumber, @ProjectId = ProjectId FROM TASKS WHERE TaskId = @TaskId
INSERT INTO @ParetsChildTable (TaskId) SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId AND
					(OutlineNumber LIKE @OutlineNumber + '.%' OR @OutlineNumber LIKE OutlineNumber + '.%' OR TaskId = @TaskId)
WHILE(EXISTS(SELECT TaskId FROM @ParetsChildTable WHERE TaskId NOT IN (SELECT TaskId FROM @ShareTable)))
BEGIN
INSERT INTO @ShareTable (TaskId) SELECT TaskId FROM @ParetsChildTable WHERE TaskId NOT IN (SELECT TaskId FROM @ShareTable)
INSERT INTO @SuccTable (TaskId,OutlineNumber) SELECT TL.PredId, PT.OutlineNumber FROM TASK_LINKS TL JOIN TASKS PT ON TL.PredId = PT.TaskId
				WHERE TL.SuccId IN (SELECT TaskId FROM @ParetsChildTable) AND TL.PredId NOT IN (SELECT TaskId FROM @ShareTable)
WHILE (EXISTS(SELECT TL.PredId, PT.OutlineNumber FROM TASK_LINKS TL JOIN TASKS PT ON TL.PredId = PT.TaskId
				WHERE TL.SuccId IN (SELECT TaskId FROM @SuccTable) AND TL.PredId NOT IN (SELECT TaskId FROM @SuccTable)) )
INSERT INTO @SuccTable (TaskId,OutlineNumber) SELECT TL.PredId, PT.OutlineNumber FROM TASK_LINKS TL JOIN TASKS PT ON TL.PredId = PT.TaskId
				WHERE TL.SuccId IN (SELECT TaskId FROM @SuccTable) AND TL.PredId NOT IN (SELECT TaskId FROM @SuccTable)
DELETE @ParetsChildTable
INSERT INTO @ShareTable (TaskId) SELECT TaskId FROM @SuccTable WHERE TaskId NOT IN (SELECT TaskId FROM @ShareTable)
INSERT INTO @ParetsChildTable (TaskId) SELECT DISTINCT T.TaskId FROM TASKS T, @SuccTable PT  WHERE T.ProjectId = @ProjectId AND
					(T.OutlineNumber LIKE PT.OutlineNumber + '.%' OR PT.OutlineNumber LIKE T.OutlineNumber + '.%')
					AND T.TaskId NOT IN (SELECT TaskId FROM @ShareTable)
DELETE @SuccTable
END
INSERT INTO @ShareTable (TaskId) SELECT SuccId FROM TASK_LINKS  WHERE PredId = @TaskId AND SuccId NOT IN (SELECT TaskId FROM @ShareTable)
SELECT TaskId, TaskNum, Title, CAST(TaskNum as varchar(10)) + ' ' + Title AS FullTitle FROM TASKS WHERE  ProjectId = @ProjectId AND TaskId NOT IN (SELECT TaskId FROM @ShareTable) ORDER BY TaskNum
GO
PRINT N'Altering [dbo].[mdpsp_sys_AddMetaDictionary]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[mdpsp_sys_AddMetaDictionary]
	@MetaFieldId	INT,
	@Value		NVARCHAR(2048),
	@Tag IMAGE = NULL,
	@Index INT = 0,
	@Retval	INT OUT
AS
	SET NOCOUNT ON
	SET @Retval = -1
BEGIN TRAN
	INSERT INTO MetaDictionary (MetaFieldId, [Value], [Tag], [Index]) VALUES (@MetaFieldId, @Value, @Tag, @Index)
	IF @@ERROR <> 0 GOTO ERR
	SET @Retval = @@IDENTITY
	COMMIT TRAN
RETURN
ERR:
	SET @Retval = -1
	ROLLBACK TRAN
RETURN
GO
PRINT N'Altering [dbo].[mdpsp_sys_AddMetaField]'
GO
ALTER PROCEDURE [dbo].[mdpsp_sys_AddMetaField]
	@Namespace 		NVARCHAR(1024) = N'Mediachase.MetaDataPlus.User',
	@Name		NVARCHAR(256),
	@FriendlyName	NVARCHAR(256),
	@Description	NTEXT,
	@DataTypeId	INT,
	@Length	INT,
	@AllowNulls	BIT,
	@SaveHistory	BIT,
	@MultiLanguageValue BIT = 0,
	@AllowSearch	BIT,
	@Retval 	INT OUTPUT
AS
	SET NOCOUNT ON
	SET @Retval = -1
BEGIN TRAN
	DECLARE @DataTypeVariable	INT
	DECLARE @DataTypeLength	INT
	SELECT @DataTypeVariable = Variable, @DataTypeLength = Length FROM MetaDataType WHERE DataTypeId = @DataTypeId
	IF (@Length <= 0 OR @Length > @DataTypeLength )
		SET @Length = @DataTypeLength
	INSERT INTO [MetaField]  ([Namespace], [Name], [FriendlyName], [Description], [DataTypeId], [Length], [AllowNulls],  [SaveHistory], [MultiLanguageValue], [AllowSearch])
		VALUES(@Namespace, @Name,  @FriendlyName, @Description, @DataTypeId, @Length, @AllowNulls, @SaveHistory,@MultiLanguageValue, @AllowSearch)
	IF @@ERROR <> 0 GOTO ERR
	SET @Retval = @@IDENTITY
	COMMIT TRAN
RETURN
ERR:
	SET @Retval = -1
	ROLLBACK TRAN
RETURN
GO
PRINT N'Altering [dbo].[TasksGetByProject]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].TasksGetByProject
	@ProjectId as int,
	@LanguageId as int
as
SELECT T.TaskId, T.TaskNum, T.ProjectId, T.CreatorId, T.Title, T.[Description],
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualFinishDate, T.ActualStartDate,
	T.Duration, T.PriorityId, T.PercentCompleted, T.OutlineNumber, T.OutlineLevel, T.IsSummary, T.IsMilestone, T.ConstraintTypeId,
	T.ConstraintDate, T.CompletionTypeId, T.IsCompleted, T.MustBeConfirmed, T.ReasonId, P.PriorityName, T.StateId
  FROM TASKS T
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE ProjectId = @ProjectId
  ORDER BY TaskNum
GO
PRINT N'Creating [dbo].[Act_ProjectUpdateCalendar]'
GO
CREATE PROCEDURE [dbo].Act_ProjectUpdateCalendar
	@ProjectId int,
	@ValueId int
AS
UPDATE PROJECTS
 SET CalendarId = @ValueId
 WHERE ProjectId = @ProjectId
GO
PRINT N'Creating [dbo].[TasksGetMaxFinishDate]'
GO
CREATE PROCEDURE [dbo].TasksGetMaxFinishDate
	@ProjectId as int,
	@retval datetime output
as
SELECT @retval = MAX(FinishDate)
  FROM TASKS T
  WHERE ProjectId = @ProjectId
GO
PRINT N'Altering [dbo].[mdpsp_sys_LoadMetaDictionary]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[mdpsp_sys_LoadMetaDictionary]
	@MetaFieldId	INT
AS
	SELECT MetaDictionaryId, MetaFieldId, [Value], [Tag], [Index] FROM MetaDictionary
	WHERE MetaFieldId = @MetaFieldId
	ORDER BY [Index]
GO
PRINT N'Altering [dbo].[FinancesCheckForUnchangeableRoles]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].FinancesCheckForUnchangeableRoles
	@UserId as int,
	@Retval int output
as
IF EXISTS(SELECT * FROM ACTUAL_FINANCES WHERE LastEditorId = @UserId)
	OR EXISTS(SELECT * FROM WeekTimeSheet WHERE LastEditorId = @UserId)
	OR EXISTS(SELECT * FROM ACCOUNTS WHERE LastEditorId = @UserId)
	OR EXISTS(SELECT * FROM ActualFinances WHERE CreatorId = @UserId)
	SET @Retval = 1
ELSE
	SET @Retval = 0
GO
PRINT N'Creating [dbo].[TasksGetMinStartDate]'
GO
CREATE PROCEDURE [dbo].TasksGetMinStartDate
	@ProjectId as int,
	@retval datetime output
as
SELECT @retval = MIN(StartDate)
  FROM TASKS T
  WHERE ProjectId = @ProjectId
GO
PRINT N'Altering [dbo].[FinancesReplaceUnchangeableUser]'
GO
ALTER PROCEDURE [dbo].FinancesReplaceUnchangeableUser
	@FromUserId as int,
	@ToUserId as int
as
BEGIN TRAN
	UPDATE ACTUAL_FINANCES SET LastEditorId = @ToUserId WHERE LastEditorId = @FromUserId
	IF @@ERROR != 0
		GOTO err
	UPDATE ACCOUNTS SET LastEditorId = @ToUserId WHERE LastEditorId = @FromUserId
	IF @@ERROR != 0
		GOTO err
	UPDATE WeekTimeSheet SET LastEditorId = @ToUserId WHERE LastEditorId = @FromUserId
	IF @@ERROR != 0
		GOTO err
	UPDATE ActualFinances SET CreatorId = @ToUserId WHERE CreatorId = @FromUserId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
PRINT N'Creating [dbo].[mdpsp_sys_LoadMetaFieldIsRequired]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[mdpsp_sys_LoadMetaFieldIsRequired]
	@MetaClassId	INT,
	@MetaFieldId	INT
AS
	IF NOT EXISTS(	SELECT * FROM MetaClassMetaFieldRelation WHERE MetaClassId = @MetaClassId AND MetaFieldId = @MetaFieldId)
		RAISERROR ('Wrong @MetaClassId or @MetaFieldId.', 16,1)
	SELECT IsRequired FROM MetaClassMetaFieldRelation WHERE MetaClassId = @MetaClassId AND MetaFieldId = @MetaFieldId
GO
PRINT N'Altering [dbo].[GetLocalDate]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER FUNCTION [dbo].GetLocalDate
		 (@TimeZoneId int,
		  @UTCDate datetime)
RETURNS DateTime AS
BEGIN
IF @UTCDate > '21000101' OR @UTCDate < '19000101'
	RETURN @UTCDate
DECLARE @TimeOffset int
SELECT @TimeOffset = TimeOffset
FROM TimeZones_UTC_Local
WHERE TimeZoneId = @TimeZoneId AND Start <= @UTCDate AND [End] > @UTCDate
IF @TimeOffset IS NULL
	SELECT @TimeOffset = -Bias FROM TimeZones WHERE TimeZoneId = @TimeZoneId
RETURN DATEADD(mi, @TimeOffset, @UTCDate)
END
GO
PRINT N'Altering [dbo].[fsc_FileAllowHistory]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[fsc_FileAllowHistory]
	@FileId int,
	@AllowHistory bit
AS
	UPDATE fsc_Files SET AllowHistory=@AllowHistory
	WHERE FileId=@FileId
	SELECT FileId, Name, DirectoryId, t.FileBinaryId, CreatorId, Created, ModifierId, Modified, DATALENGTH(FB.Data) as Length, CT.ContentTypeString, CT.ContentTypeId, AllowHistory, Description
	FROM fsc_Files t
		LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = t.FileBinaryId
		LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	WHERE FileId=@FileId
GO
PRINT N'Altering [dbo].[fsc_FileCopy]'
GO
ALTER PROCEDURE [dbo].[fsc_FileCopy]
	@FileId INT,
	@DestDirectoryId INT,
	@OverwriteExisting bit = 0,
	@Retval INT OUT
AS
SET NOCOUNT ON
BEGIN TRAN
	IF NOT EXISTS(SELECT * FROM fsc_Directories WHERE DirectoryId = @DestDirectoryId)
	BEGIN
		RAISERROR('Invalid DestDirectoryId.',16,1)
		GOTO ERR
	END
	IF NOT EXISTS(SELECT * FROM fsc_Files WHERE FileId = @FileId)
	BEGIN
		RAISERROR('Invalid FileId.',16,1)
		GOTO ERR
	END
	DECLARE @SrcDirectoryId INT
	DECLARE @SrcAllowHistory BIT
	DECLARE @SrcName NVARCHAR(255)
	SELECT @SrcDirectoryId = DirectoryId, @SrcAllowHistory = AllowHistory, @SrcName = [Name] FROM fsc_Files WHERE FileId = @FileId
	IF @SrcDirectoryId<>@DestDirectoryId
	BEGIN
		IF @OverwriteExisting = 1
		BEGIN
			DECLARE @DelFileId INT
			SET @DelFileId = (SELECT [FileId] FROM fsc_Files WHERE [Name] = @SrcName AND [DirectoryId] = @DestDirectoryId)
			IF @DelFileId > 0
				EXEC [dbo].fsc_FileDelete @DelFileId
		END
		INSERT INTO [fsc_Files]([Name],  [DirectoryId], [FileBinaryId], [CreatorId], [Created], [ModifierId], [Modified], [AllowHistory], [Description])
		SELECT [Name],  @DestDirectoryId, [FileBinaryId], [CreatorId], [Created], [ModifierId], [Modified], [AllowHistory], [Description] FROM fsc_Files WHERE FileId = @FileId
		IF @@ERROR <> 0 GOTO ERR
		SET @Retval = @@IDENTITY
		IF @SrcAllowHistory = 1
		BEGIN
			INSERT INTO fsc_Files_History ([FileId], [Name], [DirectoryId], [FileBinaryId], [ModifierId], [Modified])
			SELECT @Retval, [Name], [DirectoryId], [FileBinaryId], [ModifierId], [Modified] FROM fsc_Files_History WHERE FileId = @FileId
			IF @@ERROR <> 0 GOTO ERR
		END
	END
COMMIT TRAN
RETURN
ERR:
	ROLLBACK TRAN
RETURN
GO
PRINT N'Altering [dbo].[IncidentsGetByFilter]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[IncidentsGetByFilter]
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle, I.IncidentBoxId,B.[Name] as IncidentBoxName,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId
	,U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	INM.NewMessage,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate, I.ModifiedDate, I.ActualOpenDate, I.ActualFinishDate, I.ExpectedResponseDate, I.ExpectedResolveDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,  I.Identifier,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId  OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT  JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
	LEFT JOIN INCIDENT_NEWMESSAGE INM ON I.IncidentId = INM.IncidentId
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND (IsResource = 1 OR IsIncidentResponsible =1)))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND (I.Title LIKE @Keyword OR I.[Description] LIKE @Keyword OR I.Resolution LIKE @Keyword OR I.Workaround LIKE @Keyword OR CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
  ORDER BY ProjectTitle
GO
PRINT N'Altering [dbo].[fsc_FilesSearch]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[fsc_FilesSearch]
	@UserId INT,
	@ContainerKey nvarchar(50) = NULL,
	@DirectoryId int = NULL,
	@Deep bit = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
IF  [dbo].[GetFullTextSearchEnabled] () = 1
BEGIN
	EXEC [dbo].fsc_FilesSearchFts @UserId, @ContainerKey, @DirectoryId, @DirectoryId, @Keyword, @ContentType, @ModifiedFrom, @ModifiedTo, @LengthFrom, @LengthTo
	RETURN
END
SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory,
	Description
FROM fsc_Files F WITH(NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH(NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N'Read' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	(
		@ContainerKey IS NULL
		OR
		D.ContainerKey = @ContainerKey
	)
	AND
	(
		@DirectoryId IS NULL
		OR
		@Deep = 1
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Deep IS NULL
		OR
		@DirectoryId IS NULL
		OR
		@Deep = 0
		OR
		F.DirectoryId IN (SELECT DD.DirectoryId From fsc_Directories DD WHERE DD.Path LIKE ('%.' + CAST(@DirectoryId AS VARCHAR(10)) + '.%'))
		OR
		F.DirectoryId = @DirectoryId
	)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE '%'+@Keyword+'%'
		OR
		F.[Description] LIKE '%'+@Keyword+'%'
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)
GO
PRINT N'Altering [dbo].[IncidentsGetForManagerView]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[IncidentsGetForManagerView]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
SELECT I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, 7 AS ItemType, I.CreationDate,
	I.CreationDate as StartDate, I.ActualFinishdate as ActualFinishDate, I.ActualOpenDate as ActualStartDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, B.ManagerId,  I.Identifier
  FROM INCIDENTS I, PRIORITY_LANGUAGE P, INCIDENTBOX B
  WHERE I.IncidentBoxId = B.IncidentBoxId AND
	I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId AND
	(@ManagerId=0 OR B.ManagerId=@ManagerId) AND
	(@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
	AND
	(
		@PrincipalId = 1
	OR
		IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE IsRealIncidentResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
		OR (ResponsibleId = @PrincipalId OR ResponsibleId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
	)
GO
PRINT N'Altering [dbo].[IncidentsGetForResourceView]'
GO
ALTER PROCEDURE [dbo].[IncidentsGetForResourceView]
	@UserId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
 SELECT DISTINCT I.IncidentId AS ItemId, I.Title, B.ManagerId, I.PriorityId, P.PriorityName, 7 AS ItemType, I.CreationDate, I.CreationDate as StartDate,
	I.ActualFinishdate as ActualFinishDate, I.ActualOpenDate as ActualStartDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	0 as ReasonId, I.ProjectId, PR.Title as ProjectTitle, I.StateId, 0 as CompletionTypeId,  I.Identifier
  FROM INCIDENTS I
	 LEFT JOIN PROJECTS PR ON I.ProjectId=PR.ProjectId
	JOIN INCIDENT_SECURITY_ALL ISS ON (I.IncidentId = ISS.IncidentId  AND ISS.PrincipalId = @UserId)
	 JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	JOIN INCIDENT_RESOURCES IR ON (I.IncidentId = IR.IncidentId AND IR.PrincipalId = @UserId)
  WHERE
	(@ManagerId=0 OR B.ManagerId=@ManagerId)
	AND
	(@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
	AND
	(I.ResponsibleId = @UserId OR ISS.IsRealIncidentResource=1)
GO
PRINT N'Creating [dbo].[ToDoAndTasksGetAssignedToUser]'
GO
CREATE PROCEDURE [dbo].ToDoAndTasksGetAssignedToUser
	@UserId as int,
	@ShowActive as bit,
	@FromDate datetime,
	@ToDate datetime
as
SET @ToDate = DATEADD(d, 1, @ToDate)
DECLARE @ActiveState int, @OverdueState int
SET @ActiveState = 2
SET @OverdueState  = 3
DECLARE @Now datetime, @MaxValue datetime, @MinValue datetime
SET @Now = getutcdate()
SET @MaxValue = DATEADD(yy, 100, @Now)
SET @MinValue = DATEADD(yy, -100, @Now)
SELECT T.ToDoId AS ItemId, T.Title,  T.IsCompleted, T.CompletionTypeId, T.ReasonId, 1 AS IsToDo, T.StateId, T.ManagerId, U.LastName,
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate, ISNULL(T.FinishDate, DATEADD(yy, 100, T.CreationDate)) AS SortFinishDate
  FROM TODO T
	JOIN USERS U ON (T.ManagerId = U.PrincipalId)
  WHERE T.ToDoId IN
	(SELECT ToDoId FROM TODO_SECURITY_ALL WHERE PrincipalId = @UserId AND IsResource = 1)
	AND
	(@ShowActive = 0 OR T.StateId = @ActiveState OR T.StateId = @OverdueState)
	AND
		CASE
			WHEN T.StartDate IS NOT NULL AND T.StartDate < ISNULL(T.ActualStartDate, @MaxValue) THEN T.StartDate
			WHEN T.ActualStartDate IS NOT NULL AND T.ActualStartDate < ISNULL(T.StartDate, @MaxValue) THEN T.ActualStartDate
			ELSE T.CreationDate
		END < @ToDate
	AND
		CASE
			WHEN T.FinishDate IS NOT NULL AND T.FinishDate > ISNULL(T.ActualFinishDate, @Now) THEN T.FinishDate
			WHEN T.ActualFinishDate IS NOT NULL AND T.ActualFinishDate > ISNULL(T.FinishDate, @MinValue) THEN T.ActualFinishDate
			WHEN T.ActualFinishDate IS NULL THEN @Now
			ELSE T.CreationDate
		END > @FromDate
UNION ALL
SELECT T.TaskId  AS ItemId, T.Title, T.IsCompleted, T.CompletionTypeId, T.ReasonId, 0 AS IsToDo, T.StateId, P.ManagerId, U.LastName,
	T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate, T.FinishDate AS SortFinishDate
  FROM TASKS T
	JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
	JOIN USERS U ON (P.ManagerId = U.PrincipalId)
  WHERE
	T.TaskId IN
		(SELECT TaskId FROM TASK_RESOURCES WHERE PrincipalId = @UserId AND NOT (MustBeConfirmed = 1 AND ResponsePending = 0 AND IsConfirmed = 0))
	AND
	(@ShowActive = 0 OR T.StateId = @ActiveState OR T.StateId = @OverdueState)
	AND
		CASE
			WHEN T.StartDate < ISNULL(T.ActualStartDate, @MaxValue) THEN T.StartDate
			WHEN T.ActualStartDate IS NOT NULL AND T.ActualStartDate < T.StartDate THEN T.ActualStartDate
			ELSE T.CreationDate
		END < @ToDate
	AND
		CASE
			WHEN T.FinishDate > ISNULL(T.ActualFinishDate, @Now) THEN T.FinishDate
			WHEN T.ActualFinishDate IS NOT NULL AND T.ActualFinishDate > T.FinishDate THEN T.ActualFinishDate
			WHEN T.ActualFinishDate IS NULL THEN @Now
			ELSE T.CreationDate
		END > @FromDate
	AND T.IsSummary = 0 AND T.IsMilestone = 0
GO
PRINT N'Altering [dbo].[WorkSpaceFilesSearch]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[WorkSpaceFilesSearch]
	@UserId INT,
	@ProjectId INT = NULL,
	@ObjectTypeId INT = NULL,
	@ObjectId INT = NULL,
	@Keyword nvarchar(255) = NULL,
	@ContentType int = NULL,
	@ModifiedFrom DateTime = NULL,
	@ModifiedTo DateTime = NULL,
	@LengthFrom int = NULL,
	@LengthTo int = NULL
AS
IF  [dbo].[GetFullTextSearchEnabled] () = 1
BEGIN
	EXEC [dbo].WorkSpaceFilesSearchFts @UserId, @ProjectId, @ObjectTypeId, @ObjectId, @Keyword, @ContentType, @ModifiedFrom, @LengthFrom, @LengthTo
	RETURN
END
DECLARE @SelectedContainerKeys TABLE(ContainerKey nvarchar(50) COLLATE database_default)
IF @ProjectId IS NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys SELECT DISTINCT ContainerKey FROM fsc_Directories WITH (NOLOCK)
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 3
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'ProjectId_' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)
		UNION
		SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N'TaskId_' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK) WHERE ProjectId IS NOT NULL
		UNION
		SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO  WITH (NOLOCK)  WHERE ProjectId IS NOT NULL
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId IS NULL
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'ProjectId_' + CAST(ProjectId as NVARCHAR(10)) FROM Projects WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'TaskId_' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
		UNION
		SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents  WITH (NOLOCK) WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 5
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'TaskId_' + CAST(TaskId as NVARCHAR(10)) FROM Tasks WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'DocumentVers_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NOT NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId = @ProjectId
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 7
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'IncidentId_' + CAST(IncidentId as NVARCHAR(10)) FROM Incidents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 16
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'DocumentId_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'DocumentVers_' + CAST(DocumentId as NVARCHAR(10)) FROM Documents WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 4
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'EventId_' + CAST(EventId as NVARCHAR(10)) FROM EVENTS WITH (NOLOCK)  WHERE ProjectId IS NULL
END
ELSE IF @ProjectId IS NULL AND @ObjectTypeId = 6
BEGIN
	INSERT INTO @SelectedContainerKeys
		SELECT DISTINCT N'ToDoId_' + CAST(ToDoId as NVARCHAR(10)) FROM TODO WITH (NOLOCK)  WHERE ProjectId IS NULL
END
SELECT D.ContainerKey,
	F.FileId,
	F.[Name],
	F.DirectoryId,
	F.FileBinaryId,
	F.CreatorId,
	F.Created,
	F.ModifierId,
	F.Modified,
	F.[Description],
	DATALENGTH(FB.Data) as Length,
	CT.ContentTypeString, CT.ContentTypeId,
	AllowHistory
FROM fsc_Files F WITH (NOLOCK)
	LEFT JOIN fsc_FileBinaries FB ON FB.FileBinaryId = F.FileBinaryId
	LEFT JOIN CONTENT_TYPES CT ON CT.ContentTypeId = FB.ContentTypeId
	INNER JOIN fsc_Directories D WITH (NOLOCK) ON F.DirectoryId = D.DirectoryId
	INNER JOIN fsc_FolderSecurityAll FSA ON
		FSA.DirectoryId = F.DirectoryId AND
		FSA.ContainerKey = D.ContainerKey AND
		FSA.[Action] = N'Read' AND
		FSA.Allow = 1 AND
		FSA.PrincipalId = @UserId
WHERE
	D.ContainerKey IN (SELECT ContainerKey FROM @SelectedContainerKeys)
	AND
	(
		@Keyword IS NULL
		OR
		F.[Name] LIKE '%'+@Keyword+'%'
		OR
		F.[Description] LIKE '%'+@Keyword+'%'
	)
	AND
	(
		@ContentType IS NULL
		OR
		CT.ContentTypeId = @ContentType
	)
	AND
	(
		@ModifiedFrom IS NULL
		OR
		F.Modified >= @ModifiedFrom
	)
	AND
	(
		@ModifiedTo IS NULL
		OR
		F.Modified <= @ModifiedTo
	)
	AND
	(
		@LengthFrom IS NULL
		OR
		DATALENGTH(FB.Data) >= @LengthFrom
	)
	AND
	(
		@LengthTo IS NULL
		OR
		DATALENGTH(FB.Data) <= @LengthTo
	)
GO
PRINT N'Altering [dbo].[ObjectsGetForManagerViewGroupedByUser]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ObjectsGetForManagerViewGroupedByUser]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
DECLARE @EventType int
SET @EventType = 4
SELECT U.PrincipalId, U.FirstName, U.LastName, 5 AS ItemType, T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate,
	T.ActualStartDate, T.ActualFinishDate, T.PercentCompleted, T.IsCompleted,
	PR.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN TASK_SECURITY TS ON (U.PrincipalId = TS.PrincipalId)
	JOIN TASKS T ON (TS.TaskId = T.TaskId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN PROJECTS PR ON (T.ProjectId=PR.ProjectId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND(TS.IsRealTaskResource=1)
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 6 AS ItemType, T.TodoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate,
	T.ActualStartDate, T.ActualFinishDate, T.PercentCompleted, T.IsCompleted,
	T.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN TODO_SECURITY_ALL TS ON (U.PrincipalId = TS.PrincipalId)
	JOIN TODO T ON (TS.TodoId = T.TodoId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (TS.IsResource=1)
	AND (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 7 AS ItemType, I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, I.CreationDate, I.CreationDate as StartDate, null as FinishDate,
	I.ActualOpenDate as ActualStartDate, I.ActualfinishDate as ActualFinishDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	B.ManagerId, 0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN INCIDENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN INCIDENTS I ON (S.IncidentId = I.IncidentId)
	JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealIncidentResource=1 OR S.IsIncidentResponsible = 1)
	AND (@ManagerId=0 OR B.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 4 AS ItemType, E.EventId AS ItemId, E.Title, E.PriorityId, P.PriorityName, E.CreationDate, E.StartDate, E.FinishDate,
	null as ActualStartDate, null as ActualFinishDate, 0 as PercentCompleted, CAST(0 as bit) as IsCompleted,
	E.ManagerId, 0 as ReasonId, E.ProjectId, E.StateId, 0 as CompletionTypeId,
	CASE WHEN R.RecurrenceId IS NULL THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS HasRecurrence
  FROM Users U
	JOIN EVENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN EVENTS E ON (S.EventId = E.EventId)
	JOIN PRIORITY_LANGUAGE P ON (E.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	LEFT JOIN RECURRENCE R ON (E.EventId = R.ObjectId AND R.ObjectTypeId = @EventType)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsResource=1)
	AND (@ManagerId=0 OR E.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR E.ProjectId=@ProjectId)
	AND
	(
		(
			R.RecurrenceId IS NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.StateId=@UpcomingState)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StateId=@CompletedState)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
		OR
		(
			R.RecurrenceId IS NOT NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.FinishDate>=@dt)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StartDate<=@dt)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 16 AS ItemType, D.DocumentId AS ItemId, D.Title, D.PriorityId, P.PriorityName, D.CreationDate, D.CreationDate as StartDate, null as FinishDate,
	null as ActualStartDate, D.ClosedDate as ActualFinishDate, 0 as PercentCompleted, D.IsCompleted,
	D.ManagerId, D.ReasonId, D.ProjectId, D.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN DOCUMENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN DOCUMENTS D ON (S.DocumentId = D.DocumentId)
	JOIN PRIORITY_LANGUAGE P ON (D.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealDocumentResource=1)
	AND (@ManagerId=0 OR D.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR D.ProjectId=@ProjectId)
	AND
	(
	((@StartDate is not null)AND(D.CreationDate<=@StartDate)AND(D.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(D.ClosedDate>=@CompletedDate)AND(D.IsCompleted=1))
	OR((@ShowActive=1 AND (D.StateId=@ActiveState OR D.StateId=@OverdueState)))
	)
ORDER BY U.PrincipalId, ItemType, ItemId
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetForManagerView]'
GO
ALTER PROCEDURE [dbo].[ToDoAndTasksGetForManagerView]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @OverdueState as int
set @OverdueState=3
SELECT T.ToDoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 6 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	T.PercentCompleted, T.IsCompleted,
	T.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId
  FROM TODO T, PRIORITY_LANGUAGE P
  WHERE (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
	AND
	(
		@PrincipalId = 1
	OR
		ToDoId IN (SELECT ToDoId FROM TODO_SECURITY_ALL
				WHERE IsResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
 UNION ALL
 SELECT T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 5 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	T.PercentCompleted, T.IsCompleted,
	PR.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId
  FROM TASKS T,  PRIORITY_LANGUAGE P, PROJECTS PR
  WHERE T.ProjectId=PR.ProjectId
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId
	AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
	AND
	(
		@PrincipalId = 1
	OR
		TaskId IN (SELECT TaskId FROM TASK_SECURITY
				WHERE IsRealTaskResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
ORDER By ItemType, FinishDate DESC
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetForResourceView]'
GO
ALTER PROCEDURE [dbo].[ToDoAndTasksGetForResourceView]
	@UserId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @OverdueState as int
set @OverdueState=3
DECLARE @All int
SET @All = 1
 SELECT DISTINCT T.ToDoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 6 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	CASE WHEN T.ReasonId = @All THEN TR.PercentCompleted ELSE T.PercentCompleted END AS PercentCompleted,
	T.IsCompleted, T.ManagerId, T.ReasonId, T.ProjectId, PR.Title as ProjectTitle, T.StateId, T.CompletionTypeId
  FROM TODO T
  LEFT JOIN PROJECTS PR ON T.ProjectId=PR.ProjectId
  JOIN TODO_SECURITY_ALL TS ON (T.ToDoId = TS.ToDoId AND TS.IsResource=1 AND TS.PrincipalId = @UserId)
  JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  JOIN TODO_RESOURCES TR ON (TR.ToDoId = T.ToDoId) AND (TR.PrincipalId=@UserId)
  WHERE (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND ((T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1)) OR (TR.ActualFinishDate>=@CompletedDate AND TR.PercentCompleted=100) )
	OR(@ShowActive=1 AND TR.PercentCompleted!=100 AND(T.StateId=@ActiveState OR T.StateId=@OverdueState))
	)
 UNION ALL
 SELECT DISTINCT T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 5 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	CASE WHEN T.ReasonId = @All THEN TR.PercentCompleted ELSE T.PercentCompleted END AS PercentCompleted,
	T.IsCompleted, PR.ManagerId, T.ReasonId, T.ProjectId, PR.Title as ProjectTitle, T.StateId, T.CompletionTypeId
  FROM TASKS T
  LEFT JOIN PROJECTS PR ON T.ProjectId=PR.ProjectId
  JOIN TASK_SECURITY TS ON (T.TaskId = TS.TaskId AND TS.IsRealTaskResource=1 AND TS.PrincipalId = @UserId)
  JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  JOIN TASK_RESOURCES TR ON (TR.TaskId = T.TaskId) AND (TR.PrincipalId=@UserId)
  WHERE (@ManagerId=0 OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND ((T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1)) OR (TR.ActualFinishDate>=@CompletedDate AND TR.PercentCompleted=100) )
	OR(@ShowActive=1 AND TR.PercentCompleted!=100 AND(T.StateId=@ActiveState OR T.StateId=@OverdueState))
	)
ORDER By ItemType, T.FinishDate DESC
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
PRINT N'Adding constraints to [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] ADD CONSTRAINT [IX_fsc_Files] UNIQUE NONCLUSTERED  ([Name], [DirectoryId]) ON [PRIMARY]
GO
PRINT N'Adding foreign keys to [dbo].[fsc_Files_History]'
GO
ALTER TABLE [dbo].[fsc_Files_History] ADD
CONSTRAINT [FK_fsc_Files_History_fsc_Files] FOREIGN KEY ([FileId]) REFERENCES [dbo].[fsc_Files] ([FileId])
GO
PRINT N'Adding foreign keys to [dbo].[USER_DETAILS]'
GO
ALTER TABLE [dbo].[USER_DETAILS] ADD
CONSTRAINT [FK_USER_DETAILS_fsc_Files] FOREIGN KEY ([PictureFileId]) REFERENCES [dbo].[fsc_Files] ([FileId]) ON DELETE CASCADE
GO
PRINT N'Adding foreign keys to [dbo].[fsc_Files]'
GO
ALTER TABLE [dbo].[fsc_Files] ADD
CONSTRAINT [FK_fsc_Files_fsc_Folders] FOREIGN KEY ([DirectoryId]) REFERENCES [dbo].[fsc_Directories] ([DirectoryId]),
CONSTRAINT [FK_fsc_Files_fsc_FileBinaries] FOREIGN KEY ([FileBinaryId]) REFERENCES [dbo].[fsc_FileBinaries] ([FileBinaryId])
GO
