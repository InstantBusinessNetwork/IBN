SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Creating [dbo].[STATUS_LOG]'
GO
CREATE TABLE [dbo].[STATUS_LOG]
(
[USER_ID] [int] NOT NULL,
[DT] [datetime] NOT NULL CONSTRAINT [DF_STATUS_LOG_DT] DEFAULT (getutcdate()),
[STATUS] [int] NOT NULL
) ON [PRIMARY]
GO
PRINT N'Creating index [IX_STATUS_LOG] on [dbo].[STATUS_LOG]'
GO
CREATE NONCLUSTERED INDEX [IX_STATUS_LOG] ON [dbo].[STATUS_LOG] ([USER_ID]) ON [PRIMARY]
GO
PRINT N'Creating index [IX_STATUS_LOG_1] on [dbo].[STATUS_LOG]'
GO
CREATE NONCLUSTERED INDEX [IX_STATUS_LOG_1] ON [dbo].[STATUS_LOG] ([DT]) ON [PRIMARY]
GO
PRINT N'Altering [dbo].[COMPANIES]'
GO
ALTER TABLE [dbo].[COMPANIES] ADD
[log_user_status] [bit] NOT NULL CONSTRAINT [DF_COMPANIES_log_user_status] DEFAULT (0)
GO
PRINT N'Altering [dbo].[OM_CHANGE_STATUS]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].OM_CHANGE_STATUS
	@USER_ID INT,
	@STATUS INT,
	@RETVAL INT OUTPUT
AS
DECLARE @DT_BEGIN int, @NOW datetime
SET @NOW = GETUTCDATE()
SET @DT_BEGIN = DATEDIFF(s, '1970-01-01 00:00:00', @NOW)
DECLARE @log_user_status bit
SELECT @log_user_status = log_user_status
  FROM COMPANIES C
	JOIN IMGROUPS G ON (C.company_id = G.company_id)
	JOIN [USER] U ON (G.imgroup_id = U.imgroup_id)
  WHERE [user_id] = @USER_ID
BEGIN TRAN
	UPDATE [USER] SET status_time = @DT_BEGIN WHERE [user_id] = @USER_ID
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	IF @log_user_status = 1
	BEGIN
		INSERT INTO STATUS_LOG ([user_id], dt, status)
		  VALUES (@USER_ID, @NOW, @STATUS)
		IF @@error != 0
		BEGIN
			ROLLBACK TRAN
			RETURN
		END
	END
	UPDATE Active_User SET status = @STATUS WHERE [user_id] = @USER_ID
	SET @RETVAL = @@ROWCOUNT
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO
PRINT N'Altering [dbo].[OM_KILL_ALL]'
GO
ALTER PROCEDURE [dbo].OM_KILL_ALL
	@TIME int,
	@RETVAL INT OUTPUT
AS
DECLARE @OFFLINE int
SET @OFFLINE = 0
BEGIN TRAN
	UPDATE Sessions SET Dt_End = Dt_Begin WHERE Dt_End IS NULL
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE CHAT_USERS SET USER_STATUS = 0, [TIME] = @TIME WHERE USER_STATUS <> 0
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE [USER] SET status_time = @TIME WHERE [user_id] IN (SELECT [user_id] FROM Active_User)
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	INSERT INTO STATUS_LOG ([user_id], dt, status)
	  SELECT A.[user_id], getutcdate(), @OFFLINE
	  FROM Active_User A
		JOIN [USER] U ON (A.[user_id] = U.[user_id])
		JOIN IMGROUPS G ON (U.imgroup_id = G.imgroup_id)
		JOIN COMPANIES C ON (G.company_id = C.company_id)
	  WHERE C.log_user_status = 1
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	DELETE FROM Active_User
	SET @RETVAL = @@ROWCOUNT
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO
PRINT N'Altering [dbo].[ASP_GET_COMPANY]'
GO
ALTER PROCEDURE [dbo].ASP_GET_COMPANY
	@company_type INT,
	@company_id INT
AS
SELECT company_id, company_name, domain, [db_name], app_id, C.description, contact_name, contact_phone, contact_email, support_name, support_email, product_name,
	theme, use_im, title1, title2, text1, text2, max_users, max_external_users, is_global, creation_date, company_type, start_date, end_date, rate_per_user, is_active, max_disk_space,
	enable_alerts, show_admin_wizard, use_ssl, firstdayofweek, Port,
	CC.StatusId, S.Name AS StatusName, CC.Description AS StatusDescription, DATALENGTH(S.Icon) AS StatusIconLength, C.log_user_status
 FROM Companies C
LEFT JOIN CompanyComment CC ON CC.CompanyId = company_id
LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE (company_id = @company_id OR @company_id = 0) AND (company_type=@company_type OR @company_type=0)
 ORDER BY company_name
GO
PRINT N'Altering [dbo].[OM_LOGOFF]'
GO
ALTER PROCEDURE [dbo].OM_LOGOFF
	@USER_ID INT,
	@DT_END INT,
	@RETVAL INT OUTPUT
AS
DECLARE @log_user_status bit, @OFFLINE int
SET @OFFLINE = 0
SELECT @log_user_status = log_user_status
  FROM COMPANIES C
	JOIN IMGROUPS G ON (C.company_id = G.company_id)
	JOIN [USER] U ON (G.imgroup_id = U.imgroup_id)
  WHERE [user_id] = @USER_ID
BEGIN TRAN
	UPDATE Sessions SET Dt_End = @DT_END WHERE [user_id] = @USER_ID AND Dt_End IS NULL
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE [USER] SET status_time = @DT_END WHERE [user_id] = @USER_ID
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	IF @log_user_status = 1
	BEGIN
		INSERT INTO STATUS_LOG ([user_id], dt, status)
		  VALUES (@USER_ID, getutcdate(), @OFFLINE)
		IF @@error != 0
		BEGIN
			ROLLBACK TRAN
			RETURN
		END
	END
	DELETE FROM Active_User WHERE [user_id] = @USER_ID
	SET @RETVAL = @@ROWCOUNT
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO
PRINT N'Creating [dbo].[REP_GET_STATUS_LOG]'
GO
CREATE PROCEDURE [dbo].REP_GET_STATUS_LOG
	@companyId as int,
	@imGroupId as int,
	@userId as int,
	@fromDate as datetime,
	@toDate as datetime
AS
SELECT L.[user_id], L.dt, L.status, U.first_name, U.last_name
  FROM STATUS_LOG L
	JOIN [USER] U ON (L.[user_id] = U.[user_id])
	JOIN IMGROUPS G ON (U.imgroup_id = G.imgroup_id)
  WHERE L.dt >= @fromDate AND L.dt <= @toDate
	AND (@userId = 0 OR L.[user_id] = @userId)
	AND (@imGroupId = 0 OR U.imgroup_id = @imGroupId)
	AND G.company_id = @companyId
  ORDER BY L.dt
GO
PRINT N'Creating [dbo].[CompanyPaymentContact]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TABLE [dbo].[CompanyPaymentContact]
(
[ContactId] [int] NOT NULL IDENTITY(1, 1),
[CompanyId] [int] NOT NULL,
[Name] [nvarchar] (100) NOT NULL,
[Email] [nvarchar] (100) NOT NULL,
[Culture] [nvarchar] (10) NOT NULL CONSTRAINT [DF_CompanyPaymentContact_Culture] DEFAULT (N'ru-RU')
) ON [PRIMARY]
GO
PRINT N'Creating primary key [PK_CompanyPaymentContact] on [dbo].[CompanyPaymentContact]'
GO
ALTER TABLE [dbo].[CompanyPaymentContact] ADD CONSTRAINT [PK_CompanyPaymentContact] PRIMARY KEY CLUSTERED  ([ContactId]) ON [PRIMARY]
GO
PRINT N'Creating [dbo].[CompanyPaymentContactCreateUpdate]'
GO
CREATE PROCEDURE [dbo].[CompanyPaymentContactCreateUpdate]
	@CompanyId INT,
	@ContactId INT,
	@Name NVARCHAR(100),
	@Email NVARCHAR(100),
	@Culture NVARCHAR(10)
AS
BEGIN
	IF EXISTS (SELECT * FROM CompanyPaymentContact WHERE ContactId = @ContactId)
	BEGIN
		UPDATE CompanyPaymentContact
		 SET Name = @Name, Email = @Email, Culture = @Culture
		 WHERE ContactId = @ContactId
		SELECT @ContactId
	END
	ELSE
	BEGIN
		INSERT INTO CompanyPaymentContact
		 (CompanyId, Name, Email, Culture)
		 VALUES (@CompanyId, @Name, @Email, @Culture)
		SELECT SCOPE_IDENTITY()
	END
END
GO
PRINT N'Creating [dbo].[CompanyPaymentContactDelete]'
GO
CREATE PROCEDURE [dbo].[CompanyPaymentContactDelete]
	@ContactId INT
AS
BEGIN
	DELETE FROM CompanyPaymentContact WHERE ContactId = @ContactId
END
GO
PRINT N'Creating [dbo].[CompanyPaymentContactGet]'
GO
CREATE PROCEDURE [dbo].[CompanyPaymentContactGet]
	@CompanyId INT,
	@ContactId INT
AS
BEGIN
	SELECT ContactId, CompanyId, Name, Email, Culture
	 FROM CompanyPaymentContact
	 WHERE ContactId = @ContactId OR CompanyId = @CompanyId
END
GO
PRINT N'Creating [dbo].[CompanyPaymentManager]'
GO
CREATE TABLE [dbo].[CompanyPaymentManager]
(
[ManagerId] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (100) NOT NULL,
[Email] [nvarchar] (100) NOT NULL,
[Culture] [nvarchar] (50) NOT NULL CONSTRAINT [DF_CompanyPaymentManager_Culture] DEFAULT (N'ru-RU')
) ON [PRIMARY]
GO
PRINT N'Creating primary key [PK_CompanyPaymentManager] on [dbo].[CompanyPaymentManager]'
GO
ALTER TABLE [dbo].[CompanyPaymentManager] ADD CONSTRAINT [PK_CompanyPaymentManager] PRIMARY KEY CLUSTERED  ([ManagerId]) ON [PRIMARY]
GO
PRINT N'Creating [dbo].[CompanyPayment]'
GO
CREATE TABLE [dbo].[CompanyPayment]
(
[AccountId] [int] NOT NULL IDENTITY(1, 1),
[CompanyId] [int] NOT NULL,
[Manage] [bit] NOT NULL CONSTRAINT [DF_CompanyPayment_Manage] DEFAULT (0),
[ManagerId] [int] NULL,
[PaymentDate] [datetime] NULL,
[ReminderDate] [datetime] NULL,
[DeactivationDate] [datetime] NULL
) ON [PRIMARY]
GO
PRINT N'Creating primary key [PK_CompanyPayment] on [dbo].[CompanyPayment]'
GO
ALTER TABLE [dbo].[CompanyPayment] ADD CONSTRAINT [PK_CompanyPayment] PRIMARY KEY CLUSTERED  ([AccountId]) ON [PRIMARY]
GO
PRINT N'Creating [dbo].[CompanyPaymentSetPaid]'
GO
CREATE PROCEDURE [dbo].[CompanyPaymentSetPaid]
	@CompanyId INT,
	@PaymentDate DATETIME,
	@ReminderDate DATETIME,
	@DeactivationDate DATETIME
AS
BEGIN
	UPDATE CompanyPayment
	 SET PaymentDate = @PaymentDate, ReminderDate = @ReminderDate, DeactivationDate = @DeactivationDate
	 WHERE CompanyId = @CompanyId
END
GO
PRINT N'Creating [dbo].[CompanyPaymentUpdateDeactivationDate]'
GO
CREATE PROCEDURE [dbo].[CompanyPaymentUpdateDeactivationDate]
	@CompanyId INT,
	@DeactivationDate DATETIME
AS
BEGIN
	UPDATE CompanyPayment
	 SET DeactivationDate = @DeactivationDate
	 WHERE CompanyId = @CompanyId
END
GO
PRINT N'Creating [dbo].[CompanyPaymentUpdateManage]'
GO
CREATE PROCEDURE [dbo].[CompanyPaymentUpdateManage]
	@CompanyId INT,
	@Manage BIT
AS
BEGIN
	UPDATE CompanyPayment
	 SET Manage = @Manage
	 WHERE CompanyId = @CompanyId
END
GO
PRINT N'Creating [dbo].[CompanyPaymentUpdateReminderDate]'
GO
CREATE PROCEDURE [dbo].[CompanyPaymentUpdateReminderDate]
	@CompanyId INT,
	@ReminderDate DATETIME
AS
BEGIN
	UPDATE CompanyPayment
	 SET ReminderDate = @ReminderDate
	 WHERE CompanyId = @CompanyId
END
GO
PRINT N'Altering [dbo].[OM_ADD_ACTIVE_USER]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].OM_ADD_ACTIVE_USER
	@USER_ID INT,
	@SID CHAR(36),
	@STATUS INT,
	@DT_BEGIN INT,
	@RETVAL INT OUTPUT
AS
DECLARE @log_user_status bit, @ACTIVE int
SET @ACTIVE = 1
SELECT @log_user_status = log_user_status
  FROM COMPANIES C
	JOIN IMGROUPS G ON (C.company_id = G.company_id)
	JOIN [USER] U ON (G.imgroup_id = U.imgroup_id)
  WHERE [user_id] = @USER_ID
BEGIN TRAN
	DELETE FROM Sessions WHERE [user_id] = @USER_ID AND Dt_Begin = @DT_BEGIN
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE Sessions SET Dt_End = Dt_Begin WHERE [user_id] = @USER_ID AND Dt_End IS NULL
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	INSERT INTO Sessions ([user_id], Dt_Begin) VALUES (@USER_ID, @DT_BEGIN)
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	UPDATE [USER] SET status_time = @DT_BEGIN WHERE [user_id] = @USER_ID
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
	IF @log_user_status = 1
	BEGIN
		INSERT INTO STATUS_LOG ([user_id], dt, status)
		  VALUES (@USER_ID, getutcdate(), @ACTIVE)
		IF @@error != 0
		BEGIN
			ROLLBACK TRAN
			RETURN
		END
	END
	INSERT INTO Active_User ([user_id], sid, status) VALUES (@USER_ID, @SID, @STATUS)
	SET @RETVAL = @@ROWCOUNT
	IF @@error != 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO
PRINT N'Altering [dbo].[ASP_EmptyTables]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].ASP_EmptyTables
	@company_id INT,
	@delete_trial_requests BIT = 0,
	@delete_company BIT = 0
AS
DECLARE @TempGroups TABLE (GroupId INT)
INSERT INTO @TempGroups SELECT imgroup_id AS GroupId FROM IMGROUPS WHERE company_id = @company_id
DECLARE @TempUsers TABLE (UserId INT)
INSERT INTO @TempUsers SELECT [user_id] AS UserId FROM [User] WHERE imgroup_id IN (SELECT GroupId FROM @TempGroups)
DECLARE @TempFiles TABLE (FileId CHAR(36))
INSERT INTO @TempFiles SELECT DISTINCT [file_id] AS FileId FROM [File] WHERE from_user_id IN (SELECT UserId FROM @TempUsers) OR to_user_id IN (SELECT UserId FROM @TempUsers)
DELETE FROM [ACTIVE_USER] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [AUTH_LIST] WHERE [from_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [AUTH_LIST] WHERE [to_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [STATUS_LOG] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CHAT_MESS] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CHAT_USERS] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CHAT_USERS] WHERE [from_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CHATS] WHERE [owner_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CONTACT_LIST] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [CONTACT_LIST] WHERE [cont_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [DEPENDENCES] WHERE [imgroup_id] IN (SELECT GroupId FROM @TempGroups)
DELETE FROM [DEPENDENCES] WHERE [dep_imgroup_id] IN (SELECT GroupId FROM @TempGroups)
DELETE FROM [BINARY_DATA] WHERE [FID] IN (SELECT FileId COLLATE database_default FROM @TempFiles)
DELETE FROM [FILE] WHERE [file_id] IN (SELECT FileId COLLATE database_default FROM @TempFiles)
DELETE FROM [SESSIONS] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [PORTAL_SESSIONS] WHERE [user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [USER_MESS] WHERE [from_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [USER_MESS] WHERE [to_user_id] IN (SELECT UserId FROM @TempUsers)
DELETE FROM [USER] WHERE [imgroup_id] IN (SELECT GroupId FROM @TempGroups)
DELETE FROM [IMGROUPS] WHERE company_id = @company_id
DELETE FROM [TRIAL_NOTIFICATIONS] WHERE company_id = @company_id
IF @delete_trial_requests = 1
BEGIN
	UPDATE [CompanyComment] SET RequestId = NULL WHERE RequestId IN (SELECT RequestId FROM TRIAL_REQUESTS WHERE CompanyId = @company_id)
	DELETE FROM [TRIAL_REQUESTS] WHERE CompanyId = @company_id
END
ELSE
	UPDATE TRIAL_REQUESTS SET IsDeleted=1 WHERE CompanyId = @company_id
IF @delete_company = 1
BEGIN
	UPDATE [CompanyComment] SET CompanyId = NULL WHERE CompanyId = @company_id
	DELETE FROM [COMPANIES] WHERE company_id = @company_id
END
GO
PRINT N'Creating [dbo].[CompanyPaymentGet]'
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[CompanyPaymentGet]
	@NowUtc DATETIME = NULL,
	@CompanyId INT = 0,
	@IncludeInactive BIT = 1,
	@IncludePaid BIT = 1
AS
BEGIN
	SELECT C.company_id AS CompanyId, C.company_name AS CompanyName, C.domain AS Domain, C.is_active AS IsActive, P.AccountId, P.Manage, P.PaymentDate, P.ReminderDate, P.DeactivationDate, M.ManagerId, M.Name AS ManagerName, M.Email AS ManagerEmail, M.Culture AS ManagerCulture
	FROM Companies C
	LEFT JOIN CompanyPayment P ON P.CompanyId = C.company_id
	LEFT JOIN CompanyPaymentManager M ON M.ManagerId = P.ManagerId
	WHERE C.company_type = 1
		AND (C.company_id = @CompanyId OR @CompanyId = 0)
		AND (C.is_active = 1 OR @IncludeInactive = 1)
		AND (P.PaymentDate IS NOT NULL AND P.PaymentDate < @NowUtc OR @IncludePaid = 1)
END
GO
PRINT N'Adding foreign keys to [dbo].[CompanyPayment]'
GO
ALTER TABLE [dbo].[CompanyPayment] ADD
CONSTRAINT [FK_CompanyPayment_COMPANIES] FOREIGN KEY ([CompanyId]) REFERENCES [dbo].[COMPANIES] ([company_id]) ON DELETE CASCADE,
CONSTRAINT [FK_CompanyPayment_CompanyPaymentManager] FOREIGN KEY ([ManagerId]) REFERENCES [dbo].[CompanyPaymentManager] ([ManagerId])
GO
PRINT N'Adding foreign keys to [dbo].[CompanyPaymentContact]'
GO
ALTER TABLE [dbo].[CompanyPaymentContact] ADD
CONSTRAINT [FK_CompanyPaymentContact_COMPANIES] FOREIGN KEY ([CompanyId]) REFERENCES [dbo].[COMPANIES] ([company_id]) ON DELETE CASCADE
GO
