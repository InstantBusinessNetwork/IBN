SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[mc_VCardDelete]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].[mc_VCardDelete]
(
@VCardId int
)
AS
    SET NOCOUNT ON
DECLARE @ObjectType int
SET @ObjectType = 22
DELETE FROM TAGS WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM COLLAPSED_PROJECTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_TODO_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE VCardId = @VCardId
UPDATE EVENTS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE DOCUMENTS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE INCIDENTS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE PROJECTS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE TODO SET VCardId = NULL WHERE VCardId = @VCardId
DELETE FROM [VCard] WHERE [VCardId] = @VCardId
RETURN @@Error
GO
PRINT N'Altering [dbo].[DeclinedRequestsGet]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].DeclinedRequestsGet
	@ProjectId as int,
	@UserId as int,
	@LanguageId as int
as
DECLARE @Upcoming int, @Active int, @ReOpen int
SET @Upcoming = 1
SET @Active = 2
SET @ReOpen = 6
SELECT T.ToDoId AS ObjectId, 6 AS ObjectTypeId, T.Title, T.PriorityId, PL.PriorityName, R.LastSavedDate, R.PrincipalId AS UserId, U.FirstName, U.LastName
  FROM TODO T
	JOIN PRIORITY_LANGUAGE PL ON (T.PriorityId = PL.PriorityId AND PL.LanguageId = @LanguageId)
	JOIN TODO_RESOURCES R ON (T.ToDoId = R.ToDoId AND R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0)
	JOIN USERS U ON (R.PrincipalId = U.PrincipalId)
  WHERE (@ProjectId = 0 OR T.ProjectId = @ProjectId)
	AND T.ManagerId = @UserId
	AND T.IsCompleted=0
UNION ALL
SELECT T.TaskId AS ObjectId, 5 AS ObjectTypeId, T.Title, T.PriorityId, PL.PriorityName, R.LastSavedDate, R.PrincipalId AS UserId, U.FirstName, U.LastName
  FROM TASKS T
	JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PL ON (T.PriorityId = PL.PriorityId AND PL.LanguageId = @LanguageId)
	JOIN TASK_RESOURCES R ON (T.TaskId = R.TaskId AND R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0)
	JOIN USERS U ON (R.PrincipalId = U.PrincipalId)
  WHERE (@ProjectId = 0 OR T.ProjectId = @ProjectId)
	AND P.ManagerId = @UserId
	AND T.IsCompleted=0  AND T.IsSummary = 0 AND T.IsMilestone = 0
UNION ALL
SELECT D.DocumentId AS ObjectId, 16 AS ObjectTypeId, D.Title, D.PriorityId, PL.PriorityName, R.LastSavedDate, R.PrincipalId AS UserId, U.FirstName, U.LastName
  FROM DOCUMENTS D
	JOIN PRIORITY_LANGUAGE PL ON (D.PriorityId = PL.PriorityId AND PL.LanguageId = @LanguageId)
	JOIN DOCUMENT_RESOURCES R ON (D.DocumentId = R.DocumentId AND R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0)
	JOIN USERS U ON (R.PrincipalId = U.PrincipalId)
  WHERE (@ProjectId = 0 OR D.ProjectId = @ProjectId)
	AND D.ManagerId = @UserId
	AND D.IsCompleted=0
UNION ALL
SELECT I.IncidentId AS ObjectId, 7 AS ObjectTypeId, I.Title, I.PriorityId, PL.PriorityName, R.LastSavedDate, R.PrincipalId AS UserId, U.FirstName, U.LastName
  FROM INCIDENTS I
	JOIN PRIORITY_LANGUAGE PL ON (I.PriorityId = PL.PriorityId AND PL.LanguageId = @LanguageId)
	JOIN INCIDENT_RESOURCES R ON (I.IncidentId = R.IncidentId AND R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0 AND R.IsResponsible = 0)
	JOIN USERS U ON (R.PrincipalId = U.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
  WHERE (@ProjectId = 0 OR I.ProjectId = @ProjectId)
	AND B.ManagerId = @UserId
	AND (I.StateId = @Upcoming OR I.StateId = @Active OR I.StateId = @ReOpen)
UNION ALL
SELECT E.EventId AS ObjectId, 4 AS ObjectTypeId, E.Title, E.PriorityId, PL.PriorityName, R.LastSavedDate, R.PrincipalId AS UserId, U.FirstName, U.LastName
  FROM EVENTS E
	JOIN PRIORITY_LANGUAGE PL ON (E.PriorityId = PL.PriorityId AND PL.LanguageId = @LanguageId)
	JOIN EVENT_RESOURCES R ON (E.EventId = R.EventId AND R.MustBeConfirmed = 1 AND R.ResponsePending = 0 AND R.IsConfirmed = 0)
	JOIN USERS U ON (R.PrincipalId = U.PrincipalId)
  WHERE (@ProjectId = 0 OR E.ProjectId = @ProjectId)
	AND E.ManagerId = @UserId
	AND (E.StateId = @Upcoming OR E.StateId = @Active OR E.StateId = @ReOpen)
ORDER BY R.LastSavedDate DESC
GO
PRINT N'Altering [dbo].[IncidentsGetByFilter]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[IncidentsGetByFilter]
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle, I.IncidentBoxId,B.[Name] as IncidentBoxName,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId
	,U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	INM.NewMessage,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate, I.ModifiedDate, I.ActualOpenDate, I.ActualFinishDate, I.ExpectedResponseDate, I.ExpectedResolveDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,  I.Identifier,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId  OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT  JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
	LEFT JOIN INCIDENT_NEWMESSAGE INM ON I.IncidentId = INM.IncidentId
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND (IsResource = 1 OR IsIncidentResponsible =1)))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND
	(	@Keyword = '%%' OR
		I.Title LIKE @Keyword OR
		I.[Description] LIKE @Keyword OR
		I.Resolution LIKE @Keyword OR
		I.Workaround LIKE @Keyword OR
		CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword
	)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
  ORDER BY ProjectTitle
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[IncidentsGetByFilterGroupedByClient]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].IncidentsGetByFilterGroupedByClient
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId  as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
DECLARE @Incidents
	TABLE (IncidentId int, ProjectId int, ProjectTitle nvarchar(255), ClientName nvarchar(255), CreatorId int, CreatorName nvarchar(102), ControllerId int, ControllerName nvarchar(102), ManagerId int, ManagerName nvarchar(102),
		ResponsibleId int, ResponsibleName nvarchar(102),IsResponsibleGroup bit, ResponsibleGroupState int, VCardId int, OrgId int,
		Title nvarchar(255), CreationDate DateTime, TypeId int, TypeName nvarchar(50), PriorityId int, PriorityName nvarchar(50),
		StateId int, StateName nvarchar(50), SeverityId int, CanEdit int, CanDelete int, IncidentBoxId int, IncidentBoxName nvarchar(255))
INSERT INTO @Incidents
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId,
	U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId  OR(I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete,
	I.IncidentBoxId, B.[Name] as IncidentBoxName
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND IsResource = 1))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND (@Keyword = '%%' OR I.Title LIKE @Keyword OR I.[Description] LIKE @Keyword OR I.Resolution LIKE @Keyword OR I.Workaround LIKE @Keyword OR CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword )
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
DECLARE @CollapseNonClientIncident bit
SET @CollapseNonClientIncident = 0
IF EXISTS (SELECT * FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE UserId = @UserId AND vCardId = -1 AND OrgId = -1)
	SET @CollapseNonClientIncident = 1
SELECT DISTINCT
	CASE WHEN I.VCardId IS NULL THEN -1 ELSE I.VCardId END AS VCardId,
	CASE WHEN I.OrgId IS NULL THEN -1 ELSE I.OrgId END AS OrgId,
	CAST (1 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	0 AS ProjectId, '' AS ProjectTitle,
	0 as IncidentId, '' as Title, 0 as CreatorId, '' as CreatorName, 0 as ControllerId, '' as ControllerName, 0 as ManagerId, '' as ManagerName,
	0 as ResponsibleId , '' as ResponsibleName ,CAST(0 as bit) as IsResponsibleGroup , 0 as ResponsibleGroupState ,
	NULL as CreationDate, 0 as TypeId, '' as TypeName, -1 as PriorityId, '' as PriorityName, 0 as IncidentBoxId, '' as IncidentBoxName,
	0 as StateId, '' as StateName, 0 as SeverityId, 0 as CanEdit, 0 as CanDelete,
	CASE WHEN
		(CI.OrgId IS NULL AND CI.vCardId IS NULL  AND  (I.OrgId IS NOT NULL OR I.vCardId IS NOT NULL))
		OR
		(I.OrgId IS NULL AND I.vCardId IS NULL AND @CollapseNonClientIncident = 0)
	THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS IsCollapsed
  FROM @Incidents I
		LEFT JOIN COLLAPSED_INCIDENTS_BYCLIENT CI ON ((I.vCardId = CI.vCardId OR I.OrgId = CI.OrgId) AND CI.UserId = @UserId)
UNION ALL
SELECT
	CASE WHEN I.VCardId IS NULL THEN -1 ELSE I.VCardId END AS VCardId,
	CASE WHEN I.OrgId IS NULL THEN -1 ELSE I.OrgId END AS OrgId,
	CAST (0 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	CASE WHEN I.ProjectId IS NULL THEN 0 ELSE I.ProjectId END AS ProjectId,
	CASE WHEN I.ProjectTitle IS NULL THEN '' ELSE I.ProjectTitle END AS ProjectTitle,
	IncidentId, Title, CreatorId, CreatorName, ControllerId, ControllerName,  ManagerId, ManagerName,
	ResponsibleId , ResponsibleName ,IsResponsibleGroup , ResponsibleGroupState ,
	CreationDate, TypeId, TypeName, PriorityId, PriorityName, IncidentBoxId, IncidentBoxName,
	StateId, StateName, SeverityId, CanEdit, CanDelete, CAST(0 as bit) as IsCollapsed
  FROM @Incidents I
		LEFT JOIN COLLAPSED_INCIDENTS_BYCLIENT CI ON ((I.vCardId = CI.vCardId OR I.OrgId = CI.OrgId) AND CI.UserId = @UserId)
  WHERE
	(CI.OrgId IS NULL AND CI.vCardId IS NULL  AND  (I.OrgId IS NOT NULL OR I.vCardId IS NOT NULL))
		OR
		(I.OrgId IS NULL AND I.vCardId IS NULL AND @CollapseNonClientIncident = 0)
ORDER BY ClientName, Title
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[IncidentsGetByFilterGroupedByProject]'
GO
ALTER PROCEDURE [dbo].IncidentsGetByFilterGroupedByProject
	@ProjectId as int,
	@ManagerId as int,
	@CreatorId as int,
	@ResourceId as int,
	@ResponsibleId  as int,
	@OrgId as int,
	@VCardId as int,
	@IncidentBoxId as int,
	@PriorityId as int,
	@TypeId as int,
	@StateId as int,
	@SeverityId int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@IncidentCategoryType as int
AS
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET @Keyword = '%' + @Keyword + '%'
DECLARE @NewState int, @ActiveState  int, @ReOpenState int, @OnCheckState int, @Suspended INT, @Completed INT
SET @NewState = 1
SET @ActiveState = 2
SET @ReOpenState = 6
SET @OnCheckState = 7
SET @Suspended = 4
SET @Completed = 5
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @HDM int
SET @HDM = 5
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = @HDM)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
DECLARE @Incidents
	TABLE (IncidentId int, ProjectId int, ProjectTitle nvarchar(255), ClientName nvarchar(255), CreatorId int, CreatorName nvarchar(102), ControllerId int, ControllerName nvarchar(102), ManagerId int, ManagerName nvarchar(102),
		ResponsibleId int, ResponsibleName nvarchar(102),IsResponsibleGroup bit, ResponsibleGroupState int, VCardId int, OrgId int,
		Title nvarchar(255), CreationDate DateTime, TypeId int, TypeName nvarchar(50), PriorityId int, PriorityName nvarchar(50),
		StateId int, StateName nvarchar(50), SeverityId int, CanEdit int, CanDelete int, IncidentBoxId int, IncidentBoxName nvarchar(255))
INSERT INTO @Incidents
SELECT I.IncidentId, I.ProjectId, P.Title AS ProjectTitle,
	 ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	I.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END as ControllerId
	,U3.LastName + ', ' + U3.FirstName AS ControllerName,
	B.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	I.ResponsibleId, U4.LastName + ', ' + U4.FirstName AS ResponsibleName,
	I.IsResponsibleGroup,
	(SELECT CASE
		WHEN Count(*) = 0 THEN 0
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) > 0  THEN 1
		WHEN Count(*) > 0 AND Sum(CAST(ResponsePending as INT)) = 0  THEN 2
		END
	FROM INCIDENT_RESOURCES IR WHERE IsResponsible = 1 AND IR.IncidentId = I.IncidentId) as ResponsibleGroupState,
	I.VCardId, I.OrgId,
	I.Title, I.CreationDate,
	I.TypeId, T.TypeName, I.PriorityId, PR.PriorityName, I.StateId, S.StateName, I.SeverityId,
	CASE WHEN (I.StateId = @NewState OR I.StateId = @ActiveState)
		AND (@IsPPM = 1 OR I.CreatorId = @UserId OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1)) THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR (I.CreatorId = @UserId AND I.StateId = @NewState) OR B.ManagerId = @UserId OR (I.ProjectId IS NULL AND @IsHDM = 1) THEN 1 ELSE 0 END AS CanDelete,
	I.IncidentBoxId, B.[Name] as IncidentBoxName
  FROM INCIDENTS I
	LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (I.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN INCIDENT_TYPES T ON (I.TypeId = T.TypeId)
	JOIN INCIDENT_STATE_LANGUAGE S ON (I.StateId = S.StateId AND S.LanguageId = @LanguageId)
	JOIN USERS U1 ON (I.CreatorId = U1.PrincipalId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	LEFT JOIN USERS U2 ON (B.ManagerId = U2.PrincipalId)
	LEFT  JOIN USERS U3 ON ((CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)  = U3.PrincipalId)
	LEFT JOIN USERS U4 ON (I.ResponsibleId = U4.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (I.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (I.VCardId = V.VCardId)
  WHERE
	(@ProjectId = 0 OR I.ProjectId = @ProjectId OR (@ProjectId = -1 AND I.ProjectId IS NULL))
	AND (@ManagerId = 0 OR B.ManagerId = @ManagerId)
	AND (@ResourceId = 0 OR I.IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND IsResource = 1))
	AND (@CreatorId = 0 OR I.CreatorId = @CreatorId)
	AND (@PriorityId = -1 OR I.PriorityId = @PriorityId)
	AND (@TypeId = 0 OR I.TypeId = @TypeId)
	AND (@SeverityId = 0 OR I.SeverityId = @SeverityId)
	AND
	(
		@StateId = 0
		OR I.StateId = @StateId
		OR (@StateId = -1 AND (I.StateId = @NewState OR I.StateId = @ActiveState OR I.StateId = @ReOpenState OR I.StateId = @OnCheckState))
		OR (@StateId = -2 AND (I.StateId <> @NewState AND I.StateId <> @ActiveState AND I.StateId <> @ReOpenState AND I.StateId <> @OnCheckState))
	)
	AND (@Keyword = '%%' OR I.Title LIKE @Keyword OR I.[Description] LIKE @Keyword OR I.Resolution LIKE @Keyword OR I.Workaround LIKE @Keyword OR CAST(I.IncidentId AS nvarchar(10)) LIKE @Keyword )
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR (I.ProjectId IS NULL AND @IsHDM = 1)
		OR I.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR I.IncidentId IN
			(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND I.IncidentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND I.IncidentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @IncidentObjectType AND CategoryId = -@CategoryType
			)
	)
	AND (@IncidentCategoryType = 0
		OR @IncidentCategoryType = 1 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType = 2 AND I.IncidentId NOT IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId IN (SELECT CategoryId FROM INCIDENTCATEGORY_USER WHERE UserId = @UserId)
			)
		OR @IncidentCategoryType < 0 AND I.IncidentId IN
			(SELECT IncidentId
			  FROM INCIDENT_CATEGORY
			  WHERE CategoryId = -@IncidentCategoryType
			)
	)
	AND	(@IncidentBoxId = 0 OR  I.IncidentBoxId = @IncidentBoxId)
	AND 	(@VCardId = 0 OR  I.VCardId = @VCardId)
	AND	(@OrgId = 0 OR  I.OrgId = @OrgId OR I.VCardId IN (SELECT VCardId FROM VCard WHERE OrganizationId = @OrgId))
	AND 	(@ResponsibleId = 0
			OR
			(
				   (
					(I.StateId = @NewState OR I.StateId = @Suspended OR I.StateId = @Completed) OR
				  	((I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId <=0)
				  )  AND B.ManagerId = @ResponsibleId
			)
			OR (	(I.StateId = @ActiveState OR I.StateId = @ReOpenState ) AND I.ResponsibleId = @ResponsibleId  )
			OR ( I.StateId = @OnCheckState  AND (CASE WHEN B.ControllerId > 0 THEN B.ControllerId ELSE I.CreatorId END)= @ResponsibleId )
		)
DECLARE @CollapseNonProjectIncident bit
SET @CollapseNonProjectIncident = 0
IF EXISTS (SELECT * FROM COLLAPSED_INCIDENTS WHERE UserId = @UserId AND ProjectId = -1)
	SET @CollapseNonProjectIncident = 1
SELECT DISTINCT CASE WHEN I.ProjectId IS NULL THEN -1 ELSE I.ProjectId END AS ProjectId,
	CASE WHEN ProjectTitle IS NULL THEN '' ELSE ProjectTitle END AS ProjectTitle,
	0 as IncidentId, '' as Title, 0 as CreatorId, '' as CreatorName, 0 as ControllerId, '' as ControllerName, 0 as ManagerId, '' as ManagerName,
	0 as ResponsibleId , '' as ResponsibleName ,CAST(0 as bit) as IsResponsibleGroup , 0 as ResponsibleGroupState ,0 as VCardId ,0 as OrgId , '' as ClientName,
	NULL as CreationDate, 0 as TypeId, '' as TypeName, -1 as PriorityId, '' as PriorityName, 0 as IncidentBoxId, '' as IncidentBoxName,
	0 as StateId, '' as StateName, 0 as SeverityId, 0 as CanEdit, 0 as CanDelete, CAST (1 as bit) AS IsProject,
	CASE WHEN
		(CI.ProjectId IS NULL  AND I.ProjectId IS NOT NULL)
		OR
		(I.ProjectId IS NULL AND @CollapseNonProjectIncident = 0)
	THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS IsCollapsed
  FROM @Incidents I
		LEFT JOIN COLLAPSED_INCIDENTS CI ON (I.ProjectId = CI.ProjectId AND CI.UserId = @UserId)
UNION ALL
SELECT CASE WHEN I.ProjectId IS NULL THEN -1 ELSE I.ProjectId END AS ProjectId,
	CASE WHEN ProjectTitle IS NULL THEN '' ELSE ProjectTitle END AS ProjectTitle,
	IncidentId, Title, CreatorId, CreatorName, ControllerId, ControllerName,  ManagerId, ManagerName,
	ResponsibleId , ResponsibleName ,IsResponsibleGroup , ResponsibleGroupState , VCardId , OrgId , ClientName,
	CreationDate, TypeId, TypeName, PriorityId, PriorityName, IncidentBoxId, IncidentBoxName,
	StateId, StateName, SeverityId, CanEdit, CanDelete, CAST (0 as bit) AS IsProject, CAST(0 as bit) as IsCollapsed
  FROM @Incidents I
	LEFT JOIN COLLAPSED_INCIDENTS CI ON (I.ProjectId = CI.ProjectId AND CI.UserId = @UserId)
  WHERE
	(CI.ProjectId IS NULL  AND I.ProjectId IS NOT NULL)
	OR
	(I.ProjectId IS NULL AND @CollapseNonProjectIncident = 0)
ORDER BY ProjectTitle, Title
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[OrganizationDelete]'
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].OrganizationDelete
	@OrgId as int
as
DECLARE @ObjectType int
SET @ObjectType = 21
DELETE FROM TAGS WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM COLLAPSED_PROJECTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_TODO_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE OrgId = @OrgId
UPDATE EVENTS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE DOCUMENTS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE INCIDENTS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE PROJECTS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE TODO SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE VCard SET OrganizationId = NULL WHERE OrganizationId = @OrgId
DELETE FROM ORGANIZATIONS WHERE OrgId = @OrgId
GO
PRINT N'Altering [dbo].[ProjectsGetUpdatedForUser]'
GO
ALTER PROCEDURE [dbo].ProjectsGetUpdatedForUser
	@UserId as int,
	@TimeZoneId as int,
	@Days as int
as
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @TimeOffset int
SELECT @TimeOffset = -Bias FROM TIMEZONES WHERE TimeZoneId = @TimeZoneId
IF @TimeOffset IS NULL
	SET @TimeOffset = 0
DECLARE @IsPPM_Exec bit
SET @IsPPM_Exec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND (GroupId = 4 OR GroupId = 7))
	SET @IsPPM_Exec = 1
DECLARE @ProjectObjectType int
SET @ProjectObjectType = 3
DECLARE @UserDate datetime
SET @UserDate = DATEADD(mi, @TimeOffset, GETUTCDATE())
SELECT ProjectId, Title, LastEditorId, LastSavedDate, StatusId
FROM
(
	SELECT P.ProjectId, P.Title, P.StatusId, ISNULL(SE.UserId, -1) AS LastEditorId, SE.Dt AS LastSavedDate
	  FROM PROJECTS P
		JOIN SYSTEM_EVENTS SE ON (P.ProjectId = SE.ObjectId)
		LEFT JOIN PROJECT_SECURITY_ALL PS ON (P.ProjectId = PS.ProjectId AND PS.PrincipalId = @UserId )
	  WHERE (@IsPPM_Exec = 1 OR PS.IsManager = 1 OR PS.IsExecutiveManager = 1 OR PS.IsTeamMember = 1 OR PS.IsSponsor = 1 OR PS.IsStakeHolder = 1)
		AND SE.SystemEventId IN
			(SELECT MAX(E.SystemEventId)
			  FROM SYSTEM_EVENTS E
				JOIN SYSTEM_EVENT_TYPES T ON (E.EventTypeId = T.EventTypeId)
			  WHERE T.ObjectTypeId = @ProjectObjectType
			  GROUP BY E.ObjectId)
) A
  WHERE DATEDIFF(dd, DATEADD(mi, @TimeOffset, LastSavedDate) , @UserDate) <= @Days
  ORDER BY LastSavedDate DESC
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[DocumentsGetUpdatedForUser]'
GO
ALTER PROCEDURE [dbo].DocumentsGetUpdatedForUser
	@ProjectId as int,
	@UserId as int,
	@TimeZoneId as int,
	@Days as int
as
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @TimeOffset int
SELECT @TimeOffset = -Bias FROM TIMEZONES WHERE TimeZoneId = @TimeZoneId
IF @TimeOffset IS NULL
	SET @TimeOffset = 0
DECLARE @IsPPM_Exec bit
SET @IsPPM_Exec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND (GroupId = 4 OR GroupId = 7))
	SET @IsPPM_Exec = 1
DECLARE @DocumentObjectType int
SET @DocumentObjectType = 16
DECLARE @UserDate datetime
SET @UserDate = DATEADD(mi, @TimeOffset, GETUTCDATE())
SELECT DocumentId, Title, CreatorId, ManagerId, LastEditorId, LastSavedDate, ProjectId, ProjectName, StateId
FROM
(
	SELECT D.DocumentId, D.Title, D.CreatorId, D.ManagerId, ISNULL(D.ProjectId, -1) AS ProjectId, ISNULL(P.Title, '') AS ProjectName,
		ISNULL(SE.UserId, -1) AS LastEditorId, SE.Dt AS LastSavedDate, D.StateId
	  FROM DOCUMENTS D
		JOIN SYSTEM_EVENTS SE ON (D.DocumentId = SE.ObjectId)
		LEFT JOIN PROJECTS P ON (D.ProjectId = P.ProjectId)
	  WHERE (@ProjectId = 0 OR D.ProjectId = @ProjectId)
		AND
		(@IsPPM_Exec = 1
			OR D.ProjectId IN
				(SELECT ProjectId FROM PROJECT_SECURITY
					WHERE PrincipalId = @UserId
						AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
				)
			OR D.DocumentId IN
				(SELECT DocumentId FROM DOCUMENT_SECURITY_ALL
					WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsResource = 1)
				)
		)
		AND SE.SystemEventId IN
			(SELECT MAX(E.SystemEventId)
			  FROM SYSTEM_EVENTS E
				JOIN SYSTEM_EVENT_TYPES T ON (E.EventTypeId = T.EventTypeId)
			  WHERE T.ObjectTypeId = @DocumentObjectType
			  GROUP BY E.ObjectId)
) A
  WHERE DATEDIFF(dd, DATEADD(mi, @TimeOffset, LastSavedDate) , @UserDate) <= @Days
  ORDER BY LastSavedDate DESC
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[IncidentsGetUpdatedForUser]'
GO
ALTER PROCEDURE [dbo].IncidentsGetUpdatedForUser
	@ProjectId as int,
	@UserId as int,
	@TimeZoneId as int,
	@Days as int
as
DECLARE @TimeOffset int
SELECT @TimeOffset = -Bias FROM TIMEZONES WHERE TimeZoneId = @TimeZoneId
IF @TimeOffset IS NULL
	SET @TimeOffset = 0
DECLARE @IsPPM_Exec bit
SET @IsPPM_Exec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND (GroupId = 4 OR GroupId = 7))
	SET @IsPPM_Exec = 1
DECLARE @IsHDM bit
SET @IsHDM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 5)
	SET @IsHDM = 1
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
DECLARE @UserDate datetime
SET @UserDate = DATEADD(mi, @TimeOffset, GETUTCDATE())
SELECT IncidentId, Title, CreatorId, LastEditorId, LastSavedDate, ProjectId, ProjectName, StateId
FROM
(
	SELECT I.IncidentId, I.Title, I.CreatorId, ISNULL(I.ProjectId, -1) AS ProjectId, ISNULL(P.Title, '') AS ProjectName,
		ISNULL(SE.UserId, -1) AS LastEditorId, SE.Dt AS LastSavedDate,
		I.StateId
	  FROM INCIDENTS I
		JOIN SYSTEM_EVENTS SE ON (I.IncidentId = SE.ObjectId)
		LEFT JOIN PROJECTS P ON (I.ProjectId = P.ProjectId)
	  WHERE (@ProjectId = 0 OR I.ProjectId = @ProjectId)
		AND
		(@IsPPM_Exec = 1
			OR (I.ProjectId IS NULL AND @IsHDM = 1)
			OR I.ProjectId IN
				(SELECT ProjectId FROM PROJECT_SECURITY
					WHERE PrincipalId = @UserId
						AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
				)
			OR I.IncidentId IN
				(SELECT IncidentId FROM INCIDENT_SECURITY_ALL
					WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsCreator = 1 OR IsResource = 1 OR IsIncidentResponsible = 1 OR IsIncidentController = 1)
				)
		)
		AND SE.SystemEventId IN
			(SELECT MAX(E.SystemEventId)
			  FROM SYSTEM_EVENTS E
				JOIN SYSTEM_EVENT_TYPES T ON (E.EventTypeId = T.EventTypeId)
			  WHERE T.ObjectTypeId = @IncidentObjectType
			  GROUP BY E.ObjectId)
) A
  WHERE DATEDIFF(dd, DATEADD(mi, @TimeOffset, LastSavedDate), @UserDate) <= @Days
  ORDER BY LastSavedDate DESC
GO
PRINT N'Altering [dbo].[EventsGetUpdatedForUser]'
GO
ALTER PROCEDURE [dbo].EventsGetUpdatedForUser
	@ProjectId as int,
	@UserId as int,
	@TimeZoneId as int,
	@Days as int
as
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @TimeOffset int
SELECT @TimeOffset = -Bias FROM TIMEZONES WHERE TimeZoneId = @TimeZoneId
IF @TimeOffset IS NULL
	SET @TimeOffset = 0
DECLARE @EventObjectType int
SET @EventObjectType = 4
DECLARE @UserDate datetime
SET @UserDate = DATEADD(mi, @TimeOffset, GETUTCDATE())
SELECT EventId, Title, Location, TypeId,  StartDate, FinishDate, LastSavedDate, LastEditorId, ProjectId, ProjectName, StateId
FROM
(
	SELECT E.EventId, E.Title, E.Location, E.TypeId, 	E.StartDate, E.FinishDate, E.StateId,
		ISNULL(E.ProjectId, -1) AS ProjectId, ISNULL(P.Title, '') AS ProjectName, SE.Dt AS LastSavedDate,
		ISNULL(SE.UserId, -1) AS LastEditorId
	  FROM EVENTS E
		JOIN SYSTEM_EVENTS SE ON (E.EventId = SE.ObjectId)
		LEFT JOIN PROJECTS P ON (E.ProjectId = P.ProjectId)
	  WHERE (@ProjectId = 0 OR E.ProjectId = @ProjectId)
		AND E.EventId IN
			(SELECT EventId FROM EVENT_SECURITY_ALL S
			  WHERE PrincipalId = @UserId AND (IsResource = 1 OR IsManager = 1)
			)
		AND SE.SystemEventId IN
			(SELECT MAX(E.SystemEventId)
			  FROM SYSTEM_EVENTS E
				JOIN SYSTEM_EVENT_TYPES T ON (E.EventTypeId = T.EventTypeId)
			  WHERE T.ObjectTypeId = @EventObjectType
			  GROUP BY E.ObjectId)
) A
WHERE  DATEDIFF(dd, DATEADD(mi, @TimeOffset, LastSavedDate), @UserDate) <= @Days
  ORDER BY LastSavedDate DESC
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetUpdatedForUser]'
GO
ALTER PROCEDURE [dbo].ToDoAndTasksGetUpdatedForUser
	@ProjectId as int,
	@UserId as int,
	@TimeZoneId as int,
	@Days as int
as
SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @TimeOffset int
SELECT @TimeOffset = -Bias FROM TIMEZONES WHERE TimeZoneId = @TimeZoneId
IF @TimeOffset IS NULL
	SET @TimeOffset = 0
DECLARE @UserDate datetime
SET @UserDate = DATEADD(mi, @TimeOffset, GETUTCDATE())
DECLARE @TaskObjectType int
SET @TaskObjectType = 5
DECLARE @ToDoObjectType int
SET @ToDoObjectType = 6
SELECT ItemId, Title, LastEditorId, IsToDo, StartDate, FinishDate, LastSavedDate, IsCompleted, CompletionTypeId, ProjectId, ProjectName, ReasonId, StateId
  FROM
	(SELECT T.ToDoId AS ItemId, T.Title, ISNULL(SE.UserId, -1) AS LastEditorId,
		1 AS IsToDo, T.IsCompleted, T.CompletionTypeId,  T.ReasonId, T.StartDate, T.FinishDate, T.StateId,
		ISNULL(T.ProjectId, -1) AS ProjectId, ISNULL(P.Title, '') AS ProjectName, SE.Dt AS LastSavedDate
	  FROM TODO T
		JOIN SYSTEM_EVENTS SE ON (T.ToDoId = SE.ObjectId)
		LEFT JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
	  WHERE (@ProjectId = 0 OR T.ProjectId = @ProjectId)
		AND (T.ToDoId IN (SELECT ToDoId FROM TODO_SECURITY_ALL S
			 	 WHERE PrincipalId = @UserId AND (IsResource = 1 OR IsManager = 1))
			OR T.CreatorId = @UserId)
		AND SE.SystemEventId IN
			(SELECT MAX(E.SystemEventId)
			  FROM SYSTEM_EVENTS E
				JOIN SYSTEM_EVENT_TYPES T ON (E.EventTypeId = T.EventTypeId)
			  WHERE T.ObjectTypeId = @ToDoObjectType
			  GROUP BY E.ObjectId)
	UNION ALL
	SELECT T.TaskId  AS ItemId, T.Title, ISNULL(SE.UserId, -1) AS LastEditorId,
		0 AS IsToDo, T.IsCompleted, T.CompletionTypeId,  T.ReasonId, T.StartDate, T.FinishDate, T.StateId,
		T.ProjectId, P.Title AS ProjectName, SE.Dt AS LastSavedDate
	  FROM TASKS T
		JOIN SYSTEM_EVENTS SE ON (T.TaskId = SE.ObjectId)
		JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
	  WHERE (@ProjectId = 0 OR T.ProjectId = @ProjectId)
		AND T.TaskId IN (SELECT TaskId FROM TASK_SECURITY S
				  WHERE PrincipalId = @UserId AND (IsResource = 1 OR IsManager = 1))
		AND SE.SystemEventId IN
			(SELECT MAX(E.SystemEventId)
			  FROM SYSTEM_EVENTS E
				JOIN SYSTEM_EVENT_TYPES T ON (E.EventTypeId = T.EventTypeId)
			  WHERE T.ObjectTypeId = @TaskObjectType
			  GROUP BY E.ObjectId)
	) A
  WHERE DATEDIFF(dd, DATEADD(mi, @TimeOffset, LastSavedDate), @UserDate) <= @Days
  ORDER BY LastSavedDate DESC
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
SET NOCOUNT OFF
GO
