SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[IncidentsDeleteByProject]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[IncidentsDeleteByProject]
	@ProjectId as int
as
DECLARE @IncidentObjectType int
SET @IncidentObjectType = 7
DELETE DISCUSSIONS WHERE ObjectTypeId = @IncidentObjectType AND ObjectId IN
	(SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId)
DELETE EXTERNAL_GATE WHERE ObjectTypeId = @IncidentObjectType AND ObjectId IN
	(SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId)
DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @IncidentObjectType AND ObjectId IN
	(SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId)
DELETE INCIDENT_RESOURCES WHERE IncidentId IN
	(SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId)
DELETE INCIDENT_RELATIONS
  WHERE IncidentId IN
		(SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId)
	OR RelIncidentId IN
		(SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId)
DELETE FAVORITES WHERE ObjectTypeId = @IncidentObjectType AND ObjectId IN
	(SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId)
DELETE SUBSCRIPTIONS WHERE ObjectId IN (SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId) AND
	EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @IncidentObjectType)
DELETE HISTORY WHERE ObjectTypeId = @IncidentObjectType AND ObjectId IN
	(SELECT IncidentId FROM INCIDENTS WHERE ProjectId = @ProjectId)
DELETE FROM INCIDENTS  WHERE ProjectId = @ProjectId
GO
PRINT N'Altering [dbo].[DocumentsDeleteByProject]'
GO
ALTER PROCEDURE [dbo].[DocumentsDeleteByProject]
	@ProjectId as int
as
DECLARE @DocumentObjectType int
SET @DocumentObjectType = 16
DELETE DISCUSSIONS WHERE ObjectTypeId = @DocumentObjectType AND ObjectId IN
	(SELECT DocumentId FROM DOCUMENTS WHERE ProjectId = @ProjectId)
DELETE EXTERNAL_GATE WHERE ObjectTypeId = @DocumentObjectType AND ObjectId IN
	(SELECT DocumentId FROM DOCUMENTS WHERE ProjectId = @ProjectId)
DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @DocumentObjectType AND ObjectId IN
	(SELECT DocumentId FROM DOCUMENTS WHERE ProjectId = @ProjectId)
DELETE DOCUMENT_RESOURCES WHERE DocumentId IN
	(SELECT DocumentId FROM DOCUMENTS WHERE ProjectId = @ProjectId)
DELETE FAVORITES WHERE ObjectTypeId = @DocumentObjectType AND ObjectId IN
	(SELECT DocumentId FROM DOCUMENTS WHERE ProjectId = @ProjectId)
DELETE SUBSCRIPTIONS WHERE ObjectId IN (SELECT DocumentId FROM DOCUMENTS WHERE ProjectId = @ProjectId) AND
	EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @DocumentObjectType)
DELETE HISTORY WHERE ObjectTypeId = @DocumentObjectType AND ObjectId IN
	(SELECT DocumentId FROM DOCUMENTS WHERE ProjectId = @ProjectId)
DELETE FROM DOCUMENTS  WHERE ProjectId = @ProjectId
GO
PRINT N'Altering [dbo].[TaskDeleteAll]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].[TaskDeleteAll]
			@ProjectId  INT
AS
DECLARE @TaskObjectType int
SET @TaskObjectType = 5
DELETE DISCUSSIONS WHERE ObjectTypeId = @TaskObjectType AND ObjectId IN
	(SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId)
DELETE EXTERNAL_GATE WHERE ObjectTypeId = @TaskObjectType AND ObjectId IN
	(SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId)
DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @TaskObjectType AND ObjectId IN
	(SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId)
DELETE TASK_RESOURCES WHERE TaskId IN
	(SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId)
DELETE FAVORITES WHERE ObjectTypeId = @TaskObjectType AND ObjectId  IN
	(SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId)
DELETE TASK_LINKS  WHERE
	PredId IN (SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId) OR
	 SuccId IN (SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId)
DELETE SUBSCRIPTIONS WHERE
	ObjectId IN (SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId) AND
	EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @TaskObjectType)
DELETE REMINDER_SUBSCRIPTIONS WHERE
	ObjectId IN (SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId) AND
	DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TaskObjectType)
DELETE DATE_TYPE_VALUES WHERE
	ObjectId IN (SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId) AND
	DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TaskObjectType)
DELETE DATE_TYPE_HOOKS WHERE
	ObjectId IN (SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId) AND
	DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TaskObjectType)
DELETE HISTORY WHERE ObjectTypeId = @TaskObjectType AND ObjectId IN
	(SELECT TaskId FROM TASKS WHERE ProjectId = @ProjectId)
DELETE TASKS WHERE  ProjectId = @ProjectId
GO
PRINT N'Altering [dbo].[EventDeleteByProject]'
GO
ALTER PROCEDURE [dbo].[EventDeleteByProject]
	@ProjectId as int
as
DECLARE @EventObjectType int
SET @EventObjectType = 4
BEGIN TRAN
	DELETE DISCUSSIONS WHERE ObjectTypeId = @EventObjectType AND ObjectId IN
		(SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @EventObjectType AND ObjectId IN
		(SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @EventObjectType AND ObjectId IN
		(SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE RECURRENCE WHERE ObjectTypeId = @EventObjectType AND ObjectId IN
		(SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE EVENT_RESOURCES WHERE EventId IN
		(SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @EventObjectType AND ObjectId IN
		(SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId IN (SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId) AND
		EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @EventObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE REMINDER_SUBSCRIPTIONS WHERE ObjectId IN (SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId) AND
		DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @EventObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE ObjectId IN (SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId) AND
		DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @EventObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_HOOKS WHERE ObjectId IN (SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId) AND
		DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @EventObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @EventObjectType AND ObjectId IN
		(SELECT EventId FROM EVENTS WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE FROM EVENTS  WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
PRINT N'Altering [dbo].[ToDoDeleteByProject]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[ToDoDeleteByProject]
	@ProjectId as int
AS
DECLARE @TodoObjectType int
SET @TodoObjectType = 6
BEGIN TRAN
	DELETE DISCUSSIONS WHERE ObjectTypeId = @TodoObjectType AND ObjectId IN
		(SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE EXTERNAL_GATE WHERE ObjectTypeId = @TodoObjectType AND ObjectId IN
		(SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE OBJECT_CATEGORY WHERE ObjectTypeId = @TodoObjectType AND ObjectId IN
		(SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE TODO_RESOURCES WHERE ToDoId IN
		(SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE FAVORITES WHERE ObjectTypeId = @TodoObjectType AND ObjectId IN
		(SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE SUBSCRIPTIONS WHERE ObjectId IN (SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId) AND
		EventTypeId IN (SELECT EventTypeId FROM SYSTEM_EVENT_TYPES WHERE ObjectTypeId = @TodoObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE REMINDER_SUBSCRIPTIONS WHERE ObjectId IN (SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId) AND
		DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TodoObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_VALUES WHERE ObjectId IN (SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId) AND
		DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TodoObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE DATE_TYPE_HOOKS WHERE ObjectId IN (SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId) AND
		DateTypeId IN (SELECT DateTypeId FROM DATE_TYPES WHERE ObjectTypeId = @TodoObjectType)
	IF @@ERROR != 0
		GOTO err
	DELETE HISTORY WHERE ObjectTypeId = @TodoObjectType AND ObjectId IN
		(SELECT ToDoId FROM TODO WHERE ProjectId = @ProjectId)
	IF @@ERROR != 0
		GOTO err
	DELETE FROM TODO  WHERE ProjectId = @ProjectId
	IF @@ERROR != 0
		GOTO err
COMMIT TRAN
RETURN
err:
	ROLLBACK TRAN
GO
SET ANSI_NULLS ON
GO

DELETE FROM [SUBSCRIPTIONS] WHERE [EventTypeId]=406
DELETE FROM [SYSTEM_EVENTS] WHERE [EventTypeId]=406
DELETE FROM [SYSTEM_EVENT_TYPES] WHERE [EventTypeId]=406
GO
