SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
PRINT N'Altering [dbo].[GROUPS]'
GO
ALTER TABLE [dbo].[GROUPS] ADD
[VCardId] [int] NULL,
[OrgId] [int] NULL
GO
PRINT N'Altering [dbo].[PendingEmailMessagesGet]'
GO
ALTER PROCEDURE [dbo].[PendingEmailMessagesGet]
AS
BEGIN
	SET NOCOUNT ON;
    SELECT M.EMailMessageId AS PendingMessageId, M.Created, M.[From], M.[To], M.Subject
	FROM PendingEMailMessage P
		JOIN EMailMessage M ON (P.EMailMessageId = M.EMailMessageId)
END
GO
PRINT N'Altering [dbo].[mc_VCardDelete]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].[mc_VCardDelete]
(
@VCardId int
)
AS
    SET NOCOUNT ON
DECLARE @ObjectType int
SET @ObjectType = 22
DELETE FROM TAGS WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @VCardId AND ObjectTypeId = @ObjectType
DELETE FROM COLLAPSED_PROJECTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_TODO_BYCLIENT WHERE VCardId = @VCardId
DELETE FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE VCardId = @VCardId
UPDATE GROUPS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE EVENTS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE DOCUMENTS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE INCIDENTS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE PROJECTS SET VCardId = NULL WHERE VCardId = @VCardId
UPDATE TODO SET VCardId = NULL WHERE VCardId = @VCardId
DELETE FROM [VCard] WHERE [VCardId] = @VCardId
RETURN @@Error
GO
PRINT N'Creating [dbo].[EmailMessageSenderGet]'
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].EmailMessageSenderGet
	@EMailMessageId INT
AS
BEGIN
	SET NOCOUNT ON;
	SELECT [From] FROM EmailMessage WHERE EMailMessageId = @EMailMessageId
END
GO
PRINT N'Altering [dbo].[GroupGet]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[GroupGet]
       @PrincipalId as int
as
SELECT PrincipalId AS GroupId, GroupName, IMGroupId, VCardId, OrgId
  FROM GROUPS
  WHERE PrincipalId = @PrincipalId or @PrincipalId=0
GO
PRINT N'Creating [dbo].[GroupUpdateClient]'
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[GroupUpdateClient]
	@PrincipalId int,
	@VCardId int,
	@OrgId int
AS
IF @VCardId < 0
	SET @VCardId = null
IF @OrgId < 0
	SET @OrgId = null
UPDATE GROUPS
	SET OrgId = @OrgId, VCardId = @VCardId
	WHERE PrincipalId = @PrincipalId
GO
PRINT N'Altering [dbo].[ProjectsGetGroupedByClient]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[ProjectsGetGroupedByClient]
	@PortfolioId int,
	@PhaseId int,
	@StatusId int,
	@ManagerId int,
	@UserId as int,
	@LanguageId int,
	@OrgId as int,
	@VCardId as int
AS
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @dummy TABLE (VCardId int, OrgId int, ClientName nvarchar(255), ProjectId int, ProjectName nvarchar(255),
	StatusName nvarchar(50), OpenTasks int, CompletedTasks int, Issues int)
INSERT INTO @dummy (VCardId, OrgId, ClientName, ProjectId, ProjectName, StatusName, OpenTasks,
	CompletedTasks, Issues)
SELECT P.VCardId, P.OrgId,  ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	P.ProjectId, P.Title AS ProjectName, PSL.StatusName,
	(SELECT COUNT(*) FROM TASKS T WHERE T.ProjectId = P.ProjectId AND T.IsCompleted = 0) +
	(SELECT COUNT(*) FROM TODO T WHERE T.ProjectId = P.ProjectId AND T.IsCompleted = 0) AS OpenTasks,
	(SELECT COUNT(*) FROM TASKS T WHERE T.ProjectId = P.ProjectId AND T.IsCompleted = 1) +
	(SELECT COUNT(*) FROM TODO T WHERE T.ProjectId = P.ProjectId AND T.IsCompleted = 1) AS CompletedTasks,
	(SELECT COUNT(*) FROM INCIDENTS I WHERE I.ProjectId = P.ProjectId) AS Issues
  FROM PROJECTS P
	JOIN PROJECT_STATUS_LANGUAGE PSL ON (P.StatusId = PSL.StatusId AND PSL.LanguageId = @LanguageId)
	LEFT JOIN ORGANIZATIONS O ON (P.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (P.VCardId = V.VCardId)
  WHERE (@PortfolioId = 0 OR P.ProjectId IN
		(SELECT ProjectId FROM PROJECT_GROUP WHERE ProjectGroupId = @PortfolioId))
	AND (@PhaseId = 0 OR P.PhaseId = @PhaseId)
	AND (@StatusId = 0 OR P.StatusId = @StatusId)
	AND (@ManagerId = 0 OR P.ManagerId = @ManagerId)
	AND (@OrgId = -1 OR P.OrgId = @OrgId)
	AND (@VCardId = -1 OR P.VCardId = @VCardId)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR P.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
	)
DECLARE @CollapseNonClientProject bit
SET @CollapseNonClientProject = 0
IF EXISTS (SELECT * FROM COLLAPSED_PROJECTS_BYCLIENT WHERE UserId = @UserId AND VCardId = -1 AND OrgId = -1)
	SET @CollapseNonClientProject = 1
SELECT DISTINCT
	CASE WHEN d.VCardId IS NULL THEN -1 ELSE d.VCardId END AS VCardId,
	CASE WHEN d.OrgId IS NULL THEN -1 ELSE d.OrgId END AS OrgId,
	CAST (1 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	0 AS ProjectId, '' AS ProjectName, '' AS StatusName,
	0 AS OpenTasks, 0 AS CompletedTasks, 0 AS Issues,
	CASE WHEN
		(CP.OrgId IS NULL AND CP.VCardId IS NULL  AND  (d.OrgId IS NOT NULL OR d.VCardId IS NOT NULL))
		OR
		(d.OrgId IS NULL AND d.VCardId IS NULL AND @CollapseNonClientProject = 0)
	THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS IsCollapsed
	FROM @Dummy d
	LEFT JOIN COLLAPSED_PROJECTS_BYCLIENT CP ON ((d.VCardId = CP.VCardId OR d.OrgId = CP.OrgId) AND CP.UserId = @UserId)
UNION ALL
SELECT CASE WHEN d.VCardId IS NULL THEN -1 ELSE d.VCardId END AS VCardId,
	CASE WHEN d.OrgId IS NULL THEN -1 ELSE d.OrgId END AS OrgId,
	CAST (0 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	ProjectId, ProjectName, StatusName, OpenTasks,
	CompletedTasks, Issues, CAST(0 as bit) as IsCollapsed
  FROM @Dummy d
	LEFT JOIN COLLAPSED_PROJECTS_BYCLIENT CP ON ((d.VCardId = CP.VCardId OR d.OrgId = CP.OrgId) AND CP.UserId = @UserId)
  WHERE
	(CP.OrgId IS NULL AND CP.VCardId IS NULL  AND  (d.OrgId IS NOT NULL OR d.VCardId IS NOT NULL))
		OR
		(d.OrgId IS NULL AND d.vCardId IS NULL AND @CollapseNonClientProject = 0)
ORDER BY ClientName, ProjectName
GO
PRINT N'Altering [dbo].[IncidentsGetForManagerView]'
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER PROCEDURE [dbo].[IncidentsGetForManagerView]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
SELECT I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, 7 AS ItemType, I.CreationDate,
	I.CreationDate as StartDate, I.ActualFinishdate as ActualFinishDate, I.ActualOpenDate as ActualStartDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, B.ManagerId,  I.Identifier
  FROM INCIDENTS I, PRIORITY_LANGUAGE P, INCIDENTBOX B
  WHERE I.IncidentBoxId = B.IncidentBoxId AND
	I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId AND
	(@ManagerId=0 OR B.ManagerId=@ManagerId) AND
	(@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND (@OrgId=0 OR I.OrgId=@OrgId)
	AND (@VCardId=0 OR I.VCardId=@VCardId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
	AND
	(
		@PrincipalId = 1
	OR
		IncidentId IN (SELECT IncidentId FROM INCIDENT_SECURITY_ALL
				WHERE IsRealIncidentResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
		OR (ResponsibleId = @PrincipalId OR ResponsibleId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
	)
GO
PRINT N'Altering [dbo].[IncidentsGetForResourceView]'
GO
ALTER PROCEDURE [dbo].[IncidentsGetForResourceView]
	@UserId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
 SELECT DISTINCT I.IncidentId AS ItemId, I.Title, B.ManagerId, I.PriorityId, P.PriorityName, 7 AS ItemType, I.CreationDate, I.CreationDate as StartDate,
	I.ActualFinishdate as ActualFinishDate, I.ActualOpenDate as ActualStartDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	0 as ReasonId, I.ProjectId, PR.Title as ProjectTitle, I.StateId, 0 as CompletionTypeId,  I.Identifier
  FROM INCIDENTS I
	 LEFT JOIN PROJECTS PR ON I.ProjectId=PR.ProjectId
	JOIN INCIDENT_SECURITY_ALL ISS ON (I.IncidentId = ISS.IncidentId  AND ISS.PrincipalId = @UserId)
	 JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
	JOIN INCIDENT_RESOURCES IR ON (I.IncidentId = IR.IncidentId AND IR.PrincipalId = @UserId)
  WHERE
	(@ManagerId=0 OR B.ManagerId=@ManagerId)
	AND
	(@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND (@OrgId=0 OR I.OrgId=@OrgId)
	AND (@VCardId=0 OR I.VCardId=@VCardId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
	AND
	(I.ResponsibleId = @UserId OR ISS.IsRealIncidentResource=1)
GO
PRINT N'Altering [dbo].[DocumentsGetByFilterGroupedByClient]'
GO
ALTER PROCEDURE [dbo].[DocumentsGetByFilterGroupedByClient]
	@ProjectId as int,
	@ManagerId as int,
	@ResourceId as int,
	@PriorityId as int,
	@StatusId as int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@OrgId as int,
	@VCardId as int
as
SET @Keyword = '%' + @Keyword + '%'
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @DocumentObjectType int
SET @DocumentObjectType = 16
DECLARE @Documents
	TABLE (DocumentId int, ProjectId int, ProjectTitle nvarchar(255), CreatorId int, CreatorName nvarchar(102), ManagerId int, ManagerName nvarchar(102),
		Title nvarchar(255), CreationDate DateTime, PriorityId int, PriorityName nvarchar(50), VCardId int, OrgId int, ClientName nvarchar(255),
		StatusId int, StatusName nvarchar(50), IsCompleted bit, StateId int, CanEdit int, CanDelete int)
INSERT INTO @Documents
SELECT D.DocumentId, D.ProjectId, P.Title AS ProjectTitle,
	D.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	D.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	D.Title, D.CreationDate, D.PriorityId, PR.PriorityName,
	D.VCardId, D.OrgId,  ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	D.StatusId, S.StatusName, D.IsCompleted, D.StateId,
	CASE WHEN @IsPPM = 1 OR D.ManagerId = @UserId THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR D.ManagerId = @UserId THEN 1 ELSE 0 END AS CanDelete
  FROM DOCUMENTS D
	LEFT JOIN PROJECTS P ON (D.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (D.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN DOCUMENT_STATUS S ON (D.StatusId = S.StatusId)
	JOIN USERS U1 ON (D.CreatorId = U1.PrincipalId)
	JOIN USERS U2 ON (D.ManagerId = U2.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (D.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (D.VCardId = V.VCardId)
  WHERE
	(@ProjectId = 0 OR D.ProjectId = @ProjectId OR (@ProjectId = -1 AND D.ProjectId IS NULL))
	AND (@ManagerId = 0 OR D.DocumentId IN (SELECT DocumentId FROM DOCUMENT_SECURITY_ALL WHERE PrincipalId = @ManagerId AND IsManager = 1))
	AND (@ResourceId = 0 OR D.DocumentId IN (SELECT DocumentId FROM DOCUMENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND IsResource = 1))
	AND (@PriorityId = -1 OR D.PriorityId = @PriorityId)
	AND (@StatusId = 0 OR D.StatusId = @StatusId)
	AND (@OrgId = -1 OR D.OrgId = @OrgId)
	AND (@VCardId = -1 OR D.VCardId = @VCardId)
	AND (D.Title LIKE @Keyword OR D.[Description] LIKE @Keyword)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR D.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR D.DocumentId IN
			(SELECT DocumentId FROM DOCUMENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsResource = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND D.DocumentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @DocumentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND D.DocumentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @DocumentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND D.DocumentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @DocumentObjectType AND CategoryId = -@CategoryType
			)
	)
DECLARE @CollapseNonClientDocument bit
SET @CollapseNonClientDocument = 0
IF EXISTS (SELECT * FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE UserId = @UserId AND vCardId = -1 AND OrgId = -1)
	SET @CollapseNonClientDocument = 1
SELECT DISTINCT
	CASE WHEN D.VCardId IS NULL THEN -1 ELSE D.VCardId END AS VCardId,
	CASE WHEN D.OrgId IS NULL THEN -1 ELSE D.OrgId END AS OrgId,
	CAST (1 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	0 AS ProjectId, '' AS ProjectTitle,
	0 as DocumentId, '' as Title, 0 as CreatorId, '' as CreatorName, 0 as ManagerId, '' as ManagerName,
	NULL as CreationDate, -1 as PriorityId, '' as PriorityName,
	0 as StatusId, '' as StatusName, 0 AS StateId, 0 as IsCompleted, 0 as CanEdit, 0 as CanDelete,
	CASE WHEN
		(CD.OrgId IS NULL AND CD.vCardId IS NULL  AND  (D.OrgId IS NOT NULL OR D.VCardId IS NOT NULL))
		OR
		(D.OrgId IS NULL AND D.VCardId IS NULL AND @CollapseNonClientDocument = 0)
	THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS IsCollapsed
  FROM @Documents D
		LEFT JOIN COLLAPSED_DOCUMENTS_BYCLIENT CD ON ((D.VCardId = CD.VCardId OR D.OrgId = CD.OrgId) AND CD.UserId = @UserId)
UNION ALL
SELECT
	CASE WHEN D.VCardId IS NULL THEN -1 ELSE D.VCardId END AS VCardId,
	CASE WHEN D.OrgId IS NULL THEN -1 ELSE D.OrgId END AS OrgId,
	CAST (0 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	CASE WHEN D.ProjectId IS NULL THEN -1 ELSE D.ProjectId END AS ProjectId,
	CASE WHEN ProjectTitle IS NULL THEN '' ELSE ProjectTitle END AS ProjectTitle,
	DocumentId, Title, CreatorId, CreatorName, ManagerId, ManagerName, CreationDate, PriorityId, PriorityName,
	StatusId, StatusName, IsCompleted, StateId, CanEdit, CanDelete, CAST(0 as bit) as IsCollapsed
  FROM @Documents D
		LEFT JOIN COLLAPSED_DOCUMENTS_BYCLIENT CD ON ((D.VCardId = CD.VCardId OR D.OrgId = CD.OrgId) AND CD.UserId = @UserId)
  WHERE
	(CD.OrgId IS NULL AND CD.VCardId IS NULL  AND  (D.OrgId IS NOT NULL OR D.VCardId IS NOT NULL))
	OR
	(D.OrgId IS NULL AND D.VCardId IS NULL AND @CollapseNonClientDocument = 0)
ORDER BY ClientName, Title
GO
PRINT N'Altering [dbo].[DocumentsGetByFilterGroupedByProject]'
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[DocumentsGetByFilterGroupedByProject]
	@ProjectId as int,
	@ManagerId as int,
	@ResourceId as int,
	@PriorityId as int,
	@StatusId as int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@OrgId as int,
	@VCardId as int
as
SET @Keyword = '%' + @Keyword + '%'
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @DocumentObjectType int
SET @DocumentObjectType = 16
DECLARE @Documents
	TABLE (DocumentId int, ProjectId int, ProjectTitle nvarchar(255), CreatorId int, CreatorName nvarchar(102), ManagerId int, ManagerName nvarchar(102),
		Title nvarchar(255), CreationDate DateTime, PriorityId int, PriorityName nvarchar(50),
		StatusId int, StatusName nvarchar(50), IsCompleted bit, StateId int, CanEdit int, CanDelete int)
INSERT INTO @Documents
SELECT D.DocumentId, D.ProjectId, P.Title AS ProjectTitle,
	D.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	D.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	D.Title, D.CreationDate, D.PriorityId, PR.PriorityName, D.StatusId, S.StatusName, D.IsCompleted, D.StateId,
	CASE WHEN @IsPPM = 1 OR D.ManagerId = @UserId THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR D.ManagerId = @UserId THEN 1 ELSE 0 END AS CanDelete
  FROM DOCUMENTS D
	LEFT JOIN PROJECTS P ON (D.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (D.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN DOCUMENT_STATUS S ON (D.StatusId = S.StatusId)
	JOIN USERS U1 ON (D.CreatorId = U1.PrincipalId)
	JOIN USERS U2 ON (D.ManagerId = U2.PrincipalId)
  WHERE
	(@ProjectId = 0 OR D.ProjectId = @ProjectId OR (@ProjectId = -1 AND D.ProjectId IS NULL))
	AND (@ManagerId = 0 OR D.DocumentId IN (SELECT DocumentId FROM DOCUMENT_SECURITY_ALL WHERE PrincipalId = @ManagerId AND IsManager = 1))
	AND (@ResourceId = 0 OR D.DocumentId IN (SELECT DocumentId FROM DOCUMENT_SECURITY_ALL WHERE PrincipalId = @ResourceId AND IsResource = 1))
	AND (@PriorityId = -1 OR D.PriorityId = @PriorityId)
	AND (@StatusId = 0 OR D.StatusId = @StatusId)
	AND (@OrgId = -1 OR D.OrgId = @OrgId)
	AND (@VCardId = -1 OR D.VCardId = @VCardId)
	AND (D.Title LIKE @Keyword OR D.[Description] LIKE @Keyword)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR D.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR D.DocumentId IN
			(SELECT DocumentId FROM DOCUMENT_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsResource = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND D.DocumentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @DocumentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND D.DocumentId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @DocumentObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND D.DocumentId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @DocumentObjectType AND CategoryId = -@CategoryType
			)
	)
DECLARE @CollapseNonProjectDocument bit
SET @CollapseNonProjectDocument = 0
IF EXISTS (SELECT * FROM COLLAPSED_DOCUMENTS WHERE UserId = @UserId AND ProjectId = -1)
	SET @CollapseNonProjectDocument = 1
SELECT DISTINCT CASE WHEN D.ProjectId IS NULL THEN -1 ELSE D.ProjectId END AS ProjectId,
	CASE WHEN ProjectTitle IS NULL THEN '' ELSE ProjectTitle END AS ProjectTitle,
	0 as DocumentId, '' as Title, 0 as CreatorId, '' as CreatorName, 0 as ManagerId, '' as ManagerName,
	NULL as CreationDate, -1 as PriorityId, '' as PriorityName,
	0 as StatusId, '' as StatusName, 0 AS StateId, 0 as IsCompleted, 0 as CanEdit, 0 as CanDelete, CAST (1 as bit) AS IsProject,
	CASE WHEN
		(CD.ProjectId IS NULL  AND D.ProjectId IS NOT NULL)
		OR
		(D.ProjectId IS NULL AND @CollapseNonProjectDocument = 0)
	THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS IsCollapsed
  FROM @Documents D
		LEFT JOIN COLLAPSED_DOCUMENTS CD ON (D.ProjectId = CD.ProjectId AND CD.UserId = @UserId)
UNION ALL
SELECT CASE WHEN D.ProjectId IS NULL THEN -1 ELSE D.ProjectId END AS ProjectId,
	CASE WHEN ProjectTitle IS NULL THEN '' ELSE ProjectTitle END AS ProjectTitle,
	DocumentId, Title, CreatorId, CreatorName, ManagerId, ManagerName, CreationDate, PriorityId, PriorityName,
	StatusId, StatusName, IsCompleted, StateId, CanEdit, CanDelete, CAST (0 as bit) AS IsProject, CAST(0 as bit) as IsCollapsed
  FROM @Documents D
	LEFT JOIN COLLAPSED_DOCUMENTS CD ON (D.ProjectId = CD.ProjectId AND CD.UserId = @UserId)
  WHERE
	(CD.ProjectId IS NULL  AND D.ProjectId IS NOT NULL)
	OR
	(D.ProjectId IS NULL AND @CollapseNonProjectDocument = 0)
ORDER BY ProjectTitle, Title
GO
PRINT N'Altering [dbo].[OrganizationDelete]'
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE [dbo].[OrganizationDelete]
	@OrgId as int
as
DECLARE @ObjectType int
SET @ObjectType = 21
DELETE FROM TAGS WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM HISTORY WHERE ObjectId = @OrgId AND ObjectTypeId = @ObjectType
DELETE FROM COLLAPSED_PROJECTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_INCIDENTS_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_TODO_BYCLIENT WHERE OrgId = @OrgId
DELETE FROM COLLAPSED_DOCUMENTS_BYCLIENT WHERE OrgId = @OrgId
UPDATE GROUPS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE EVENTS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE DOCUMENTS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE INCIDENTS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE PROJECTS SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE TODO SET OrgId = NULL WHERE OrgId = @OrgId
UPDATE VCard SET OrganizationId = NULL WHERE OrganizationId = @OrgId
DELETE FROM ORGANIZATIONS WHERE OrgId = @OrgId
GO
PRINT N'Altering [dbo].[DocumentsGetForManagerView]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].[DocumentsGetForManagerView]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @OverdueState as int
set @OverdueState=3
SELECT  D.DocumentId AS ItemId, D.Title, D.PriorityId, P.PriorityName, 16 AS ItemType, D.CreationDate, D.CreationDate as StartDate, D.ClosedDate as FinishDate, 0 as PercentCompleted, D.IsCompleted,
	D.ManagerId, D.ReasonId, D.ProjectId, D.StateId, 0 as CompletionTypeId
  FROM DOCUMENTS D, PRIORITY_LANGUAGE P
  WHERE (@ManagerId=0 OR D.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR D.ProjectId=@ProjectId)
	AND (@OrgId=0 OR D.OrgId=@OrgId)
	AND (@VCardId=0 OR D.VCardId=@VCardId)
	AND D.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId
	AND
	(
	((@StartDate is not null)AND(D.CreationDate<=@StartDate)AND(D.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(D.ClosedDate>=@CompletedDate)AND(D.IsCompleted=1))
	OR((@ShowActive=1 AND (D.StateId=@ActiveState OR D.StateId=@OverdueState)))
	)
	AND
	(
		@PrincipalId = 1
	OR
		DocumentId IN (SELECT DocumentId FROM DOCUMENT_SECURITY_ALL
				WHERE IsRealDocumentResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
GO
PRINT N'Altering [dbo].[DocumentsGetForResourceView]'
GO
ALTER PROCEDURE [dbo].[DocumentsGetForResourceView]
	@UserId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @OverdueState as int
set @OverdueState=3
 SELECT DISTINCT D.DocumentId AS ItemId, D.Title, D.PriorityId, P.PriorityName, 16 AS ItemType, D.CreationDate, D.CreationDate as StartDate, D.ClosedDate as FinishDate, 0 as PercentCompleted, D.IsCompleted,
	D.ManagerId, D.ReasonId, D.ProjectId, PR.Title as ProjectTitle, D.StateId, 0 as CompletionTypeId
  FROM DOCUMENTS D
  LEFT JOIN PROJECTS PR ON D.ProjectId=PR.ProjectId
  JOIN DOCUMENT_SECURITY_ALL DS ON (D.DocumentId = DS.DocumentId AND DS.IsRealDocumentResource=1 AND DS.PrincipalId = @UserId)
  JOIN PRIORITY_LANGUAGE P ON (D.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE  (@ManagerId=0 OR D.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR D.ProjectId=@ProjectId)
	AND (@OrgId=0 OR D.OrgId=@OrgId)
	AND (@VCardId=0 OR D.VCardId=@VCardId)
	AND
	(
	((@StartDate is not null)AND(D.CreationDate<=@StartDate)AND(D.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(D.ClosedDate>=@CompletedDate)AND(D.IsCompleted=1))
	OR((@ShowActive=1 AND (D.StateId=@ActiveState OR D.StateId=@OverdueState)))
	)
GO
PRINT N'Altering [dbo].[ToDoGetByFilterGroupedByClient]'
GO
ALTER PROCEDURE [dbo].[ToDoGetByFilterGroupedByClient]
	@ProjectId as int,
	@ManagerId as int,
	@ResourceId as int,
	@PriorityId as int,
	@Keyword as nvarchar(100),
	@UserId as int,
	@LanguageId as int,
	@CategoryType as int,
	@OrgId as int,
	@VCardId as int
as
SET @Keyword = '%' + @Keyword + '%'
DECLARE @IsPPM bit
SET @IsPPM = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 4)
	SET @IsPPM = 1
DECLARE @IsExec bit
SET @IsExec = 0
IF EXISTS(SELECT * FROM USER_GROUP WHERE UserId = @UserId AND GroupId = 7)
	SET @IsExec = 1
DECLARE @ToDoObjectType int
SET @ToDoObjectType = 6
DECLARE @ToDos
	TABLE (ToDoId int, ProjectId int, ProjectTitle nvarchar(255), CreatorId int, CreatorName nvarchar(102), ManagerId int, ManagerName nvarchar(102),
		Title nvarchar(255), CreationDate DateTime, PriorityId int, PriorityName nvarchar(50), VCardId int, OrgId int, ClientName nvarchar(255),
		IsCompleted bit, CanEdit int, CanDelete int)
INSERT INTO @ToDos
SELECT T.ToDoId, T.ProjectId, P.Title AS ProjectTitle,
	T.CreatorId, U1.LastName + ', ' + U1.FirstName AS CreatorName,
	T.ManagerId, U2.LastName + ', ' + U2.FirstName AS ManagerName,
	T.Title, T.CreationDate, T.PriorityId, PR.PriorityName,
	T.VCardId, T.OrgId,  ISNULL(O.OrgName, ISNULL(V.FullName, '')) AS ClientName,
	T.IsCompleted,
	CASE WHEN @IsPPM = 1 OR T.ManagerId = @UserId THEN 1 ELSE 0 END AS CanEdit,
	CASE WHEN @IsPPM = 1 OR T.ManagerId = @UserId THEN 1 ELSE 0 END AS CanDelete
  FROM TODO T
	LEFT JOIN PROJECTS P ON (T.ProjectId = P.ProjectId)
	JOIN PRIORITY_LANGUAGE PR ON (T.PriorityId = PR.PriorityId AND PR.LanguageId = @LanguageId)
	JOIN USERS U1 ON (T.CreatorId = U1.PrincipalId)
	JOIN USERS U2 ON (T.ManagerId = U2.PrincipalId)
	LEFT JOIN ORGANIZATIONS O ON (T.OrgId = O.OrgId)
	LEFT JOIN VCard V ON (T.VCardId = V.VCardId)
  WHERE
	(@ProjectId = 0 OR T.ProjectId = @ProjectId OR (@ProjectId = -1 AND T.ProjectId IS NULL))
	AND (@ManagerId = 0 OR T.ToDoId IN (SELECT ToDoId FROM TODO_SECURITY_ALL WHERE PrincipalId = @ManagerId AND IsManager = 1))
	AND (@ResourceId = 0 OR T.ToDoId IN (SELECT ToDoId FROM TODO_SECURITY_ALL WHERE PrincipalId = @ResourceId AND IsResource = 1))
	AND (@PriorityId = -1 OR T.PriorityId = @PriorityId)
	AND (@OrgId = 0 OR T.OrgId = @OrgId)
	AND (@VCardId = 0 OR T.VCardId = @VCardId)
	AND (T.Title LIKE @Keyword OR T.[Description] LIKE @Keyword)
	AND
	(	@IsPPM = 1 OR @IsExec = 1
		OR T.ProjectId IN
			(SELECT ProjectId FROM PROJECT_SECURITY
				WHERE PrincipalId = @UserId
					AND (IsManager = 1 OR IsExecutiveManager = 1 OR IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
			)
		OR T.ToDoId IN
			(SELECT ToDoId FROM TODO_SECURITY_ALL
				WHERE PrincipalId = @UserId AND (IsManager = 1 OR IsResource = 1)
			)
	)
	AND (@CategoryType = 0
		OR @CategoryType = 1 AND T.ToDoId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @ToDoObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType = 2 AND T.ToDoId NOT IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @ToDoObjectType
				AND CategoryId IN (SELECT CategoryId FROM CATEGORY_USER WHERE UserId = @UserId)
			)
		OR @CategoryType < 0 AND T.ToDoId IN
			(SELECT ObjectId
			  FROM OBJECT_CATEGORY
			  WHERE ObjectTypeId = @ToDoObjectType AND CategoryId = -@CategoryType
			)
	)
DECLARE @CollapseNonClientToDo bit
SET @CollapseNonClientToDo = 0
IF EXISTS (SELECT * FROM COLLAPSED_TODO_BYCLIENT WHERE UserId = @UserId AND vCardId = -1 AND OrgId = -1)
	SET @CollapseNonClientToDo = 1
SELECT DISTINCT
	CASE WHEN T.VCardId IS NULL THEN -1 ELSE T.VCardId END AS VCardId,
	CASE WHEN T.OrgId IS NULL THEN -1 ELSE T.OrgId END AS OrgId,
	CAST (1 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	0 AS ProjectId, '' AS ProjectTitle,
	0 as ToDoId, '' as Title, 0 as CreatorId, '' as CreatorName, 0 as ManagerId, '' as ManagerName,
	NULL as CreationDate, -1 as PriorityId, '' as PriorityName,
	CAST(0 as bit) as IsCompleted, 0 as CanEdit, 0 as CanDelete,
	CASE WHEN
		(CT.OrgId IS NULL AND CT.VCardId IS NULL  AND  (T.OrgId IS NOT NULL OR T.VCardId IS NOT NULL))
		OR
		(T.OrgId IS NULL AND T.VCardId IS NULL AND @CollapseNonClientToDo = 0)
	THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS IsCollapsed
  FROM @ToDos T
		LEFT JOIN COLLAPSED_TODO_BYCLIENT CT ON ((T.VCardId = CT.VCardId OR T.OrgId = CT.OrgId) AND CT.UserId = @UserId)
UNION ALL
SELECT
	CASE WHEN T.VCardId IS NULL THEN -1 ELSE T.VCardId END AS VCardId,
	CASE WHEN T.OrgId IS NULL THEN -1 ELSE T.OrgId END AS OrgId,
	CAST (0 as bit) AS IsClient,
	CASE WHEN ClientName IS NULL THEN '' ELSE ClientName END AS ClientName,
	CASE WHEN T.ProjectId IS NULL THEN -1 ELSE T.ProjectId END AS ProjectId,
	CASE WHEN ProjectTitle IS NULL THEN '' ELSE ProjectTitle END AS ProjectTitle,
	ToDoId, Title, CreatorId, CreatorName, ManagerId, ManagerName, CreationDate, PriorityId, PriorityName,
	IsCompleted, CanEdit, CanDelete, CAST(0 as bit) as IsCollapsed
  FROM @ToDos T
		LEFT JOIN COLLAPSED_TODO_BYCLIENT CT ON ((T.VCardId = CT.VCardId OR T.OrgId = CT.OrgId) AND CT.UserId = @UserId)
  WHERE
	(CT.OrgId IS NULL AND CT.VCardId IS NULL  AND  (T.OrgId IS NOT NULL OR T.VCardId IS NOT NULL))
	OR
	(T.OrgId IS NULL AND T.VCardId IS NULL AND @CollapseNonClientToDo = 0)
ORDER BY ClientName, Title
GO
PRINT N'Altering [dbo].[EventsGetForManagerView]'
GO
ALTER PROCEDURE [dbo].[EventsGetForManagerView]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @CompletedState as int
set @CompletedState=5
DECLARE @EventType int
SET @EventType = 4
SELECT E.EventId AS ItemId, E.Title, E.PriorityId, P.PriorityName, 4 AS ItemType, E.CreationDate, E.StartDate, E.FinishDate, 0 as PercentCompleted, CAST(0 as bit) as IsCompleted,
	E.ManagerId, 0 as ReasonId, E.ProjectId, E.StateId, 0 as CompletionTypeId,
	CASE WHEN R.RecurrenceId IS NULL THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS HasRecurrence
  FROM EVENTS E
	JOIN PRIORITY_LANGUAGE P ON (E.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	LEFT JOIN RECURRENCE R ON (E.EventId = R.ObjectId AND R.ObjectTypeId = @EventType)
  WHERE (@ManagerId=0 OR E.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR E.ProjectId=@ProjectId)
	AND (@OrgId=0 OR E.OrgId=@OrgId)
	AND (@VCardId=0 OR E.VCardId=@VCardId)
	AND
	(
		(R.RecurrenceId IS NULL AND
		(
			(@StartDate is not null AND E.StartDate<=@StartDate AND E.StateId=@UpcomingState)
			OR
			(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StateId=@CompletedState)
			OR
			(@ShowActive=1 AND E.StateId=@ActiveState)
		))
		OR
		(R.RecurrenceId IS NOT NULL AND
		(
			(@StartDate is not null AND E.StartDate<=@StartDate AND E.FinishDate>=@dt)
			OR
			(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StartDate<=@dt)
			OR
			(@ShowActive=1 AND E.StateId=@ActiveState)
		))
	)
	AND
	(
		@PrincipalId = 1
	OR
		EventId IN (SELECT EventId FROM EVENT_SECURITY_ALL
				WHERE IsResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
GO
PRINT N'Altering [dbo].[EventsGetForResourceView]'
GO
ALTER PROCEDURE [dbo].[EventsGetForResourceView]
	@UserId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @CompletedState as int
set @CompletedState=5
DECLARE @EventType int
SET @EventType = 4
 SELECT DISTINCT E.EventId AS ItemId, E.Title, E.PriorityId, P.PriorityName, 4 AS ItemType, E.CreationDate, E.StartDate, E.FinishDate, 0 as PercentCompleted, CAST(0 as bit) as IsCompleted,
	E.ManagerId, 0 as ReasonId, E.ProjectId, PR.Title as ProjectTitle, E.StateId, 0 as CompletionTypeId,
	CASE WHEN R.RecurrenceId IS NULL THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS HasRecurrence
  FROM EVENTS E
	LEFT JOIN PROJECTS PR ON E.ProjectId=PR.ProjectId
	JOIN EVENT_SECURITY_ALL ES ON (E.EventId = ES.EventId AND ES.IsResource=1 AND ES.PrincipalId = @UserId)
	JOIN PRIORITY_LANGUAGE P ON (E.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	LEFT JOIN RECURRENCE R ON (E.EventId = R.ObjectId AND R.ObjectTypeId = @EventType)
  WHERE (@ManagerId=0 OR E.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR E.ProjectId=@ProjectId)
	AND (@OrgId=0 OR E.OrgId=@OrgId)
	AND (@VCardId=0 OR E.VCardId=@VCardId)
	AND
	(
		(
			R.RecurrenceId IS NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.StateId=@UpcomingState)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StateId=@CompletedState)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
		OR
		(
			R.RecurrenceId IS NOT NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.FinishDate>=@dt)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StartDate<=@dt)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
	)
GO
PRINT N'Altering [dbo].[ObjectsGetForManagerViewGroupedByUser]'
GO
ALTER PROCEDURE [dbo].[ObjectsGetForManagerViewGroupedByUser]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState int, @ActiveState int, @OverdueState int, @SuspendedSate int, @CompletedState  int, @ReOpenState int, @OnCheckState int
SET @UpcomingState=1
SET @ActiveState=2
SET @OverdueState=3
SET @SuspendedSate = 4
SET @CompletedState=5
SET @ReOpenState = 6
SET @OnCheckState = 7
DECLARE @EventType int
SET @EventType = 4
SELECT U.PrincipalId, U.FirstName, U.LastName, 5 AS ItemType, T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate,
	T.ActualStartDate, T.ActualFinishDate, T.PercentCompleted, T.IsCompleted,
	PR.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN TASK_SECURITY TS ON (U.PrincipalId = TS.PrincipalId)
	JOIN TASKS T ON (TS.TaskId = T.TaskId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN PROJECTS PR ON (T.ProjectId=PR.ProjectId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND(TS.IsRealTaskResource=1)
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND @OrgId=0 AND @VCardId=0 AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 6 AS ItemType, T.TodoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, T.CreationDate, T.StartDate, T.FinishDate,
	T.ActualStartDate, T.ActualFinishDate, T.PercentCompleted, T.IsCompleted,
	T.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN TODO_SECURITY_ALL TS ON (U.PrincipalId = TS.PrincipalId)
	JOIN TODO T ON (TS.TodoId = T.TodoId)
	JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (TS.PrincipalId = @PrincipalId OR TS.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (TS.IsResource=1)
	AND (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND (@OrgId=0 OR T.OrgId=@OrgId)
	AND (@VCardId=0 OR T.VCardId=@VCardId)
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 7 AS ItemType, I.IncidentId AS ItemId, I.Title, I.PriorityId, P.PriorityName, I.CreationDate, I.CreationDate as StartDate, null as FinishDate,
	I.ActualOpenDate as ActualStartDate, I.ActualfinishDate as ActualFinishDate, 0 as PercentCompleted,
	CASE WHEN I.StateId = @SuspendedSate OR I.StateId = @CompletedState THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END AS IsCompleted,
	B.ManagerId, 0 as ReasonId, I.ProjectId, I.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN INCIDENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN INCIDENTS I ON (S.IncidentId = I.IncidentId)
	JOIN PRIORITY_LANGUAGE P ON (I.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	JOIN INCIDENTBOX B ON (I.IncidentBoxId = B.IncidentBoxId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealIncidentResource=1 OR S.IsIncidentResponsible = 1)
	AND (@ManagerId=0 OR B.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR I.ProjectId=@ProjectId)
	AND (@OrgId=0 OR I.OrgId=@OrgId)
	AND (@VCardId=0 OR I.VCardId=@VCardId)
	AND
	(
		(@CompletedDate is not null AND I.ActualFinishDate>=@CompletedDate AND (I.StateId=@SuspendedSate OR I.StateId=@CompletedState))
		OR
		(@ShowActive=1 AND (I.StateId = @UpcomingState OR I.StateId=@ActiveState OR I.StateId=@ReOpenState OR I.StateId = @OnCheckState))
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 4 AS ItemType, E.EventId AS ItemId, E.Title, E.PriorityId, P.PriorityName, E.CreationDate, E.StartDate, E.FinishDate,
	null as ActualStartDate, null as ActualFinishDate, 0 as PercentCompleted, CAST(0 as bit) as IsCompleted,
	E.ManagerId, 0 as ReasonId, E.ProjectId, E.StateId, 0 as CompletionTypeId,
	CASE WHEN R.RecurrenceId IS NULL THEN CAST(0 as bit) ELSE CAST(1 as bit) END AS HasRecurrence
  FROM Users U
	JOIN EVENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN EVENTS E ON (S.EventId = E.EventId)
	JOIN PRIORITY_LANGUAGE P ON (E.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
	LEFT JOIN RECURRENCE R ON (E.EventId = R.ObjectId AND R.ObjectTypeId = @EventType)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsResource=1)
	AND (@ManagerId=0 OR E.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR E.ProjectId=@ProjectId)
	AND (@OrgId=0 OR E.OrgId=@OrgId)
	AND (@VCardId=0 OR E.VCardId=@VCardId)
	AND
	(
		(
			R.RecurrenceId IS NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.StateId=@UpcomingState)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StateId=@CompletedState)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
		OR
		(
			R.RecurrenceId IS NOT NULL AND
			(
				(@StartDate is not null AND E.StartDate<=@StartDate AND E.FinishDate>=@dt)
				OR
				(@CompletedDate is not null AND E.FinishDate>=@CompletedDate AND E.StartDate<=@dt)
				OR
				(@ShowActive=1 AND E.StateId=@ActiveState)
			)
		)
	)
UNION ALL
SELECT U.PrincipalId, U.FirstName, U.LastName, 16 AS ItemType, D.DocumentId AS ItemId, D.Title, D.PriorityId, P.PriorityName, D.CreationDate, D.CreationDate as StartDate, null as FinishDate,
	null as ActualStartDate, D.ClosedDate as ActualFinishDate, 0 as PercentCompleted, D.IsCompleted,
	D.ManagerId, D.ReasonId, D.ProjectId, D.StateId, 0 as CompletionTypeId, CAST(0 as bit) AS HasRecurrence
  FROM Users U
	JOIN DOCUMENT_SECURITY_ALL S ON (U.PrincipalId = S.PrincipalId)
	JOIN DOCUMENTS D ON (S.DocumentId = D.DocumentId)
	JOIN PRIORITY_LANGUAGE P ON (D.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  WHERE (S.PrincipalId = @PrincipalId OR S.PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId ))
	AND (S.IsRealDocumentResource=1)
	AND (@ManagerId=0 OR D.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR D.ProjectId=@ProjectId)
	AND (@OrgId=0 OR D.OrgId=@OrgId)
	AND (@VCardId=0 OR D.VCardId=@VCardId)
	AND
	(
	((@StartDate is not null)AND(D.CreationDate<=@StartDate)AND(D.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(D.ClosedDate>=@CompletedDate)AND(D.IsCompleted=1))
	OR((@ShowActive=1 AND (D.StateId=@ActiveState OR D.StateId=@OverdueState)))
	)
ORDER BY U.PrincipalId, ItemType, ItemId
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetForManagerView]'
GO
ALTER PROCEDURE [dbo].[ToDoAndTasksGetForManagerView]
	@PrincipalId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime=null,
	@StartDate as datetime=null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @OverdueState as int
set @OverdueState=3
SELECT T.ToDoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 6 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	T.PercentCompleted, T.IsCompleted,
	T.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId
  FROM TODO T, PRIORITY_LANGUAGE P
  WHERE (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND (@OrgId=0 OR @OrgId = T.OrgId)
	AND (@VCardId=0 OR @VCardId = T.VCardId)
	AND T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
	AND
	(
		@PrincipalId = 1
	OR
		ToDoId IN (SELECT ToDoId FROM TODO_SECURITY_ALL
				WHERE IsResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
 UNION ALL
 SELECT T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 5 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	T.PercentCompleted, T.IsCompleted,
	PR.ManagerId, T.ReasonId, T.ProjectId, T.StateId, T.CompletionTypeId
  FROM TASKS T,  PRIORITY_LANGUAGE P, PROJECTS PR
  WHERE T.ProjectId=PR.ProjectId
	AND (@ManagerId=0 OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId
	AND @OrgId=0 AND @VCardId=0 AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND(T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1))
	OR((@ShowActive=1 AND (T.StateId=@ActiveState OR T.StateId=@OverdueState)))
	)
	AND
	(
		@PrincipalId = 1
	OR
		TaskId IN (SELECT TaskId FROM TASK_SECURITY
				WHERE IsRealTaskResource = 1 AND (PrincipalId = @PrincipalId OR PrincipalId IN (SELECT UserId FROM User_Group UG WHERE UG.GroupId=@PrincipalId))
			)
	)
ORDER By ItemType, FinishDate DESC
GO
PRINT N'Altering [dbo].[ToDoAndTasksGetForResourceView]'
GO
ALTER PROCEDURE [dbo].[ToDoAndTasksGetForResourceView]
	@UserId as int,
	@LanguageId as int,
	@ManagerId as int,
	@ProjectId as int,
	@ShowActive as bit,
	@CompletedDate as datetime = null,
	@StartDate as datetime = null,
	@OrgId as int,
	@VCardId as int
as
DECLARE @dt AS datetime
SET @dt = GETUTCDATE()
DECLARE @UpcomingState as int
set @UpcomingState=1
DECLARE @ActiveState as int
set @ActiveState=2
DECLARE @OverdueState as int
set @OverdueState=3
DECLARE @All int
SET @All = 1
 SELECT DISTINCT T.ToDoId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 6 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	CASE WHEN T.ReasonId = @All THEN TR.PercentCompleted ELSE T.PercentCompleted END AS PercentCompleted,
	T.IsCompleted, T.ManagerId, T.ReasonId, T.ProjectId, PR.Title as ProjectTitle, T.StateId, T.CompletionTypeId
  FROM TODO T
  LEFT JOIN PROJECTS PR ON T.ProjectId=PR.ProjectId
  JOIN TODO_SECURITY_ALL TS ON (T.ToDoId = TS.ToDoId AND TS.IsResource=1 AND TS.PrincipalId = @UserId)
  JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  JOIN TODO_RESOURCES TR ON (TR.ToDoId = T.ToDoId) AND (TR.PrincipalId=@UserId)
  WHERE (@ManagerId=0 OR T.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND (@OrgId=0 OR @OrgId = T.OrgId)
	AND (@VCardId=0 OR @VCardId = T.VCardId)
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND ((T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1)) OR (TR.ActualFinishDate>=@CompletedDate AND TR.PercentCompleted=100) )
	OR(@ShowActive=1 AND TR.PercentCompleted!=100 AND(T.StateId=@ActiveState OR T.StateId=@OverdueState))
	)
 UNION ALL
 SELECT DISTINCT T.TaskId AS ItemId, T.Title, P.PriorityId, P.PriorityName, 5 AS ItemType, T.CreationDate, T.StartDate, T.FinishDate, T.ActualStartDate, T.ActualFinishDate,
	CASE WHEN T.ReasonId = @All THEN TR.PercentCompleted ELSE T.PercentCompleted END AS PercentCompleted,
	T.IsCompleted, PR.ManagerId, T.ReasonId, T.ProjectId, PR.Title as ProjectTitle, T.StateId, T.CompletionTypeId
  FROM TASKS T
  LEFT JOIN PROJECTS PR ON T.ProjectId=PR.ProjectId
  JOIN TASK_SECURITY TS ON (T.TaskId = TS.TaskId AND TS.IsRealTaskResource=1 AND TS.PrincipalId = @UserId)
  JOIN PRIORITY_LANGUAGE P ON (T.PriorityId = P.PriorityId AND P.LanguageId = @LanguageId)
  JOIN TASK_RESOURCES TR ON (TR.TaskId = T.TaskId) AND (TR.PrincipalId=@UserId)
  WHERE (@ManagerId=0 OR PR.ManagerId=@ManagerId)
	AND (@ProjectId=0 OR T.ProjectId=@ProjectId)
	AND @OrgId=0 AND @VCardId=0 AND T.IsMilestone = 0 AND T.IsSummary = 0
	AND
	(
	((@StartDate is not null)AND(T.StartDate<=@StartDate)AND(T.StateId=@UpcomingState))
	OR((@CompletedDate is not null)AND ((T.ActualFinishDate>=@CompletedDate)AND(T.IsCompleted=1)) OR (TR.ActualFinishDate>=@CompletedDate AND TR.PercentCompleted=100) )
	OR(@ShowActive=1 AND TR.PercentCompleted!=100 AND(T.StateId=@ActiveState OR T.StateId=@OverdueState))
	)
ORDER By ItemType, T.FinishDate DESC
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
