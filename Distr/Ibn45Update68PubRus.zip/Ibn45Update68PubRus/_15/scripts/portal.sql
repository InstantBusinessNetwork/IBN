SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[WSSettings]'
GO
CREATE TABLE [dbo].[WSSettings]
(
[LeftCol] [nvarchar] (100) NULL,
[RightCol] [nvarchar] (100) NULL,
[HideCol] [nvarchar] (100) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[WSSettingAdd]'
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF
GO
CREATE PROCEDURE [dbo].WSSettingAdd
	@LeftCol nvarchar(100),
	@RightCol nvarchar(100),
	@HideCol nvarchar(100)
AS
INSERT INTO WSSettings (LeftCol, RightCol, HideCol)
  VALUES(@LeftCol, @RightCol, @HideCol)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[WSSettingGet]'
GO
CREATE PROCEDURE [dbo].WSSettingGet
AS
SELECT LeftCol,  RightCol, HideCol FROM WSSettings
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[WSSettingUpdate]'
GO
CREATE PROCEDURE [dbo].WSSettingUpdate
	@LeftCol nvarchar(100),
	@RightCol nvarchar(100),
	@HideCol nvarchar(100)
AS
UPDATE WSSettings
SET LeftCol = @LeftCol, RightCol = @RightCol, HideCol = @HideCol
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO

DELETE FROM fsc_AccessControlLists
WHERE DirectoryId IN (SELECT DirectoryId FROM fsc_Directories WHERE ContainerKey LIKE 'ForumNodeId_%')

-- Fill fsc_AccessControlLists
INSERT INTO fsc_AccessControlLists (DirectoryId, IsInherited) 
SELECT DirectoryId, 0 FROM fsc_Directories 
WHERE ContainerKey LIKE 'ForumNodeId_%'

-- Fill fsc_AccessControlEntries
INSERT INTO fsc_AccessControlEntries (AclId, IsInherited, Role, PrincipalId, [Action], Allow, IsInternal) 
SELECT AclId, 0, NULL, 1, N'Read', 1, 1 FROM fsc_AccessControlLists
WHERE DirectoryId IN (SELECT DirectoryId FROM fsc_Directories WHERE ContainerKey LIKE 'ForumNodeId_%')
GO
