SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Dropping constraints from [dbo].[COMPANIES]'
GO
ALTER TABLE [dbo].[COMPANIES] DROP CONSTRAINT [DF_COMPANIES_WinLogin]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping constraints from [dbo].[COMPANIES]'
GO
ALTER TABLE [dbo].[COMPANIES] DROP CONSTRAINT [DF_COMPANIES_UseWebDav]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[Company_UseWebDavSet]'
GO
DROP PROCEDURE [dbo].[Company_UseWebDavSet]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[Company_LoginADGet]'
GO
DROP PROCEDURE [dbo].[Company_LoginADGet]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[Company_LoginADSet]'
GO
DROP PROCEDURE [dbo].[Company_LoginADSet]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Dropping [dbo].[Company_UseWebDavGet]'
GO
DROP PROCEDURE [dbo].[Company_UseWebDavGet]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[COMPANIES]'
GO
ALTER TABLE [dbo].[COMPANIES] DROP
COLUMN [LoginAD],
COLUMN [UseWebDav]
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_GET_COMPANY_BY_APP_ID]'
GO
SET ANSI_NULLS OFF
GO
ALTER PROCEDURE [dbo].ASP_GET_COMPANY_BY_APP_ID
	@app_id as nvarchar(100)
AS
SELECT company_id, use_im, is_global, domain, enable_alerts, company_type, use_ssl, Port, end_date
 FROM Companies WHERE app_id = @app_id
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Altering [dbo].[ASP_GET_COMPANY]'
GO
ALTER PROCEDURE [dbo].ASP_GET_COMPANY
	@company_type INT,
	@company_id INT
AS
SELECT company_id, company_name, domain, [db_name], app_id, C.description, contact_name, contact_phone, contact_email, support_name, support_email, product_name,
	theme, use_im, title1, title2, text1, text2, max_users, max_external_users, is_global, creation_date, company_type, start_date, end_date, rate_per_user, is_active, max_disk_space,
	enable_alerts, show_admin_wizard, use_ssl, firstdayofweek, Port,
	CC.StatusId, S.Name AS StatusName, CC.Description AS StatusDescription, DATALENGTH(S.Icon) AS StatusIconLength
 FROM Companies C
LEFT JOIN CompanyComment CC ON CC.CompanyId = company_id
LEFT JOIN CompanyStatus S ON S.StatusId = CC.StatusId
 WHERE (company_id = @company_id OR @company_id = 0) AND (company_type=@company_type OR @company_type=0)
 ORDER BY company_name
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
SET ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
