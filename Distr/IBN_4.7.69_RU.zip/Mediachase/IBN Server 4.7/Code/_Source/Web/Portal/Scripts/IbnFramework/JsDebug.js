//JsScriptDebugger = function(msg, url)
//{ 
//	var req = window.XMLHttpRequest? 
//		new XMLHttpRequest() : 
//		new ActiveXObject("Microsoft.XMLHTTP");
//		
//	req.onreadystatechange = function() 
//	{
//		return;
//	}
//	req.open("GET", url+'?msg=' + msg, true);
//	//req.setRequestHeader('Content-length', '0');
//	req.send(null);
//}
