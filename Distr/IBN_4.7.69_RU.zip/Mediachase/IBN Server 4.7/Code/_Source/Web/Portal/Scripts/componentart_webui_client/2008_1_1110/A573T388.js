function _q4C(e,o){}function _q15(o){}function art_SetClientInfo(s){}
