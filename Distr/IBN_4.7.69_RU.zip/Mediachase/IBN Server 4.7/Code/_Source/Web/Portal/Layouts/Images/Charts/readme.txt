This folder contains generated chart images.
ASP.NET must have read/write access to this folder.