﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Security.Permissions;
using System.Web;
using System.Web.Hosting;

namespace IBNBPMClientService
{
    [AspNetHostingPermission(SecurityAction.Demand, Level = AspNetHostingPermissionLevel.Minimal)]
    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class BPMFormVirtualDirectory : VirtualDirectory
    {
        BPMVirtualPathProvider spp;

        private bool exists;
        public bool Exists
        {
            get { return exists; }
        }

        public BPMFormVirtualDirectory(string virtualDir, BPMVirtualPathProvider provider)
            : base(virtualDir)
        {
            spp = provider;
            GetData();
        }

        protected void GetData()
        {
            //DataSet ds = spp.GetVirtualData();

            // Clean up the path to match data in resource file.
            string path = VirtualPath.Replace(HostingEnvironment.ApplicationVirtualPath, "");
            path = path.TrimEnd('/');
            if(path == "BPMForms" || path == "ProcessesMaps" || path == "InstancesMaps")
                exists = true;
        }

        private ArrayList children = new ArrayList();
        public override IEnumerable Children
        {
            get { return children; }
        }

        private ArrayList directories = new ArrayList();
        public override IEnumerable Directories
        {
            get { return directories; }
        }

        private ArrayList files = new ArrayList();
        public override IEnumerable Files
        {
            get { return files; }
        }
    }
}