﻿using System.Web.Hosting;

namespace IBNBPMClientService
{
    public class AppStart
    {
        public static void AppInitialize()
        {
            BPMVirtualPathProvider BPMProvider = new BPMVirtualPathProvider();
            HostingEnvironment.RegisterVirtualPathProvider(BPMProvider);
        } 
    }
}