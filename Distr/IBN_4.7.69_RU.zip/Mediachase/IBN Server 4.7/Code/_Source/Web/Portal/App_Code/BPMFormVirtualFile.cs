﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Permissions;
using System.Web;
using System.Web.Caching;
using System.Web.Hosting;

namespace IBNBPMClientService
{
    [AspNetHostingPermission(SecurityAction.Demand, Level = AspNetHostingPermissionLevel.Minimal)]
    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class BPMFormVirtualFile : VirtualFile
    {
        private string content;
        private byte[] data;
        private BPMVirtualPathProvider spp;

        public bool Exists
        {
            get { return (content != null || data != null); }
        }

        public BPMFormVirtualFile(string virtualPath, BPMVirtualPathProvider provider)
            : base(virtualPath)
        {
            this.spp = provider;
            GetData();
        }

        protected void GetData()
        {
            string Extension = Path.GetExtension(this.Name);
            Common.WorkflowHelper sc = null;
            switch (Extension.ToLower())
            {
                case ".aspx":
                    int Formid = Int32.Parse(this.Name.Substring(0, this.Name.IndexOf("_")));
                    content = "<%@ Page Language=\"C#\" AutoEventWireup=\"true\" Debug=\"true\"  %>" + Environment.NewLine +
                              "<%@ Assembly Name=\"Common\" %>" + Environment.NewLine +
                              "<%@ Reference Control=\"~/Modules/PageTemplateNext.ascx\" %>" + Environment.NewLine +
                              "<%@ Register TagPrefix=\"ibn\" TagName=\"PageTemplate\" src=\"~/Modules/PageTemplateNext.ascx\" %>" + Environment.NewLine +
                              "<%@ Implements interface=\"Common.IPageConfig\" %>" + Environment.NewLine +
                              "    <script type=\"text/C#\" runat=\"server\">" + Environment.NewLine +
                              "         public Common.IBPMConfig GetConfig()" + Environment.NewLine +
                              "         {" + Environment.NewLine +
                              "              return new Mediachase.UI.Web.Apps.BPM.BPMConfig(); " + Environment.NewLine +
                              "         }" + Environment.NewLine +
                              "    </script>" + Environment.NewLine +
                              "<ibn:PageTemplate runat=\"server\" id=\"pT\" Title=\"Назначение\" ControlName=\"~/BPMForms/BPMUserForm_" + Path.GetFileNameWithoutExtension(this.Name) + ".ascx\"></ibn:PageTemplate>";
                    break;
                case ".ascx":
		    if(this.Name.StartsWith("BPMUserForm"))
		    {
		     	string ControlName = this.Name.Remove(0, 12);
			content = 
			"<%@ Reference Control=\"~/Modules/PageViewMenu.ascx\" %>" + Environment.NewLine +
			"<%@ Reference Control=\"~/Apps/BPM/Modules/DocumentInfo.ascx\" %>" +  Environment.NewLine +
			"<%@ Reference Control=\"~/BPMForms/" + ControlName + "\" %>" +  Environment.NewLine +
			"<%@ Control Language=\"C#\"  %>" + Environment.NewLine +
			"<%@ Register TagPrefix=\"ibn\" TagName=\"DocumentInfo\" src=\"~/Apps/BPM/Modules/DocumentInfo.ascx\" %>" + Environment.NewLine +
			"<%@ Register TagPrefix=\"ibn\" TagName=\"BPMUserControl\" src=\"~/BPMForms/" + ControlName + "\" %>" + Environment.NewLine +
                        "<%@ Register TagPrefix=\"ibn\" TagName=\"PageViewMenu\" src=\"~/Modules/PageViewMenu.ascx\" %>" + Environment.NewLine +
			"<table class=\"ibn-stylebox2\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" border=\"0\">" + Environment.NewLine +
                        "    <tr>" + Environment.NewLine +
                        "        <td>" + Environment.NewLine +
                        "            <ibn:PageViewMenu id=\"secHeader\" title=\"\" runat=\"server\" />" + Environment.NewLine +
                        "        </td>" + Environment.NewLine +
                        "    </tr>" + Environment.NewLine +
                        "    <tr>" + Environment.NewLine +
                        "        <td style=\"padding-left:7px; padding-right:7px; padding-bottom:7px\">" + Environment.NewLine +
			"		<ibn:DocumentInfo ID=\"di\" runat=\"server\"></ibn:DocumentInfo>" + Environment.NewLine +
			"		<ibn:BPMUserControl ID=\"bpmuc\" runat=\"server\"></ibn:BPMUserControl>" + Environment.NewLine +
                        "        </td>" + Environment.NewLine +
                        "    </tr>" + Environment.NewLine +
                        "</table>" + Environment.NewLine +
			"<script runat=\"server\">" + Environment.NewLine +
			"protected void Page_Load(object sender, EventArgs e)" + Environment.NewLine +
                                "{" + Environment.NewLine +
                                "       try" + Environment.NewLine +
                                "       {" + Environment.NewLine +
                                "           Common.WorkflowHelper sc = new Common.WorkflowHelper((this.Page as Common.IPageConfig).GetConfig());" + Environment.NewLine +
                                "           Common.WorkflowService.WorkflowActivityInstanceFullInfo aii = sc.GetInstanceActivityFullInfo(" + Environment.NewLine +
                                "           Convert.ToDecimal(Request[\"InstanceId\"]), Convert.ToInt32(Request[\"ActivityId\"]));" + Environment.NewLine +
				"	    if(aii.ProcessState != Common.WorkflowService.WorkflowProcessInstanceStates.Active || !(aii.State == Common.WorkflowService.WorkflowActivityInstanceStates.Ready || aii.State == Common.WorkflowService.WorkflowActivityInstanceStates.Processing))	" + Environment.NewLine +
				"		{ this.Visible = false; return;}" + Environment.NewLine +
                                "           secHeader.Title = \"Операция: \" + aii.Name;" + Environment.NewLine +
                                "       }" + Environment.NewLine +
                                "       catch (Exception ex )" + Environment.NewLine +
                                "       {" + Environment.NewLine +
				"		Response.Redirect(\"~/Apps/Shell/Pages/default.aspx\");" + Environment.NewLine +
                                "       }" + Environment.NewLine +
                                "}" + Environment.NewLine +
                                "</script>";
		    }
		    else
		    {	
                    	int Formid2 = Int32.Parse(this.Name.Substring(0, this.Name.IndexOf("_")));
	                sc = new Common.WorkflowHelper(new Mediachase.UI.Web.Apps.BPM.BPMConfig());
        	        Common.WorkflowService.WebForm Form = (Common.WorkflowService.WebForm)sc.GetProcessForm(Formid2);
        	        if (Form != null)
	                {
	                    content = Form.Code;
	                }
		    }
                    break;
                case ".jpg":
                case ".bpmmap":
                    String checkPath = VirtualPathUtility.ToAppRelative(this.VirtualPath);
                    if (checkPath.StartsWith("~/ProcessesMaps", StringComparison.InvariantCultureIgnoreCase))
                    {
                        int ProcessId = Int32.Parse(Path.GetFileNameWithoutExtension(this.Name));
                        sc = new Common.WorkflowHelper(new Mediachase.UI.Web.Apps.BPM.BPMConfig());
                        data = sc.GetProcessImage(ProcessId);
                    }
                    else if (checkPath.StartsWith("~/InstancesMaps", StringComparison.InvariantCultureIgnoreCase))
                    {
                        int InstanceId = Int32.Parse(Path.GetFileNameWithoutExtension(this.Name));
                        sc = new Common.WorkflowHelper(new Mediachase.UI.Web.Apps.BPM.BPMConfig());
                        data = sc.GetProcessInstanceImage(InstanceId);
                    }
                    break;
            }
        }

        /*private string Convert(string value, System.Text.Encoding src, System.Text.Encoding trg)
        {
           
             byte[] b = src.GetBytes(value);
             byte[] encoded = System.Text.Encoding.Convert(src, trg, b);
             char[] Chars = new char[trg.GetCharCount(encoded, 0, encoded.Length)];
             trg.GetChars(encoded, 0, encoded.Length, Chars, 0);
             return new string(Chars);

        }*/
        public override Stream Open()
        {

            string Extension = Path.GetExtension(this.Name);
            switch (Extension.ToLower())
            {
                case ".aspx":
                case ".ascx":
                    Stream stream = new MemoryStream();
                    StreamWriter writer = new StreamWriter(stream, System.Text.Encoding.Default);
                    writer.Write(content);
                    writer.Flush();
                    stream.Seek(0, SeekOrigin.Begin);
                    return stream;
                    break;
                case ".bpmmap":
                case ".jpg":
                    Stream stream2 = new MemoryStream();
                    stream2.Write(data, 0, data.Length);
                    stream2.Flush();
                    stream2.Seek(0, SeekOrigin.Begin);
                    return stream2;
                    break;
            }
            return null;
            // Put the page content on the stream.
        }
    }
}