This folder contains error reports.
ASP.NET must have read/write access to this folder.