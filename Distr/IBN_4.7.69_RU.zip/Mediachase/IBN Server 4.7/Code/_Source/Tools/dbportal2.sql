SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[DOCUMENT_SECURITY]
AS
SELECT DocumentId, PrincipalId, MAX(IsManager) AS IsManager, MAX(IsResource) AS IsResource,
	MAX(IsRealDocumentManager) AS IsRealDocumentManager, MAX(IsRealDocumentResource) AS IsRealDocumentResource,
	MAX(IsCreator) AS IsCreator
FROM
	(SELECT DocumentId, ManagerId AS PrincipalId, 1 AS IsManager, 0 AS IsResource, 1 AS IsRealDocumentManager, 0 AS IsRealDocumentResource, 0 AS IsCreator
	  FROM DOCUMENTS
	UNION ALL
	SELECT DocumentId, CreatorId AS PrincipalId, 0 AS IsManager, 0 AS IsResource, 0 AS IsRealDocumentManager, 0 AS IsRealDocumentResource, 1 AS IsCreator
	  FROM DOCUMENTS
	UNION ALL
	SELECT DocumentId, PrincipalId,
		CASE WHEN CanManage = 1 THEN 1 ELSE 0 END AS IsManager,
		1 AS IsResource,
		CASE WHEN CanManage = 1 THEN 1 ELSE 0 END AS IsRealDocumentManager,
		1 AS IsRealDocumentResource,
		0 AS IsCreator
	  FROM DOCUMENT_RESOURCES
	  WHERE NOT (MustBeConfirmed = 1 AND ResponsePending = 0 AND IsConfirmed = 0)
	UNION ALL
	SELECT DT.DocumentId, T.PrincipalId, T.IsManager, T.IsResource, 0 AS IsRealDocumentManager, 0 AS IsRealDocumentResource, 0 AS IsCreator
	  FROM TODO_SECURITY T
		JOIN DOCUMENT_TODO DT ON (T.ToDoId = DT.ToDoId)
	UNION ALL
	SELECT DISTINCT OwnerDocumentId AS DocumentId, UserId AS PrincipalId, 0 AS IsManager, 1 AS IsResource, 0 AS IsRealDocumentManager, 0 AS IsRealDocumentResource, 0 AS IsCreator
	  FROM cls_Assignment
	  WHERE OwnerDocumentId IS NOT NULL
	UNION ALL
	SELECT DISTINCT ObjectId AS DocumentId, UserId AS PrincipalId, 0 AS IsManager, 1 AS IsResource, 0 AS IsRealDocumentManager, 0 AS IsRealDocumentResource, 0 AS IsCreator
	  FROM WorkflowParticipant
	  WHERE ObjectType = 16
	) A
GROUP BY DocumentId, PrincipalId
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[DOCUMENT_SECURITY_ALL]
AS
SELECT DocumentId, PrincipalId, MAX(IsManager) AS IsManager, MAX(IsResource) AS IsResource,
	MAX(IsRealDocumentManager) AS IsRealDocumentManager, MAX(IsRealDocumentResource) AS IsRealDocumentResource,
	MAX(IsCreator) AS IsCreator
  FROM (
	SELECT DocumentId, PrincipalId, IsManager, IsResource, IsRealDocumentManager, IsRealDocumentResource, IsCreator
	  FROM DOCUMENT_SECURITY
	  WHERE PrincipalId NOT IN (SELECT PrincipalId FROM GROUPS)
	UNION ALL
	SELECT TS.DocumentId, UG.UserId AS PrincipalId, TS.IsManager , TS.IsResource, IsRealDocumentManager, IsRealDocumentResource, IsCreator
	  FROM DOCUMENT_SECURITY TS
		JOIN USER_GROUP UG ON (TS .PrincipalId = UG.GroupId)
	) S
  GROUP BY DocumentId, PrincipalId
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[ASSIGNMENT_SECURITY]
AS
SELECT AssignmentId, PrincipalId, MAX(IsManager) AS IsManager, MAX(IsParticipant) AS IsParticipant
FROM
	(SELECT A.AssignmentId, D.ManagerId AS PrincipalId, 1 AS IsManager, 0 AS IsParticipant
	  FROM cls_Assignment A
		JOIN DOCUMENTS D ON (A.OwnerDocumentId = D.DocumentId)
	UNION ALL
	SELECT AssignmentId, UserId AS PrincipalId, 0 AS IsManager, 1 AS IsParticipant
	  FROM cls_Assignment
	) A
GROUP BY AssignmentId, PrincipalId
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[CalendarEvent_Security_Read]
AS
SELECT CalendarEventId AS ObjectId
  FROM cls_CalendarEvent
  WHERE
	4 IN (SELECT PrincipalId FROM [dbo].PrincipalsByContext())
	OR
	7 IN (SELECT PrincipalId FROM [dbo].PrincipalsByContext())
	OR
	CalendarEventId IN
	(
		SELECT EventId FROM cls_CalendarEventResource
			WHERE PrincipalId = [dbo].GetUserFromContext() AND ResourceEventOrganizator = 1
	)
	OR
	CalendarEventId IN
	(
		SELECT EventId
		  FROM cls_CalendarEventResource
		  WHERE PrincipalId IN (SELECT PrincipalId FROM [dbo].PrincipalsByContext())
	)
	OR
	ProjectId IN
	(
		SELECT ProjectId
		  FROM Projects
		  WHERE ManagerId = [dbo].GetUserFromContext()
			OR ExecutiveManagerId = [dbo].GetUserFromContext()
	)
	OR
	ProjectId IN
	(
		SELECT ProjectId
		  FROM Project_Members
		  WHERE PrincipalId IN (SELECT PrincipalId FROM [dbo].PrincipalsByContext())
			AND (IsTeamMember = 1 OR IsSponsor = 1 OR IsStakeHolder = 1)
	)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Clients]
AS
SELECT     ContactId AS ClientId, FullName AS [Name], 1 AS IsContact, 0 AS IsOrganization
FROM         dbo.cls_Contact
UNION
SELECT     OrganizationId AS ClientId, [Name], 0 AS IsContact, 1 AS IsOrganization
FROM         dbo.cls_Organization
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW dbo.DocumentClients
AS
SELECT DocumentId, OrgUid As ClientId FROM Documents
WHERE OrgUid IS NOT NULL
UNION
SELECT DocumentId, ContactUid As ClientId FROM Documents
WHERE ContactUid IS NOT NULL
UNION
SELECT DocumentId, OrganizationId As ClientId FROM Documents D
JOIN cls_Contact C ON C.ContactId = D.ContactUid
WHERE OrganizationId IS NOT NULL
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW dbo.EventClients
AS
SELECT EventId, OrgUid As ClientId FROM Events
WHERE OrgUid IS NOT NULL
UNION
SELECT EventId, ContactUid As ClientId FROM Events
WHERE ContactUid IS NOT NULL
UNION
SELECT EventId, OrganizationId As ClientId FROM Events E
JOIN cls_Contact C ON C.ContactId = E.ContactUid
WHERE OrganizationId IS NOT NULL
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW dbo.IncidentClients
AS
SELECT IncidentId, OrgUid As ClientId FROM Incidents
WHERE OrgUid IS NOT NULL
UNION
SELECT IncidentId, ContactUid As ClientId FROM Incidents
WHERE ContactUid IS NOT NULL
UNION
SELECT IncidentId, OrganizationId As ClientId FROM Incidents I
JOIN cls_Contact C ON C.ContactId = I.ContactUid
WHERE OrganizationId IS NOT NULL
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW dbo.ProjectClients
AS
SELECT ProjectId, OrgUid As ClientId FROM Projects
WHERE OrgUid IS NOT NULL
UNION
SELECT ProjectId, ContactUid As ClientId FROM Projects
WHERE ContactUid IS NOT NULL
UNION
SELECT ProjectId, OrganizationId As ClientId FROM Projects P
JOIN cls_Contact C ON C.ContactId = P.ContactUid
WHERE OrganizationId IS NOT NULL
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW dbo.ToDoClients
AS
SELECT ToDoId, OrgUid As ClientId FROM ToDo
WHERE OrgUid IS NOT NULL
UNION
SELECT ToDoId, ContactUid As ClientId FROM ToDo
WHERE ContactUid IS NOT NULL
UNION
SELECT ToDoId, OrganizationId As ClientId FROM ToDo T
JOIN cls_Contact C ON C.ContactId = T.ContactUid
WHERE OrganizationId IS NOT NULL
GO
